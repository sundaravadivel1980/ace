import { AbstractControl } from '@angular/forms/src/model';

export class AppUtil {
    /**
     * Returns true if the field value array is empty
     *
     * @param formControl
     * @param controlName
     */
    public static isEmptyArray(formControl: AbstractControl, controlName: string) {
        return formControl.get(controlName).value && formControl.get(controlName).value.length === 0;
    }

    public static isArrayValueExists(formControl: AbstractControl, controlName: string) {
        return formControl.get(controlName).value && formControl.get(controlName).value.length > 0;
    }

    public static isEmptyValue(formControl: AbstractControl, controlName: string) {
        return !formControl.get(controlName).value;
    }

    public static isValueExists(formControl: AbstractControl, controlName: string) {
        return formControl.get(controlName).value;
    }

    public static isNullOrBlank(value: string) {
        let returnValue = false;
        if (value === null || value === undefined || value.trim() === '') {
            returnValue = true;
        }

        return returnValue;
    }
}
