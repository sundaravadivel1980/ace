/**
 * This TS file contains all the intermediate components between Rule UI and service response components
 */
export interface RuleDetailChildForm {
    /** Returns constructed data to be posted for rule create/update */
    getValues();
    /** Updates the form values from service response */
    setValues();
    validate();
}
export class MarketComponentForm {
    public legOrOAndDFlag: string;
    public marketLogicalUnits: MarketFormGroup[];
    public segmentLogicalUnits: MarketFormGroup[];
}

export class MarketFormGroup {
    public operators: string;
    public groupName: string;
    public originDestinations: OriginDestinationFormGroup[];
}

export class OriginDestinationFormGroup {
    public origin: any;
    public destination: any;
    public bidirectional: boolean;
}
export class ClassesComponentForm {
    public classesUnit: ClassesFormGroup[];
    public waitlistRdo: string;
}
export class ClassesFormGroup {
    public condSelect: string;
}
export class CarrierComponentForm {
    public carrierLogicalUnits: CarrierFormGroup[];
}

export class CarrierFormGroup {
    public operator: string;
    public marketing: string;
    public operating: string;
}

export class FlightComponentForm {
    public flightLogicalUnits: FlightFormGroup[];
}

export class FlightFormGroup {
    public operator: string;
    public flightNumbers: any;
    public flightGroups: any;
}

export class LFComponentFormModel {
    public LoadFactor: LoadFactorFormGroup[];
}

export class LoadFactorFormGroup {
    public cabin: string;
    public originDestinations: OriginDestinationFormGroup[];
    public actual: string;
    public actualInput: string;
}

export class ConnectionPointComponentForm {
    public connectionPointUnit: ConnectionPointFormGroup[];
}

export class ConnectionPointFormGroup {
    public connectionpointSelect: string;
    public connectionpointRadio: string;
    public connectionTimeUnit: ConnectionCityAndTimeFormModel[];
}

export class ConnectionCityAndTimeFormModel {
    public connectionpointCityTo: any;
    public connectionpointCityFrom: any;
    public minTime: number;
    public maxTime: number;
}

export class PointOfCommencementFormModel {
    public pointOfCommencementLogicalUnit: PointOfCommencementFormModelGroup[];
}

export class PointOfCommencementFormModelGroup {
    public operators: string;
    public location: any;
}

export class RoutingComponentForm {
    public routingUnit: RoutingFormGroup[];
}

export class RoutingFormGroup {
    public domesticInternational: string;
    public direct: boolean;
    public nonstop: boolean;
    public carrier: string;
    public connectType: string;
    public connectionCount: string;
}

export class PointOfSaleComponentForm {
    public pointOfSaleLogicalUnit: PointOfSaleFormGroup[];
}

export class PointOfSaleFormGroup {
    public operator: string;
    public groupName: any;
    public businessID: any;
    public airlineGds: any;
    public iataNumber: any;
    public pseudoCode: any;
    public geographicalCode: any;
    public countryCode: any;
    public regionCode: any;
    public userType: any;
    public iataCityCode: any;
    public airlineCode: any;
    public currencyCode: any;
    public requestCode: any;
    public communicationNumber: any;
    public inhouseID: any;
 }

export class AvailabilityAdjustmentComponentForm {
    public availabilityAdjustmentUnit: AvailabilityAdjustmentFormGroup[];
}

export class AvailabilityAdjustmentFormGroup {
    public override: boolean;
    public availability: boolean;
    public seats: number;
    public numbers: number;
    public maxSeats: number;
    public minSeats: number;
    public increaseSeats: number;
    public seatsSign: string;
    public numbersSign: string;
}

export class BidPriceAdjustmentComponentForm {
    public bidPriceAdjustmentUnit: BidPriceAdjustmentFormGroup[];
}

export class BidPriceAdjustmentFormGroup {
    public all: boolean;
    public connection: boolean;
    public local: boolean;
    public opaque: boolean;
    public reward: boolean;
    public cabin: any;
    public bidPrice: number;
    public amount: number;
    public numbers: number;
    public minAmount: number;
    public maxAmount: number;
    public amountSign: string;
    public numbersSign: string;
    public gsaGroupUnit: BidSeat[];
}

export class BidSeat {
    public gsaNumber: string;
    public gsaRange: string;
    public gsaOperator: string;
    public gsaRangeOperator: string;
}

export class ClassAvailabilityComponentForm {
    public classesAvailabilityUnit: ClassAvailabilityFormGroup[];
}

export class ClassAvailabilityFormGroup {
    public condSelect: string;
    public seatsUnit: ClassSegmentForm[];
    public operators: string;
    public numbers: number;
}

export class ClassSegmentForm {
    public origin: any;
    public destination: any;
}

export class ClassBookingComponentForm {
    public classesBookingUnit: ClassAvailabilityFormGroup[];
}

export class ClassBookingFormGroup {
    public condSelect: string;
    public seatsUnit: ClassSegmentForm[];
    public operators: string;
    public numbers: number;
}

export class DropdownModel {
    public id: any;
    public value: any;
}

export class MarketFareComponentForm {
    public baseFareAdjustmentUnit: MarketFareFormGroup[];
}

export class MarketFareFormGroup {
    public setFare: number;
    public amount: number;
    public basefarePercentage: number;
    public maxAmount: number;
    public minAmount: number;
    public amountSign: string;
    public basefarePercentageSign: string;
}

export class DepartureDateTimeComponentForm {
    public departureDataLogicalUnits: DateTimeFormGroup[];
}

export class SellingDateTimeComponentForm {
    public sellingDateArray: DateTimeFormGroup[];
}

export class ArrivalTimeComponentForm {
    public arrivalTime: TimeFormGroup[];
}

export class DepartureTimeComponentForm {
    public departureTime: TimeFormGroup[];
}

export class TimeFormGroup {
    public operator: string;
    public startHours: string;
    public startMinutes: string;
    public endHours: string;
    public endMinutes: string;
}

export class DateTimeFormGroup {
    public allDay: boolean;
    public monday: boolean;
    public tuesday: boolean;
    public wednesday: boolean;
    public thursday: boolean;
    public friday: boolean;
    public saturday: boolean;
    public sunday: boolean;
    public operators: string;
    public startDate: string;
    public startHour: string;
    public startMinute: string;
    public endDate: string;
    public endHour: string;
    public endMinute: string;
}

export class TimeOutsideDepartureComponentForm {
    public timeOutsideDepartureUnit: DaysAndHoursFormGroup[];
}

export class TimeToDepartureComponentForm {
    public timeToDepartureUnit: DaysAndHoursFormGroup[];
}

export class DaysAndHoursFormGroup {
    public days: number;
    public hours: number;
    public minutes: number;
}

export class EquipmentComponentForm {
    public equipmentArray: EquipmentFormGroup[];
}

export class EquipmentFormGroup {
    public operators: string;
    public iataCode: any;
    public configuration: any;
}
