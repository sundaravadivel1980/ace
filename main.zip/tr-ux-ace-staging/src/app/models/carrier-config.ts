import { CarrierPreference, Values } from '@dxc/tr-ux-ace-services/dist/lib';
import { DropdownModel } from '../models/rule-form.model';

export class CarrierConfig {

    public static getCarrierPreferenceVaues(name: string, carrierPreferenceList: CarrierPreference[]) {
        let returnValues = [];
        if (carrierPreferenceList && carrierPreferenceList.length > 0) {
            carrierPreferenceList.forEach(carrierPreference => {
                if (carrierPreference.name === name) {
                    returnValues = carrierPreference.values;
                }
            });
        }
        return returnValues;
    }

    public static getCarrierPreference(name: string, carrierPreferenceList: CarrierPreference[]) {
        if (carrierPreferenceList && carrierPreferenceList.length > 0) {
            carrierPreferenceList.forEach(carrierPreference => {
                if (carrierPreference.name === name) {
                    return carrierPreference;
                }
            });
        }
    }

    public static getCabinList(name: string, carrierPreferenceList: CarrierPreference[]): DropdownModel[] {
        return this.getCarrierPreferenceVaues(name, carrierPreferenceList).map(item => {
            return { id: item['data'][0], value: item['data'][1] };
        }) as DropdownModel[];
    }

    public static getBookingClassesList(name: string, carrierPreferenceList: CarrierPreference[]): DropdownModel[] {
        return this.getCarrierPreferenceVaues(name, carrierPreferenceList).map((item, index) => {
            return {
                id: index === 0 ? 'firstRow' : index === 1 ? 'secondRow' : index === 2 ? 'thirdRow' : 'fourthRow',
                value: item['data']
            };
        }) as DropdownModel[];
    }

    public static getAiportsList(airportsList): DropdownModel[] {
        // {airport: "ANGAMA", city: "MAASAI MARA", code: "ANA", country: "KENYA", timeZone: "KE1"}
        const airportList = airportsList.map(airport => {
            return { id: airport.code, value: airport.code + ' - ' + airport.city + ' (' + airport.airport + ')' + ', ' + airport.country  };
        });
        airportList.unshift({id: '***', value: 'All Airports'});
        return airportList as DropdownModel[];
    }

    public static getAirlines(airlinesList): DropdownModel[] {
        const returnValue = [];
        for (const airline of airlinesList) {
            if (airline['carrier'] && airline['name']) {
                returnValue.push({ id: airline.carrier, value: airline.carrier + ' - ' + airline.name });
            }
        }
        return returnValue as DropdownModel[];
    }

    public static getCountryList(countryList): DropdownModel[] {
       // {addlTxt: "INCLUDES ST EUSTATIUS AND SABA ISLAND", code: "BQ", name: "BONAIRE"}//
        const returnValue = [];
        for (const country of countryList) {
            if (country['code'] && country['name']) {
                returnValue.push({ id: country.code, value: country.name });
            }
        }
        return returnValue as DropdownModel[];
    }

    public static getCurrencyList(currencyList): DropdownModel[] {
        // {code: "ANG", countryCode: "CW", decimalPlaces: 0, name: "NETHERLANDS ANTILLIAN GUILDER"}
         const returnValue = [];
         for (const currency of currencyList) {
             if (currency['code'] && currency['name']) {
                 returnValue.push({ id: currency.code, value: currency.name });
             }
         }
         return returnValue as DropdownModel[];
     }
}
