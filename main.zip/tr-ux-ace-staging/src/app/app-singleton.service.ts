import { Injectable } from '@angular/core';
import { CarrierPreference, TypeOfGroupings, TableStructure,
  Airline, CityAirport, Currency, Country } from '@dxc/tr-ux-ace-services/dist/lib';
import { DropdownModel } from 'src/app/models/rule-form.model';

@Injectable()
export class AppSingletonService {
  public counter = 0;
  public ruleJsonStore: any;
  public airportJsonStore: any;
  public configJsonStore: any;
  public airports: CityAirport[];
  public carrierPreferences: CarrierPreference[];
  public groupTypes: TypeOfGroupings [];
  public referenceTables: TableStructure [];
  public airlines: Airline [];
  public countires: Country [];
  public currencies: Currency [];
  public carrierDateFormat: string;
  public carrierCurrency: string;
  public equipmentCodeList: DropdownModel [];
  public equipmentConfigList: DropdownModel [];
}
