import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

@Injectable()

export class DxcDisableService {
    public bookingClasses = new Subject <string> ();
    public cabinClasses = new Subject <string> ();
    public testObservable: Observable <any>;

    public setBooking(currentValue: string) {
        this.bookingClasses.next(currentValue);
    }
    public getBooking(): Observable <string> {
        return this.bookingClasses.asObservable();
    }

    public setCabins(currentValue: string) {
        this.cabinClasses.next(currentValue);
    }
    public getCabins(): Observable <string> {
        return this.cabinClasses.asObservable();
    }
}
