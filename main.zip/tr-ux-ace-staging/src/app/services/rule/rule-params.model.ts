export class RuleParams {
    public ruleId: any;
    public ruleVersion: any;
    public ruleAction: any;
    public ruleNew: boolean;
    public ruleTime?: string;
    public copyId?: number;
    public copyRuleVersion?: number;    
}
