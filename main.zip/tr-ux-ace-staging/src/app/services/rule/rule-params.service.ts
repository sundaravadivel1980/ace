import { Injectable } from '@angular/core';
import { RuleParams } from './rule-params.model';

@Injectable()
export class RuleParamsService {
    public params: RuleParams;
}
