import { Injectable } from '@angular/core';
import { AbstractControl } from '@angular/forms/src/model';
import { Validators } from '@angular/forms';

import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';

@Injectable()
export class RuleValidationService {
    public ruleValidationCheck: boolean = false;

    private globalErrorKeyList: string[] = [];

    constructor(public messageService: MessageService, public translateService: TranslateService) {
        // empty const
    }

    public showRequiredFieldError(field: AbstractControl) {
        field.setValidators([Validators.required]);
        field.updateValueAndValidity();
        field.markAsUntouched( { onlySelf: true} );
        field.markAsDirty( { onlySelf: true} );
    }

    public addGlobalError(errorKey: string) {
        this.globalErrorKeyList.push(errorKey);
    }

    public hasValidationErrors() {
        return this.globalErrorKeyList.length > 0;
    }

    public clearErrorList() {
        this.globalErrorKeyList = [];
    }

    public showErrors() {
        for (const errorKey of this.globalErrorKeyList) {
            this.translateService.get(errorKey).subscribe(
                translation => {
                    this.ruleValidationCheck = false;
                    this.messageService.error(translation);
                });
        }

        this.globalErrorKeyList = [];
    }
}
