import { HttpErrorResponse } from '@angular/common/http';
import { AbstractControl } from '@angular/forms/src/model';
import { RuleService,  RqStandardPayload, RuleExportRq, RuleRs, Rule } from '@dxc/tr-ux-ace-services/dist/lib';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { AppConstants } from '../../app.constants';
import { saveAs } from 'file-saver/FileSaver';
import { environment } from '../../../environments/environment';

export class RuleUtil {
    public static getAction(rule: Rule) {
        return rule.action[0];
    }
    public static getComponenetData(rule: Rule, conditionType) {
        switch (rule.type) {
          case AppConstants.ACTION_CLASS_CLOSSURE:
                 return rule.action[0].classClosureAction[conditionType];
          case AppConstants.ACTION_BASE_FARE_ADJ:
              return rule.action[0].marketFareAdjustmentAction[conditionType];
          case AppConstants.ACTION_BID_PRICE_ADJ:
              return rule.action[0].bidPriceAdjustmentAction[conditionType];
          case AppConstants.ACTION_CLASS_SUPPRESSION:
              return rule.action[0].classSuppressionAction[conditionType];
          case AppConstants.ACTION_AVAIL_ADJ:
              return rule.action[0].availabilityAdjustmentAction[conditionType];
          default:
        }
    }

    public static downloadExportData(ruleArray: any, ruleService: RuleService, messageService: MessageService) {
        const EXPORT_URL = environment.apiUrl + AppConstants.ruleExportUrl;
        const requestPayload = {
          correlationId: '1', pointOfSale: null
        } as RqStandardPayload;
        const exportRuleData = {
          rqStandardPayload: requestPayload,
          rule: ruleArray
        } as RuleExportRq;
        ruleService.exportRule(EXPORT_URL, exportRuleData).subscribe(
          (ruleResponse: any) => this.saveAsFile(ruleResponse),
          (error: HttpErrorResponse) => {
            messageService.error(error.status + '---' + error.message);
          }
        );
    }

    public static saveAsFile(blobData: any) {
        const blob = new Blob([blobData], { type: 'application/octet-binary'});
        const objectUrl = URL.createObjectURL(blob);
        const filename = 'rules.csv';
        saveAs(blob, filename);
    }

    public static isBookingClassSelected(formControl: AbstractControl) {
        return formControl.get('bookedClasses').value.selectedSeats;
    }

}
