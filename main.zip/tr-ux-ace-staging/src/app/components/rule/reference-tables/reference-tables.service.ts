import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse, HttpParams } from '@angular/common/http';
import { stucture } from './stucture';
import { environment } from '../../../../environments/environment';
import { AppConstants } from '../../../app.constants';

@Injectable()

export class ReferenceTablesService {
    public shareParams: any;
    public responseMessage: any;
    public selectedTable: number;
    private URL = environment.apiUrl + AppConstants.referenceTable;
    constructor(private http: HttpClient) {
    }

    public getTable(id: number) {
        return this.http.get(this.URL + '/' +  id);
    }

    public getTableByName(name: string) {
        const params = new HttpParams().set('name', name);
        return this.http.get(this.URL , {params});
    }

    public addNewRecord(params) {
        return this.http.put(this.URL, params);
    }
}
