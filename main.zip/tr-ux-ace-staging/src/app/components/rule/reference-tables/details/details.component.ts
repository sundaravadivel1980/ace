import { Component, OnInit, Input, Output, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { AppSingletonService } from '../../../../app-singleton.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ReferenceTablesService } from '../reference-tables.service';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';

@Component({
    templateUrl: 'details.component.html'
})

export class DetailsComponent implements OnInit, OnDestroy {
    public formFields: any;
    constructor(
        private singleton: AppSingletonService,
        private route: Router,
        private messageService: MessageService,
        private actRoute: ActivatedRoute,
        private refService: ReferenceTablesService) {
    }

    public ngOnInit() {
        this.formFields = this.refService.shareParams;
        console.log(this.formFields);
    }

    public ngOnDestroy() {
        this.refService.shareParams = undefined;
    }

    public formEmitted(data) {
        console.log(data);
        if (data.action === 'cancel') {
            this.route.navigate(['rule/tables'], { skipLocationChange: true });
        }

        if (data.action === 'save') {
            delete data.action;
            console.log(data);
            const params = { row: [] };
            params['row'].push(data);
            console.log(params);
            this.refService.addNewRecord(params).subscribe(
                (response) => {
                    if (response['rsStandardPayload']['success'] === true) {
                        this.refService.responseMessage = { success: true, operation: data.operation };
                        this.messageService.success('Successfully Added');
                        this.route.navigate(['rule/tables'], { skipLocationChange: true });
                    }else if (response['rsStandardPayload']['success'] === false) {
                        console.log(response);
                        response['rsStandardPayload']['errors']['error'].forEach((err) => {
                            this.messageService.error('Error: ' + err.message);
                        });
                    }
                }
            );
        }
    }
}
