import { Component, OnInit, OnChanges, AfterViewInit, AfterContentInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { AppSingletonService } from '../../../../app-singleton.service';
import { ReferenceTablesService } from '../reference-tables.service';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';

@Component({
    templateUrl: 'directory.component.html'
})

/*
// ADD NEW ROW
{
  "row": [
    {
      "type": 1, // table id
      "column": [
        "C11",
        "Carrier Grouping 10",
        "FF,GG,HH,II,JJ"
      ],
      "operation": "ADD"
    }
  ]
}

// UPDATE ROW
{
  "row": [
    {
      "id":3124,  // Row uniqueId
      "type": 3,  // TableID
      "version": 2, // Version of row (like rule version)
      "time":"2018-02-27T13:29:01.479",
      "column": [
        "MUNA",
        "TEST AGAIN MARKET EDIT",
        "UUUU",
        "XXX,YYY,ZZZ,OOO"
      ],
      "operation": "UPDATE"
    }
  ]
}

//DELETE ROW
{
  "row": [
    {
      "type": 1,
      "id": 3136,
      "time": "2018-02-28T12:10:01.753",
      "operation": "DELETE"
    }
  ]
}
*/

export class DirectoryComponent implements OnInit, OnDestroy {
    public tableLists: any;
    public tableColumns: any;
    public tableContent: any;
    public selectedTable: number;
    public dropdownList: any;

    constructor(
        private refService: ReferenceTablesService,
        private singleton: AppSingletonService,
        private messageService: MessageService,
        private router: Router) {
        this.tableLists = singleton.referenceTables;
    }

    public ngOnInit() {
        if (this.refService.selectedTable) {
            this.selectedTable = this.refService.selectedTable;
            this.dropdownChange(this.selectedTable);
        }
        if (this.refService.responseMessage && this.refService.responseMessage.success === true
            && this.refService.responseMessage.operation === 'ADD') {
            this.messageService.success('Added Successfully');
        }else if (this.refService.responseMessage && this.refService.responseMessage.success === true
            && this.refService.responseMessage.operation === 'UPDATE') {
            this.messageService.success('Updated Successfully');
        }
    }

    public ngOnDestroy() {
        this.refService.responseMessage = undefined;
    }

    public dropdownChange(id: number) {
        this.refService.selectedTable = id;
        this.refService.getTable(id).subscribe(
            (data: HttpResponse<any>) => {
                this.convertJsonFormat(data);
            }
        );
    }

    public clickedRow(row) {
        if (row.action === 'edit') {
            delete row.action;
            this.refService.shareParams = row;
            this.router.navigate(['rule/tables/details'], { skipLocationChange: true });
        } else if (row.action === 'delete') {
            const params = {row: []};
            Object.keys(row).forEach(prop => {
                if (prop !== 'id' && prop !== 'type' && prop !== 'time') {
                    delete row[prop];
                }
            });
            row.operation = 'DELETE';
            params.row.push(row);
            this.refService.addNewRecord(params).subscribe(
                (response) => {
                    if (response['rsStandardPayload']['success'] === true) {
                        this.refService.responseMessage = { success: true, message: 'Deleted successfully' };
                        this.messageService.success('Deleted Successfully');
                        this.dropdownChange(this.refService.selectedTable);
                    } else if (response['rsStandardPayload']['success'] === false) {
                        response['rsStandardPayload']['errors']['error'].forEach((error) => {
                            this.messageService.error(error.message);
                        });
                    }
                }
            );
        }
    }

    public convertJsonFormat(jsonData) {
        const content = [];
        if (!jsonData.row) {
            console.log('This table doesnt have rows');
            return;
        }
        const rows = jsonData.row;
        const column = jsonData.tableStructure.column;
        for (const row of rows) {
            const obj = {};
            const dynamicForm = {};
            const length = row['column'].length;
            dynamicForm['type'] = jsonData.tableStructure.id;
            dynamicForm['id'] = row['id'];
            dynamicForm['time'] = row['time'];
            dynamicForm['operation'] = 'UPDATE';
            for (let i = 0; i < length; i++) {
                obj[column[i]['name']] = row['column'][i];
                dynamicForm[column[i]['name']] = {
                    value: row['column'][i],
                    placeholder: column[i]['displayName'],
                    type: 'text',
                    validation: {
                        required: column[i]['required']
                    }
                };
            }
            obj['dynamicForm'] = dynamicForm;
            content.push(obj);
        }
        this.tableContent = content;
        this.tableColumns = jsonData.tableStructure.column.map(item => item.name);
    }

    public newRecordInsert(id) {
        this.refService.getTable(id).subscribe((data: any) => {
            const dynamicForm = {};
            const column = data.tableStructure.column;
            dynamicForm['type'] = data.tableStructure.id;
            dynamicForm['operation'] = 'ADD';
            for (const col of column) {
                dynamicForm[col['name']] = {
                    value: '',
                    placeholder: col['displayName'],
                    type: 'text',
                    validation: { required: col['required'] }
                };
            }
            this.refService.shareParams = dynamicForm;
            this.router.navigate(['rule/tables/details'], { skipLocationChange: true });
        },
            (error) => console.log(error)
        );

    }
}
