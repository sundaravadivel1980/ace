import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'dynamic-form',
  templateUrl: 'dynamic-form.component.html',
  styleUrls: ['dynamic-form.component.scss']
})

export class DynamicFormComponent implements OnInit {
  @Input() public formInput: any;
  @Output() public formOutput = new EventEmitter();
  public dynamicForm: FormGroup;
  public objectProps;
  public objectKeys: any;

  constructor(private router: Router) {
  }

  public ngOnInit() {
    const formGroup = {};
    this.objectKeys = Object.keys(this.formInput);
    this.objectProps = this.objectKeys.map(prop => {
      return Object.assign({}, { fcontrolName: prop }, this.formInput[prop]);
    });
    for (const prop of this.objectKeys) {
      formGroup[prop] = new FormControl(this.formInput[prop].value || '');
    }
    this.dynamicForm = new FormGroup(formGroup);
  }

  public onClick(action, dynamicForm) {
    const formOutput = {column: []};
    formOutput['action'] = action;
    this.objectKeys.forEach(prop => {
      if (prop === 'type') {
        formOutput['type'] = this.formInput['type'];
      }
      if (prop === 'id') {
        formOutput['id'] = this.formInput['id'];
      }
      if (prop === 'version') {
        formOutput['version'] = this.formInput['version'];
      }
      if (prop === 'time') {
        formOutput['time'] = this.formInput['time'];
      }
      if (prop === 'operation') {
        formOutput['operation'] = this.formInput['operation'];
      }
      // prop !== 'type' && prop !== 'operation' && prop !== 'id' && prop !== 'version' && prop !== 'time' && prop !== 'action'
      if (dynamicForm.value[prop] !== '') {
        formOutput.column.push(dynamicForm.value[prop]);
      }
    });
    this.formOutput.emit(formOutput);
  }

}
