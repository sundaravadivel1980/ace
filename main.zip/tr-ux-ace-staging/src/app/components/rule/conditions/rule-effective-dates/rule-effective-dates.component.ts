import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { DropdownModel } from '../../../../models/rule-form.model';
import { AppSingletonService } from '../../../../app-singleton.service';

@Component({
    selector: 'rule-effective-dates',
    templateUrl: 'rule-effective-dates.component.html',
    styleUrls: ['./rule-effective-dates.component.scss']
})
export class RuleEffectiveDatesComponent {
    @Input() public childInput: any;
    public RuleEffectiveDateGroup: FormGroup;
    public operators: DropdownModel;
    public days: DropdownModel;

    constructor( private fb: FormBuilder, private appSingletonService: AppSingletonService ) {

        this.operators = this.appSingletonService.ruleJsonStore.Operators;
        this.days = this.appSingletonService.ruleJsonStore.Days;

        this.RuleEffectiveDateGroup = this.fb.group({
                                        ChkAll: '',
                                        monday: '',
                                        tuesday: '',
                                        wednesday: '',
                                        thursday: '',
                                        friday: '',
                                        saturday: '',
                                        sunday: '',
                                        RuleEffectiveDateArray: this.fb.array([this.initRuleEffectiveDates()])
                                    });
      }

      public initRuleEffectiveDates() {
        return this.fb.group({
            operators : '',
            startDate: '',
            startHour: '',
            startMinute: '',
            endDate: '',
            endHour: '',
            endMinute: ''
        });
    }
    public addRuleEffectiveDates() {
        const control = this.RuleEffectiveDateGroup.get('RuleEffectiveDateArray') as FormArray;
        control.push(this.initRuleEffectiveDates());
    }
    public removeRuleEffectiveDates(i: number) {
        const control = this.RuleEffectiveDateGroup.get('RuleEffectiveDateArray') as FormArray;
        control.removeAt(i);
    }

}
