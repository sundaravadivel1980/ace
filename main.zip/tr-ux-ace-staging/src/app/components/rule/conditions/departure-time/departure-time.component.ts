import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, AbstractControl } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';

import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';

import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, DepartureTimeComponentForm, TimeFormGroup } from '../../../../models/rule-form.model';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';
// import { empty } from 'rxjs/Observer';

@Component({
    selector: 'departure-time',
    templateUrl: 'departure-time.component.html',
    styleUrls: ['./departure-time.component.scss']
})
export class DepartureTimeGroupComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public departureTimeGroup: FormGroup;
    private departTimeConditionDataArray: DateTimeCondition[];

    private operators: any;
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
        private appSingletonService: AppSingletonService,
        private validationService: RuleValidationService) {
        this.operators = this.appSingletonService.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        this.departureTimeGroup = this.fb.group({
            departureTime: this.fb.array([this.createDepartureTimeFormGroup()])
        });
        this.setValues();
    }

    public createDepartureTimeFormGroup() {
        return this.fb.group({
            operator: 'EQ',
            startHours: '',
            startMinutes: '',
            endHours: '',
            endMinutes: ''
        });
    }

    get departureTimeFormArray(): FormArray {
        return this.departureTimeGroup.get('departureTime') as FormArray;
    }

    public addDepartureTime() {
        this.departureTimeFormArray.push(this.createDepartureTimeFormGroup());
    }

    public removeDepartureTime(i: number) {
        this.departureTimeFormArray.removeAt(i);
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.departTimeConditionDataArray = RuleUtil.getComponenetData(rule, 'departureTimeCondition');
        }
        if (this.departTimeConditionDataArray && this.departTimeConditionDataArray.length > 0) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): DateTimeCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        const departureTimeConditionDataArray = [];
        for (const departTimeFormUnit of this.departureTimeFormArray.value) {
            const dateAndTime = new DateOrRange();
            if (departTimeFormUnit.startHours) {
                dateAndTime.startDateTime = departTimeFormUnit.startHours + ':' + departTimeFormUnit.startMinutes + ':00';
            }
            if (departTimeFormUnit.endHours) {
                dateAndTime.endDateTime = departTimeFormUnit.endHours + ':' + departTimeFormUnit.endMinutes + ':00';
            }
            departureTimeConditionDataArray.push({
                comparator: departTimeFormUnit.operator,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return departureTimeConditionDataArray;
    }

    public addError(departTimeFormUnit: AbstractControl, hours: string, minutes: string) : AbstractControl{
        departTimeFormUnit.get(hours).setErrors({errorVal: true});
        departTimeFormUnit.get(minutes).setErrors({errorVal: true});
        return departTimeFormUnit;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        if (!this.isEmptyCondition) {
            for (const departTimeFormUnit of this.departureTimeFormArray.controls) {
                if (departTimeFormUnit.get('endHours').value || departTimeFormUnit.get('startHours').value ||
                    departTimeFormUnit.get('startMinutes').value || departTimeFormUnit.get('endMinutes').value) {
                    if (!departTimeFormUnit.get('endHours').value) {
                        this.addError(departTimeFormUnit, 'endHours', 'endMinutes');
                        this.validationService.addGlobalError('acegui.rules.messages.end.time.required');
                        this.hasErrors = true;
                    } else if (!departTimeFormUnit.get('startHours').value) {
                        this.addError(departTimeFormUnit, 'startHours', 'startMinutes');
                        this.validationService.addGlobalError('acegui.rules.messages.start.time.required');
                        this.hasErrors = true;
                    } else if (departTimeFormUnit.get('endHours').value < departTimeFormUnit.get('startHours').value) {
                        this.validationService.addGlobalError('acegui.rules.messages.start.time.cannot.be.greater');
                        this.addError(departTimeFormUnit, 'endHours', 'endMinutes');
                        this.hasErrors = true;
                    } else if ((departTimeFormUnit.get('endHours').value === departTimeFormUnit.get('startHours').value) &&
                        departTimeFormUnit.get('endMinutes').value < departTimeFormUnit.get('startMinutes').value) {
                            this.addError(departTimeFormUnit, 'endHours', 'endMinutes');
                        this.validationService.addGlobalError('acegui.rules.messages.start.time.cannot.be.greater');
                        this.hasErrors = true;
                    } else {
                        departTimeFormUnit.get('endHours').setErrors(null);
                        departTimeFormUnit.get('endMinutes').setErrors(null);
                        departTimeFormUnit.get('startHours').setErrors(null);
                        departTimeFormUnit.get('startMinutes').setErrors(null);
                    }
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const departTimeFormUnit of this.departureTimeFormArray.controls) {
            let emptyForm = true;
            if (departTimeFormUnit.get('endHours').value || departTimeFormUnit.get('startHours').value ||
                departTimeFormUnit.get('startMinutes').value || departTimeFormUnit.get('endMinutes').value) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyForm of emptyForms.reverse()) {
            this.removeDepartureTime(emptyForm);
        }
        if (this.departureTimeFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addDepartureTime();
        }
    }

    private setFormValuesFromData() {
        const departureTimeFormUnitArray = [];

        for (const departCondDataUnit of this.departTimeConditionDataArray) {
            const startTimeSplit = departCondDataUnit.dateOrRange.startDateTime ?
                departCondDataUnit.dateOrRange.startDateTime.split(':') : '';
            const endTimeSplit = departCondDataUnit.dateOrRange.endDateTime ?
                departCondDataUnit.dateOrRange.endDateTime.split(':') : '';

            const departureTimeFormUnit = {
                operator: departCondDataUnit.comparator,
                startHours: startTimeSplit[0],
                startMinutes: startTimeSplit[1],
                endHours: endTimeSplit[0],
                endMinutes: endTimeSplit[1]
            } as TimeFormGroup;

            departureTimeFormUnitArray.push(departureTimeFormUnit);
        }

        const departTimeForm = {
            departureTime: departureTimeFormUnitArray
        } as DepartureTimeComponentForm;

        if (departTimeForm) {
            this.setFormValues(departTimeForm);
        }
    }

    private setFormValues(depatureDateTimeFormModel: DepartureTimeComponentForm) {
        const departureTimeFormUnitArray = this.departureTimeGroup.get('departureTime') as FormArray;
        for (const departureTimeFormUnit of depatureDateTimeFormModel.departureTime) {
            departureTimeFormUnitArray.push(this.createDepartureTimeFormGroup());
        }
        this.removeDepartureTime(0);
        (this.departureTimeGroup as FormGroup).patchValue(depatureDateTimeFormModel, { onlySelf: true });
    }
}
