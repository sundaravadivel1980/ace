import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { FlightCondition, Flight, Rule } from '@dxc/tr-ux-ace-services/dist/lib';

import { FlightFormGroup,
    FlightComponentForm, RuleDetailChildForm, DropdownModel } from '../../../../models/rule-form.model';

import { RuleUtil } from '../../rule.util.ts';
import { AppSingletonService } from '../../../../app-singleton.service';
import { GroupType } from '../../../../models/group-type';
import { AppUtil } from '../../../../utility/app-util';

@Component({
    selector: 'flights',
    templateUrl: 'flights.component.html',
    styleUrls: ['./flights.component.scss']
})
export class FlightsComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public flightsForm: FormGroup;
    public flightConditionDataArray: FlightCondition[];

    public flightGroups: DropdownModel[];
    public operators: DropdownModel[];
    public flightValid: boolean;

    private isEmptyCondition: boolean = false;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
        const data = singletonService.ruleJsonStore;
        this.operators = data.Operators;
    }

    public ngOnInit() {
        this.flightGroups = GroupType.getGroupList('Flight Grouping', this.singletonService.groupTypes);

        this.flightsForm = this.fb.group({
            flightLogicalUnits: this.fb.array([this.createFlightFormGroup()])
        });

        this.setValues();
    }

    public addFlightLogicalUnit() {
        const flightFormArray = this.flightsForm.get('flightLogicalUnits') as FormArray;
        flightFormArray.push(this.createFlightFormGroup());
    }

    public removeFlightLogicalUnit(i: number) {
        const flightFormArray = this.flightsForm.get('flightLogicalUnits') as FormArray;
        flightFormArray.removeAt(i);
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.flightConditionDataArray = RuleUtil.getComponenetData(rule, 'flightCondition');
        }
        if ( this.flightConditionDataArray && this.flightConditionDataArray.length > 0 ) {
            this.setFormValuesFromData(this.flightConditionDataArray);
        }
    }

    public getValues(): FlightCondition[] {

        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }
        const flightConditionArray = [];
        for (const flightFormUnit of this.flightFormArray.value) {
            const flightArray = [];
            if (flightFormUnit.flightNumbers) {
                flightFormUnit.flightNumbers.forEach ( flightNumber => {
                const flghtNumberArray = flightNumber.split('-');
                if (flghtNumberArray[1]) {
                    flightArray.push( {
                    startFlight: flghtNumberArray[0],
                    endFlight: flghtNumberArray[1]
                    } as Flight );
                } else {
                    flightArray.push({
                    startFlight: flghtNumberArray[0]
                    } as Flight);
                }
                });
            }
            flightConditionArray.push({
                comparator: flightFormUnit.operator,
                flight: flightArray,
                flightGrouping: flightFormUnit.flightGroups ? flightFormUnit.flightGroups : []
            } as FlightCondition);
        }
        return flightConditionArray;
    }

    get flightFormArray(): FormArray{
        return this.flightsForm.get('flightLogicalUnits') as FormArray;
    }

    public validate() {
       this.removeEmptyForms();
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const flightLogicalUnit of this.flightFormArray.controls) {
            let emptyForm = true;
            if (AppUtil.isArrayValueExists(flightLogicalUnit, 'flightNumbers')
                || AppUtil.isArrayValueExists(flightLogicalUnit, 'flightGroups')) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()){
            this.removeFlightLogicalUnit(emptyFormGroup);
        }
        if (this.flightFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addFlightLogicalUnit();
        }
    }

    private setFormValuesFromData(flightConditionDataArray: FlightCondition[]) {
        const flightFormArray = [];

        for (const flightConditionDataUnit of flightConditionDataArray) {
            const flightFormUnit = {} as FlightFormGroup;
            flightFormUnit.operator = flightConditionDataUnit.comparator;
            const flightNumbers = [];
            if (flightConditionDataUnit.flight) {
                for  (const flight of flightConditionDataUnit.flight) {
                    if  ( flight.hasOwnProperty('startFlight')  &&  flight.hasOwnProperty('endFlight') ) {
                        if (flight.startFlight && flight.endFlight) {
                            flightNumbers.push(flight.startFlight +  '-'  +  flight.endFlight);
                        } else if (flight.startFlight) {
                            flightNumbers.push(flight.startFlight.toString());
                        }
                    } else  if  (flight.hasOwnProperty('startFlight')) {
                        if (flight.startFlight) {
                            flightNumbers.push(flight.startFlight.toString());
                        }
                    }
                }
            }
            flightFormUnit.flightNumbers = flightNumbers;
            flightFormUnit.flightGroups = flightConditionDataUnit.flightGrouping;
            flightFormArray.push(flightFormUnit);
        }

        const flightComponentFormModel = {
            flightLogicalUnits: flightFormArray
        } as FlightComponentForm;

        if (flightComponentFormModel) {
            this.setFormValues(flightComponentFormModel);
        }
    }

    private setFormValues(flightComponentFormModel: FlightComponentForm) {
        const flightFormArray = this.flightsForm.get('flightLogicalUnits') as FormArray;
        for (const flightFormUnit of flightComponentFormModel.flightLogicalUnits){
            flightFormArray.push(this.createFlightFormGroup());
        }
        this.removeFlightLogicalUnit(0);
        (this.flightsForm as FormGroup).patchValue(flightComponentFormModel, { onlySelf: true });
    }

    private createFlightFormGroup() {
        return this.fb.group({
            operator: 'EQ',
            flightNumbers: [''],
            flightGroups: ''
        });
    }
}
