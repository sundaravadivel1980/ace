import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { Rule, BidPriceActionInput, Categories, BidPriceSeat, ClassCondition } from '@dxc/tr-ux-ace-services/dist/lib';
import {
    DropdownModel,
    RuleDetailChildForm,
    BidPriceAdjustmentComponentForm,
    BidPriceAdjustmentFormGroup, BidSeat
} from '../../../../models/rule-form.model';
import { CarrierConfig } from '../../../../models/carrier-config';
import { RuleUtil } from '../../rule.util.ts';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

@Component({
    selector: 'bid-price-adjustment',
    templateUrl: 'bid-price-adjustment.component.html',
    styleUrls: ['./bid-price-adjustment.component.scss']
})

export class BidPriceAdjustmentComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;
    public bidPriceAdjustmentForm: FormGroup;

    public cabins: DropdownModel[];
    public categorys: DropdownModel[];
    public gsaOperator: DropdownModel[];
    public gsaRangeOperator: DropdownModel[];
    public enableBidPriceCategory: boolean;
    public carrierPrefCurrency: string;
    private cabinClassesInput: DropdownModel[];
    private cabinViewData: any;

    private bidPriceAdjustmentData: BidPriceActionInput;

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageService,
                private translateService: TranslateService,
                private ruleValidation: RuleValidationService) {
        this.categorys = singletonService.ruleJsonStore.BidPriceCategory;
        this.gsaRangeOperator = singletonService.ruleJsonStore.Operators;
        this.gsaOperator = singletonService.ruleJsonStore.SeatsOperators;
        // will be removed. there is no category
        this.enableBidPriceCategory = singletonService.configJsonStore.BPRADJ.EnableBidPriceCategory;
    }

    public ngOnInit() {
        this.cabinClassesInput = CarrierConfig.getCabinList('Cabin Types', this.singletonService.carrierPreferences);
        this.carrierPrefCurrency = this.singletonService.carrierCurrency;
        this.bidPriceAdjustmentForm = this.fb.group({
            bidPriceAdjustmentUnit: this.fb.array([this.createBidPriceAdjustFormGroup()])
        });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.bidPriceAdjustmentData = RuleUtil.getComponenetData(rule, 'actionInput');
        }
        if (this.bidPriceAdjustmentData) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): BidPriceActionInput {
        this.validate();

        if (this.hasErrors) {
            return null;
        }

        const dataArray = [];
        for (const bidPriceFormUnit of this.bidPriceFormArray.value) {
            const bidPriceAdjustActionInput = new BidPriceActionInput();
            const bidSeats = [];
            for (const gsaFormUnit of bidPriceFormUnit.gsaGroupUnit) {
                const bidSeat = new BidPriceSeat();
                if (gsaFormUnit.gsaNumber) {
                    bidSeat.startSeat = gsaFormUnit.gsaNumber;
                    bidSeat.seatsRestriction = bidSeat.startSeat ? gsaFormUnit.gsaOperator : '';
                    bidSeats.push(bidSeat);
                } else if (gsaFormUnit.gsaRange) {
                    const gsaRangeArray = gsaFormUnit.gsaRange.split('-');
                    if (gsaRangeArray[1]) {
                        bidSeat.startSeat = gsaRangeArray[0];
                        bidSeat.endSeat = gsaRangeArray[1];
                    } else {
                        bidSeat.startSeat = gsaRangeArray[0];
                    }
                    bidSeat.seatsRestriction = bidSeat.startSeat ? gsaFormUnit.gsaRangeOperator : '';
                    bidSeats.push(bidSeat);
                }
            }

            bidPriceAdjustActionInput.bidPrice = bidPriceFormUnit.bidPrice;
            bidPriceAdjustActionInput.changeAmount = bidPriceFormUnit.amount ? (bidPriceFormUnit.amountSign ? bidPriceFormUnit.amountSign : "+") + bidPriceFormUnit.amount : '';
            bidPriceAdjustActionInput.changePercent = bidPriceFormUnit.numbers ? bidPriceFormUnit.numbersSign + bidPriceFormUnit.numbers : '';
            bidPriceAdjustActionInput.maximum = bidPriceFormUnit.maxAmount;
            bidPriceAdjustActionInput.minimum = bidPriceFormUnit.minAmount;
            bidPriceAdjustActionInput.seats = bidSeats;
            bidPriceAdjustActionInput.cabin = bidPriceFormUnit.cabinClasses;
            dataArray.push(bidPriceAdjustActionInput);
        }
        return dataArray[0];
    }

    public validate() {
        this.removeEmptyForms();
        this.hasErrors = false;

        if (this.isEmptyCondition) {
            this.ruleValidation.addGlobalError('acegui.rules.messages.bid.price.condition.required');
            this.hasErrors = true;
        } else {
            for (const bidPriceFormUnit of this.bidPriceFormArray.controls) {
                const gsaGroupUnit = bidPriceFormUnit.get('gsaGroupUnit') as FormArray;
                let emptyGSAForm = true;
                for (const gsaGroupUnitData of gsaGroupUnit.controls) {
                    if (gsaGroupUnitData.value.gsaNumber || gsaGroupUnitData.value.gsaRange) {
                        emptyGSAForm = false;
                    }
                }
                if (bidPriceFormUnit.value.cabinClasses.length === 0) {
                    this.hasErrors = true;
                    this.ruleValidation.addGlobalError('acegui.rules.messages.bid.price.cabin.required');
                }
                if (bidPriceFormUnit.value.amount && bidPriceFormUnit.value.numbers) {
                    this.hasErrors = true;
                     // cabin is required
                    this.ruleValidation.addGlobalError('acegui.rules.messages.bid.fare.amount.and.percent.not.allowed');
                }
                if (!bidPriceFormUnit.value.amount
                    && !bidPriceFormUnit.value.numbers
                    && !bidPriceFormUnit.value.bidPrice
                    && !bidPriceFormUnit.value.maxAmount
                    && !bidPriceFormUnit.value.minAmount) {
                    // Bid Price (or) Amount/Percentage/Mininum/Maximum is required
                    this.ruleValidation.addGlobalError('acegui.rules.messages.bid.price.condition.required');
                    this.hasErrors = true;
                }

                if (bidPriceFormUnit.value.bidPrice
                    && (bidPriceFormUnit.value.numbers
                    || bidPriceFormUnit.value.amount
                    || bidPriceFormUnit.value.maxAmount
                    || bidPriceFormUnit.value.minAmount)) {
                    // If bid price is given, no other adjustments allowed
                    this.ruleValidation.addGlobalError('acegui.rules.messages.bid.fare.set.bid.cannot.be.combined');
                    this.hasErrors = true;
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyBidPriceGroups = [];
        this.isEmptyCondition = false;

        for (const bidPriceFormUnit of this.bidPriceFormArray.controls) {
            const gsaGroupUnit = bidPriceFormUnit.get('gsaGroupUnit') as FormArray;
            let j: number = 0;
            const emptyGSAUnitGroups = [];
            for (const gsaGroupUnitData of gsaGroupUnit.controls) {
                let emptyGsaGroup = true;
                if (gsaGroupUnitData.value.gsaNumber || gsaGroupUnitData.value.gsaRange) {
                        emptyGsaGroup = false;
                }
                if (emptyGsaGroup) {
                    emptyGSAUnitGroups.push(j);
                }
                j++;
            }
            for (const emptyGSAGroup of emptyGSAUnitGroups.reverse()) {
                this.removeGsaGroupUnit(i, emptyGSAGroup);
            }

            let emptyGSAForm = false;
            if (gsaGroupUnit.length === 0) {
                emptyGSAForm = true;
                this.addGsaGroupUnit(i);
            }

            let emptyBidPriceForm = true;
            if (!emptyGSAForm || bidPriceFormUnit.value.numbers || bidPriceFormUnit.value.amount || bidPriceFormUnit.value.bidPrice
                || bidPriceFormUnit.value.maxAmount || bidPriceFormUnit.value.minAmount) {
                    emptyBidPriceForm = false;
            }

            if (emptyBidPriceForm) {
                emptyBidPriceGroups.push(i) ;
            }
            i++;
        }
        for (const emptyGroup of emptyBidPriceGroups.reverse()) {
            this.removeBidPriceAdjustmentUnit(emptyGroup);
        }
        if (this.bidPriceFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addBidPriceAdjustmentUnit();
        }
    }

    public enableDisableFields(value) {
        const fieldsList = ['amount', 'numbers', 'numbersSign', 'amountSign', 'minAmount', 'maxAmount'];
        if (value === '') {
            for (const field of fieldsList) {
                // this.bidPriceFormArray.controls[0].get(field).reset();
                this.bidPriceFormArray.controls[0].get(field).enable();
            }
        } else {
            for (const field of fieldsList) {
                this.bidPriceFormArray.controls[0].get(field).reset();
                this.bidPriceFormArray.controls[0].get(field).disable();
            }
        }
    }

    public enableDisableGSAFields(value, disableField: string, i: number, j: number) {
        const gsaUnit = this.bidPriceFormArray.controls[i].get('gsaGroupUnit') as FormArray;
        if (disableField === 'number') {
            gsaUnit.controls[j].get('gsaRange').disable();
            gsaUnit.controls[j].get('gsaRangeOperator').disable();
            gsaUnit.controls[j].get('gsaNumber').enable();
            gsaUnit.controls[j].get('gsaOperator').enable();
            if (value === '') {
                gsaUnit.controls[j].get('gsaRange').enable();
                gsaUnit.controls[j].get('gsaRangeOperator').enable();
            }
        } else if (disableField === 'range') {
            gsaUnit.controls[j].get('gsaRange').enable();
            gsaUnit.controls[j].get('gsaRangeOperator').enable();
            gsaUnit.controls[j].get('gsaNumber').disable();
            gsaUnit.controls[j].get('gsaOperator').disable();
            if (value === '') {
                gsaUnit.controls[j].get('gsaNumber').enable();
                gsaUnit.controls[j].get('gsaOperator').enable();
            }
        }
    }

    get bidPriceFormArray(): FormArray {
        return this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
    }

    private createBidPriceAdjustFormGroup() {
        return this.fb.group({
            cabinClasses: '',
            amount: '',
            numbers: '',
            amountSign: '',
            numbersSign: '',
            minAmount: '',
            maxAmount: '',
            bidPrice: '',
            gsaGroupUnit: this.fb.array([this.createGsaFormGroup()])
        });
    }

    private addBidPriceAdjustmentUnit() {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
        control.push(this.createBidPriceAdjustFormGroup());
    }

    private removeBidPriceAdjustmentUnit(i: number) {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
        control.removeAt(i);
    }

    get bidPriceUnit(): FormArray {
        return this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
    }

    private createGsaFormGroup() {
        return this.fb.group({
            gsaNumber: '',
            gsaRange: '',
            gsaOperator: 'EQ',
            gsaRangeOperator: 'EQ'
        });
    }

    private addGsaGroupUnit(j: number) {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit')['controls'][j].get('gsaGroupUnit') as FormArray;
        control.push(this.createGsaFormGroup());
    }

    private removeGsaGroupUnit(j: number, i: number) {
        const control = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit')['controls'][j].get('gsaGroupUnit') as FormArray;
        control.removeAt(i);
    }

    private selectAll(i: number) {
        const fields = this.categorys;
        const all = 'all';
        for (const item of fields) {
            this.bidPriceUnit['controls'][i].get(item.id).setValue(
                this.bidPriceUnit['controls'][i].get(all).value
            );
        }

    }
    private checkIfAllSelected(i: number) {
        const fields = this.categorys;
        const all = 'all';
        const chkAll = [];
        for (const item of fields) { chkAll.push(this.bidPriceUnit['controls'][i].get(item.id).value); }
        const selectAll = chkAll.every(function(item: boolean) { return item === true; });
        this.bidPriceUnit['controls'][i].get(all).setValue(selectAll);
    }

    private setFormValuesFromData() {
        const bidPriceAdjustmentFromModelGroupData = [];
        if (this.bidPriceAdjustmentData) {
            const bidPriceAdjustmentFromModelGroup = {} as BidPriceAdjustmentFormGroup;
            if (this.bidPriceAdjustmentData.bidPrice) {
                bidPriceAdjustmentFromModelGroup.bidPrice = this.bidPriceAdjustmentData.bidPrice;
            }
            if (this.bidPriceAdjustmentData.minimum) {
                bidPriceAdjustmentFromModelGroup.minAmount = this.bidPriceAdjustmentData.minimum;
            }
            if (this.bidPriceAdjustmentData.maximum) {
                bidPriceAdjustmentFromModelGroup.maxAmount = this.bidPriceAdjustmentData.maximum;
            }
            if (this.bidPriceAdjustmentData.changeAmount) {
                bidPriceAdjustmentFromModelGroup.amount = Math.abs(this.bidPriceAdjustmentData.changeAmount);
            }
            if (this.bidPriceAdjustmentData.changeAmount) {
                bidPriceAdjustmentFromModelGroup.amountSign = this.bidPriceAdjustmentData.changeAmount > 0 ? '+' : '-';
            }
            if (this.bidPriceAdjustmentData.changePercent) {
                bidPriceAdjustmentFromModelGroup.numbersSign = this.bidPriceAdjustmentData.changePercent > 0 ? '+' : '-';
            }
            if (this.bidPriceAdjustmentData.changePercent) { 
                bidPriceAdjustmentFromModelGroup.numbers = Math.abs(this.bidPriceAdjustmentData.changePercent);
            }
            this.bidPriceAdjustmentData.bidPrice ?  this.enableDisableFields(this.bidPriceAdjustmentData.bidPrice) : null;
            const bidPriceSeats = [];
            if (this.bidPriceAdjustmentData.seats) {
                for (const bidSeats of this.bidPriceAdjustmentData.seats) {
                    const bidPriceSeat = {} as BidSeat;
                    if (bidSeats.endSeat) {
                        bidPriceSeat.gsaRange = bidSeats.startSeat + '-' + bidSeats.endSeat;
                        bidPriceSeat.gsaRangeOperator = bidSeats.seatsRestriction;
                    } else {
                        bidPriceSeat.gsaNumber = bidSeats.startSeat;
                        bidPriceSeat.gsaOperator = bidSeats.seatsRestriction;
                    }
                    bidPriceSeats.push(bidPriceSeat);
                }
            } else {
                const bidPriceSeat = {} as BidSeat;
                bidPriceSeats.push(bidPriceSeat);
            }
            this.cabinViewData = this.bidPriceAdjustmentData.cabin;
            bidPriceAdjustmentFromModelGroup.gsaGroupUnit = bidPriceSeats;
            bidPriceAdjustmentFromModelGroupData.push(bidPriceAdjustmentFromModelGroup);
        }

        const bidPriceAdjustmentFromModel = {
            bidPriceAdjustmentUnit: bidPriceAdjustmentFromModelGroupData
        } as BidPriceAdjustmentComponentForm;

        if (bidPriceAdjustmentFromModel) {
            this.setFormValues(bidPriceAdjustmentFromModel);
        }
    }

    private setFormValues(bidPriceAdjustmentFromModel: BidPriceAdjustmentComponentForm) {
        const bidPriceAdjustmentUnitLength = bidPriceAdjustmentFromModel.bidPriceAdjustmentUnit.length;
        const controlBidPriceAdjustmentUnit = this.bidPriceAdjustmentForm.get('bidPriceAdjustmentUnit') as FormArray;
        let i: number;
        let j: number;
        // generate fields for marketLogic Unit
        for (i = 0; i < bidPriceAdjustmentUnitLength; i++) {
            controlBidPriceAdjustmentUnit.push(this.createBidPriceAdjustFormGroup());
        }
        controlBidPriceAdjustmentUnit.removeAt(i);
        i = 0;
        for (const bidPriceAdjustmentUnit of bidPriceAdjustmentFromModel.bidPriceAdjustmentUnit) {
            j = 0;
            const controlGsaGroupUnit = this.bidPriceUnit.controls[i].get('gsaGroupUnit') as FormArray;
            for (const gsaGroupUnit of bidPriceAdjustmentUnit.gsaGroupUnit) {
                if (gsaGroupUnit.gsaNumber) {
                    controlGsaGroupUnit.controls[j].get('gsaRange').disable();
                    controlGsaGroupUnit.controls[j].get('gsaRangeOperator').disable();
                } else if (gsaGroupUnit.gsaRange) {
                    controlGsaGroupUnit.controls[j].get('gsaNumber').disable();
                    controlGsaGroupUnit.controls[j].get('gsaOperator').disable();
                }
                controlGsaGroupUnit.push(this.createGsaFormGroup());
                j++;
            }
            this.removeGsaGroupUnit(i, j);
            i++;
        }
        (this.bidPriceAdjustmentForm as FormGroup).patchValue(bidPriceAdjustmentFromModel, { onlySelf: true });
    }
}
