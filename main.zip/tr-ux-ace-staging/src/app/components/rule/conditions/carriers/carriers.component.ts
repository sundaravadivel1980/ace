import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { CarrierComponentForm, CarrierFormGroup } from '../../../../models/rule-form.model';
import { CarrierCondition, Rule } from '@dxc/tr-ux-ace-services/dist/lib';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, DropdownModel } from '../../../../models/rule-form.model';
import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppUtil } from '../../../../utility/app-util';

@Component({
    selector: 'carriers',
    templateUrl: 'carriers.component.html',
    styleUrls: ['./carriers.component.scss']
})
export class CarriersComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public carriersForm: FormGroup;
    private carrierConditionDataArray: CarrierCondition[];

    private carriersList: DropdownModel[];
    private operators: DropdownModel[];

    private isEmptyCondition: boolean = false;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
        const data = singletonService.ruleJsonStore;
        this.operators = data.Operators;
    }

    public ngOnInit() {
        const groupList = GroupType.getGroupList('Carrier Grouping', this.singletonService.groupTypes);
        const airlineList = CarrierConfig.getAirlines(this.singletonService.airlines);
        // show both the carrier and group in the dropdown
        this.carriersList = groupList.concat(airlineList) as DropdownModel[];

        this.carriersForm = this.fb.group({
            carrierLogicalUnits: this.fb.array([this.createCarrierFormGroup()])
        });

        this.setValues();
    }

    public addCarrierFormGroup() {
        const carrierFormArray = this.carriersForm.get('carrierLogicalUnits') as FormArray;
        carrierFormArray.push(this.createCarrierFormGroup());
    }

    public removeCarrierFormGroup(i: number) {
        const carrierFormArray = this.carriersForm.get('carrierLogicalUnits') as FormArray;
        carrierFormArray.removeAt(i);
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.carrierConditionDataArray = RuleUtil.getComponenetData(rule, 'carrierCondition');
        }
        if (this.carrierConditionDataArray && this.carrierConditionDataArray.length > 0) {
            this.setFormValuesFromData(this.carrierConditionDataArray);
        }
    }

    public validate() {
       this.removeEmptyForms();
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const carrierFormUnit of this.carriersFormArray.controls) {
            let emptyForm = true;
            if (AppUtil.isArrayValueExists(carrierFormUnit, 'marketing')
              || AppUtil.isArrayValueExists(carrierFormUnit, 'operating')) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i) ;
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()) {
            this.removeCarrierFormGroup(emptyFormGroup);
        }
        if (this.carriersFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addCarrierFormGroup();
        }
    }

    public getValues(): CarrierCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }
        const carrierConditionArray = [];
        for (const carrierFormUnit of this.carriersFormArray.value) {
            carrierConditionArray.push({
                comparator: carrierFormUnit.operator,
                marketing: carrierFormUnit.marketing ? carrierFormUnit.marketing : [],
                operating: carrierFormUnit.operating ? carrierFormUnit.operating : []
            } as CarrierCondition);
        }

        return carrierConditionArray;
    }

    get carriersFormArray(): FormArray {
        return this.carriersForm.get('carrierLogicalUnits') as FormArray;
    }

    private setFormValuesFromData(carrierConditionDataArray: CarrierCondition[]) {
        const carrierFormUnitArray = [];
        for (const carrierConditionData of carrierConditionDataArray) {
            const carrierFormUnit = new CarrierFormGroup();
            carrierFormUnit.operator = carrierConditionData.comparator;
            carrierConditionData.marketing ? carrierFormUnit.marketing = carrierConditionData.marketing
                : carrierFormUnit.marketing = '';
            carrierConditionData.operating ? carrierFormUnit.operating = carrierConditionData.operating
                : carrierFormUnit.operating = '';
            carrierFormUnitArray.push(carrierFormUnit);
        }

        const carrierFormModel = {
            carrierLogicalUnits: carrierFormUnitArray
        } as CarrierComponentForm;

        if (carrierFormModel) {
            this.setFormValues(carrierFormModel);
        }
    }

    private setFormValues(carrierFormGroup: CarrierComponentForm) {
        const carrierFormArray = this.carriersForm.get('carrierLogicalUnits') as FormArray;
        for (const carrierFormUnit of carrierFormGroup.carrierLogicalUnits) {
            carrierFormArray.push(this.createCarrierFormGroup());
        }
        this.removeCarrierFormGroup(0);
        (this.carriersForm).patchValue(carrierFormGroup, { onlySelf: true });
    }

    private createCarrierFormGroup() {
        return this.fb.group({
            operator: ['EQ'],
            marketing: [''],
            operating: ['']
        });
    }
}
