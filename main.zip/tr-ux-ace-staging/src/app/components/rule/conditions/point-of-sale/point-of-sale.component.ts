import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { Rule, PointOfSaleCondition } from '@dxc/tr-ux-ace-services/dist/lib';

import {
    PointOfSaleComponentForm,
    PointOfSaleFormGroup,
    RuleDetailChildForm,
    DropdownModel } from '../../../../models/rule-form.model';
import { RuleUtil } from '../../rule.util.ts';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppSingletonService } from '../../../../app-singleton.service';

@Component({
    selector: 'point-of-sale',
    templateUrl: 'point-of-sale.component.html',
    styleUrls: ['./point-of-sale.component.scss']
})

export class PointOfSaleComponent implements  RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public pointOfSaleGroup: FormGroup;
    public pointOfSaleComponentData: PointOfSaleCondition[];

    public operators: any[];
    private expansionTitle: string = 'Show More';

    /** POS Group Name */
    private groupName: DropdownModel[];
    /** Business ID */
    private businessID: DropdownModel[];
    /** Airline/GDS Code */
    private airlineGds: DropdownModel[];
    /** Geographical City Code */
    private geographicalCode: DropdownModel[];
    /** Country Code */
    private countryCode: DropdownModel[];
    /** User type */
    private userType: DropdownModel[];
    /** GDS/OA City Code */
    private iataCityCode: DropdownModel[];
    /** Originating System */
    private airlineCode: DropdownModel[];
    /** Currency Code */
    private currencyCode: DropdownModel[];

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
        const data = singletonService.ruleJsonStore;
        this.operators = data.Operators;
        // POS group list
        this.groupName = data.POSgroupName;
        // Business id list
        this.businessID = data.POSbusinessID;
        this.userType = data.POSuserType;
    }

    public ngOnInit() {
        this.countryCode = CarrierConfig.getCountryList(this.singletonService.countires)  as DropdownModel[];
        this.currencyCode = CarrierConfig.getCurrencyList(this.singletonService.currencies)  as DropdownModel[];
         // airlineGds (Airline/GDS), airlineCode (Originating system)
        const airlinesList = CarrierConfig.getAirlines(this.singletonService.airlines);
        this.airlineGds = airlinesList;
        this.airlineCode = airlinesList;
        // for geographicalCode (Geographical city code), iataCityCode (GDS/other airline city code)
        const airportList = CarrierConfig.getAiportsList(this.singletonService.airports)  as DropdownModel[];
        this.geographicalCode = airportList;
        this.iataCityCode = airportList;

        this.pointOfSaleGroup = this.fb.group({
            pointOfSaleLogicalUnit: this.fb.array([this.createpointOfSaleLogicalUnit()])
        });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.pointOfSaleComponentData = RuleUtil.getComponenetData(rule, 'pointOfSaleCondition');
        }
        if ( this.pointOfSaleComponentData && this.pointOfSaleComponentData.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): PointOfSaleCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        const posConditionArray = [];
        for (const posFormUnit of this.posFormArray.value) {
            const pointOfSaleConditionalData = {} as PointOfSaleCondition;
            pointOfSaleConditionalData.comparator = posFormUnit.operator;
            if ( posFormUnit.businessID ) { pointOfSaleConditionalData.businessId = posFormUnit.businessID; }
            if ( posFormUnit.airlineGds ) { pointOfSaleConditionalData.carrierOrGds = posFormUnit.airlineGds; }
            if ( posFormUnit.communicationNumber ) {
                pointOfSaleConditionalData.communicationNumber = posFormUnit.communicationNumber;
            }
            if ( posFormUnit.countryCode ) { pointOfSaleConditionalData.country = posFormUnit.countryCode; }
            if ( posFormUnit.currencyCode ) { pointOfSaleConditionalData.currency = posFormUnit.currencyCode; }
            if ( posFormUnit.airlineCode ) {
                pointOfSaleConditionalData.originatingSystem = posFormUnit.airlineCode;
            }
            if ( posFormUnit.iataCityCode ) { pointOfSaleConditionalData.gdsOaCity = posFormUnit.iataCityCode; }
            if ( posFormUnit.geographicalCode ) {
                pointOfSaleConditionalData.geographicalCity = posFormUnit.geographicalCode;
            }
            if ( posFormUnit.iataNumber ) { pointOfSaleConditionalData.iataNumber = posFormUnit.iataNumber; }
            if ( posFormUnit.requestCode ) {
                pointOfSaleConditionalData.originatorsRequest = posFormUnit.requestCode;
            }
            if ( posFormUnit.groupName ) { pointOfSaleConditionalData.posGrouping = posFormUnit.groupName; }
            if ( posFormUnit.inhouseID ) { pointOfSaleConditionalData.region = posFormUnit.inhouseID; }
            if ( posFormUnit.userType ) { pointOfSaleConditionalData.userType = posFormUnit.userType; }
            if ( posFormUnit.pseudoCode ) { pointOfSaleConditionalData.pseudoCity = posFormUnit.pseudoCode; }
            posConditionArray.push(pointOfSaleConditionalData);
        }
        return posConditionArray;
    }

    public validate() {
       this.removeEmptyForms();
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const posFormUnit of this.posFormArray.controls) {
            let emptyForm = true;
            if ( posFormUnit.get('businessID').value.length > 0  || posFormUnit.get('airlineGds').value.length > 0 ||
                posFormUnit.get('communicationNumber').value.length > 0 || posFormUnit.get('countryCode').value.length > 0  ||
                posFormUnit.get('currencyCode').value.length > 0  || posFormUnit.get('airlineCode').value.length > 0  ||
                posFormUnit.get('iataCityCode').value.length > 0  || posFormUnit.get('geographicalCode').value.length > 0  ||
                posFormUnit.get('iataNumber').value.length > 0 || posFormUnit.get('requestCode').value.length > 0 ||
                posFormUnit.get('groupName').value.length > 0 || posFormUnit.get('pseudoCode').value.length > 0 ||
                posFormUnit.get('inhouseID').value.length > 0 || posFormUnit.get('userType').value.length > 0) {
                    emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()){
            this.removePointOfSaleLogicalUnit(emptyFormGroup);
        }
        if (this.posFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addPointOfSaleLogicalUnit();
        }
    }

    get posFormArray(): FormArray{
        return this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
    }

    private addPointOfSaleLogicalUnit() {
        const control = this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
        control.push(this.createpointOfSaleLogicalUnit());
    }

    private removePointOfSaleLogicalUnit(i: number) {
        const control = this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
        control.removeAt(i);
    }

    get posAsArray(): FormArray{
        return this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
    }

    private createpointOfSaleLogicalUnit() {
        return this.fb.group({
            operator: 'EQ',
            groupName: [''],
            businessID: [''],
            airlineGds: [''],
            iataNumber: [''],
            pseudoCode: [''],
            geographicalCode : [''],
            countryCode: [''],
            userType: [''],
            iataCityCode: [''],
            airlineCode: [''],
            currencyCode: [''],
            requestCode: [''],
            communicationNumber: [''],
            inhouseID: ['']
        });
    }

    private setFormValuesFromData() {
        const pointOfSaleLogicalUnitArray = [];
        for (const pointOfSaleLogicalUnitData of this.pointOfSaleComponentData) {
            const pointOfSaleLogicalUnit = {} as PointOfSaleFormGroup;
            pointOfSaleLogicalUnit.operator = pointOfSaleLogicalUnitData.comparator ? pointOfSaleLogicalUnitData.comparator : '';
            pointOfSaleLogicalUnit.businessID = pointOfSaleLogicalUnitData.businessId ? pointOfSaleLogicalUnitData.businessId : '';
            pointOfSaleLogicalUnit.airlineGds = pointOfSaleLogicalUnitData.carrierOrGds ? pointOfSaleLogicalUnitData.carrierOrGds : '';
            pointOfSaleLogicalUnit.communicationNumber = pointOfSaleLogicalUnitData.communicationNumber ?
             pointOfSaleLogicalUnitData.communicationNumber : '';
            pointOfSaleLogicalUnit.countryCode = pointOfSaleLogicalUnitData.country ? pointOfSaleLogicalUnitData.country : '';
            pointOfSaleLogicalUnit.currencyCode = pointOfSaleLogicalUnitData.currency ? pointOfSaleLogicalUnitData.currency : '';
            pointOfSaleLogicalUnit.airlineCode = pointOfSaleLogicalUnitData.originatingSystem ? pointOfSaleLogicalUnitData.originatingSystem : '';
            pointOfSaleLogicalUnit.iataCityCode = pointOfSaleLogicalUnitData.gdsOaCity ? pointOfSaleLogicalUnitData.gdsOaCity : '';
            pointOfSaleLogicalUnit.geographicalCode = pointOfSaleLogicalUnitData.geographicalCity ? pointOfSaleLogicalUnitData.geographicalCity : '';
            pointOfSaleLogicalUnit.iataNumber = pointOfSaleLogicalUnitData.iataNumber ? pointOfSaleLogicalUnitData.iataNumber : '';
            pointOfSaleLogicalUnit.requestCode = pointOfSaleLogicalUnitData.originatorsRequest ? pointOfSaleLogicalUnitData.originatorsRequest : '';
            pointOfSaleLogicalUnit.groupName = pointOfSaleLogicalUnitData.posGrouping ? pointOfSaleLogicalUnitData.posGrouping : '';
            pointOfSaleLogicalUnit.inhouseID = pointOfSaleLogicalUnitData.region ? pointOfSaleLogicalUnitData.region : '';
            pointOfSaleLogicalUnit.userType = pointOfSaleLogicalUnitData.userType ? pointOfSaleLogicalUnitData.userType : '';
            pointOfSaleLogicalUnit.pseudoCode = pointOfSaleLogicalUnitData.pseudoCity ? pointOfSaleLogicalUnitData.pseudoCity : '';

            pointOfSaleLogicalUnitArray.push(pointOfSaleLogicalUnit);
        }
        const pointOfSaleComponentFormModel = {
            pointOfSaleLogicalUnit: pointOfSaleLogicalUnitArray
        } as PointOfSaleComponentForm;
        if (pointOfSaleComponentFormModel) {
            this.setFormValues(pointOfSaleComponentFormModel);
        }
    }

    private setFormValues(pointOfSaleComponentFormModel: PointOfSaleComponentForm) {
        const control = this.pointOfSaleGroup.get('pointOfSaleLogicalUnit') as FormArray;
        for (const pointOfSaleLogicalUnit of pointOfSaleComponentFormModel.pointOfSaleLogicalUnit){
            control.push(this.createpointOfSaleLogicalUnit());
        }
        this.removePointOfSaleLogicalUnit(0);
        (this.pointOfSaleGroup as FormGroup).patchValue(pointOfSaleComponentFormModel, { onlySelf: true });
    }
}
