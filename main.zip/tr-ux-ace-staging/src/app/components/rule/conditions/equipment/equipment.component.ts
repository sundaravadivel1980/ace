import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { EquipmentCondition, Rule } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { DropdownModel, RuleDetailChildForm, EquipmentComponentForm, EquipmentFormGroup } from '../../../../models/rule-form.model';
import { RuleUtil } from '../../rule.util.ts';
import { AppConstants } from 'src/app/app.constants';

@Component({
    selector: 'equipment',
    templateUrl: 'equipment.component.html',
    styleUrls: ['./equipment.component.scss']
})

export class EquipmentComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;
    public equipmentForm: FormGroup;

    public operators: DropdownModel[];
    public configuration: DropdownModel[] = [];
    public iataCode: DropdownModel[] = [];

    private equipmencondDataArray: EquipmentCondition[];

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
        this.operators = singletonService.ruleJsonStore.Operators;
    }
    public ngOnInit() {
        this.configuration = this.singletonService.equipmentConfigList;
        this.iataCode = this.singletonService.equipmentCodeList;
        this.equipmentForm = this.fb.group({equipmentArray: this.fb.array([this.createEquipmentFormGroup()])});
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.equipmencondDataArray = RuleUtil.getComponenetData(rule, 'equipmentCondition');
        }
        if ( this.equipmencondDataArray && this.equipmencondDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): EquipmentCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        const equipmentConditionalData = [];
        for (const equipmentFormUnit of this.equipmentArray.value) {
            equipmentConditionalData.push( {
                comparator: equipmentFormUnit.operators,
                configCode: equipmentFormUnit.configuration ? equipmentFormUnit.configuration : [],
                iataCode: equipmentFormUnit.iataCode ? equipmentFormUnit.iataCode : []
            } as EquipmentCondition);
        }
        return equipmentConditionalData;
    }

    public validate() {
       this.removeEmptyForms();
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const equipmentFormUnit of this.equipmentArray.controls) {
            let emptyForm = true;
            if (equipmentFormUnit.get('iataCode').value || equipmentFormUnit.get('configuration').value) {
                emptyForm = false;
            }
            if (emptyForm) {
              emptyForms.push(i);
            }
            i++;
        }
        for (const emptyForm of emptyForms.reverse()){
            this.removeEquipmentArray(emptyForm);
        }
        if (this.equipmentArray.length === 0) {
            this.isEmptyCondition = true;
            this.addEquipmentArray();
        }
    }

    public createEquipmentFormGroup() {
        return this.fb.group({
            operators: ['EQ', Validators.required],
            iataCode: ['', Validators.required],
            configuration: ['', Validators.required]
        });
    }
    get equipmentArray(){
        return this.equipmentForm.get('equipmentArray') as FormArray;
    }
    public addEquipmentArray() {
        this.equipmentArray.push(this.createEquipmentFormGroup());
    }
    public removeEquipmentArray(i: number) {
        this.equipmentArray.removeAt(i);
    }

    private setFormValuesFromData() {
        const equipmentLogicalUnitArray = [];
        for (const equipmentLogicalUnitData of this.equipmencondDataArray) {
            const equipmentLogicalUnit = {
                operators: equipmentLogicalUnitData.comparator,
                configuration: equipmentLogicalUnitData.configCode,
                iataCode: equipmentLogicalUnitData.iataCode
            } as EquipmentFormGroup;
            equipmentLogicalUnitArray.push(equipmentLogicalUnit);
        }
        const equipmentComponentFormModel = {
            equipmentArray: equipmentLogicalUnitArray
        } as EquipmentComponentForm;
        if (equipmentComponentFormModel) {
            this.setFormValues(equipmentComponentFormModel);
        }
    }

    private setFormValues(equipmentFromModel: EquipmentComponentForm) {
        const control = this.equipmentForm.get('equipmentArray') as FormArray;
        for (const pointOfCommencementLogicalUnit of equipmentFromModel.equipmentArray){
            control.push(this.createEquipmentFormGroup());
        }
        this.removeEquipmentArray(0);
        (this.equipmentForm as FormGroup).patchValue(equipmentFromModel, { onlySelf: true });
    }
}
