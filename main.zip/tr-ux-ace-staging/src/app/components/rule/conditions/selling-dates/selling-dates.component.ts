import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';

import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, SellingDateTimeComponentForm, DateTimeFormGroup } from '../../../../models/rule-form.model';
import { DropdownModel } from '../../../../models/rule-form.model';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

@Component({
    selector: 'selling-dates',
    templateUrl: 'selling-dates.component.html',
    styleUrls: ['./selling-dates.component.scss']
})
export class SellingDatesComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;
    @Input() public timeUnitCount = 0;
    @Output() public timeUnitCountChange = new EventEmitter();

    public sellingDateGroup: FormGroup;
    public sellingDateTimeCondDataArray: DateTimeCondition[];

    public operators: DropdownModel[];
    public days: DropdownModel[];
    public minDate = new Date();
    public minEndDate = new Date();
    public startMaxDate: any;
    public carrierPrefDateFormat: string;
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private appSingletonService: AppSingletonService,
                private datePipe: DatePipe,
                private validationService: RuleValidationService) {
        this.operators = this.appSingletonService.ruleJsonStore.Operators;
        this.days = this.appSingletonService.ruleJsonStore.Days;
    }

    public ngOnInit() {
        this.carrierPrefDateFormat = this.appSingletonService.carrierDateFormat;

        this.sellingDateGroup = this.fb.group({
            sellingDateArray: this.fb.array([this.createSellingDateFormGroup()])
        });
        this.setValues();
    }

    public setEndDate(event: MatDatepickerInputEvent<Date>) {
        this.minEndDate = event.value;
        this.startMaxDate = '';
    }

    public setStartDate(event: MatDatepickerInputEvent<Date>) {
        this.startMaxDate = event.value;
    }

    public createSellingDateFormGroup() {
        return this.fb.group({
            allDay: ['true'],
            monday: [''],
            tuesday: [''],
            wednesday: [''],
            thursday: [''],
            friday: [''],
            saturday: [''],
            sunday: [''],
            operators: 'EQ',
            startDate: '',
            startHour: '',
            startMinute: '',
            endDate: '',
            endHour: '',
            endMinute: ''
        });
    }

    get sellingDateFormArray() {
        return this.sellingDateGroup.get('sellingDateArray') as FormArray;
    }

    public addSellingDates() {
        this.sellingDateFormArray.push(this.createSellingDateFormGroup());
        this.timeUnitCount++;
        this.timeUnitCountChange.emit(this.timeUnitCount);
        this.selectAllDays(this.timeUnitCount);
    }

    public removeSellingDates(i: number) {
        this.sellingDateFormArray.removeAt(i);
        this.timeUnitCount--;
    }

    public selectAllDays(i) {
        for (const item of this.days) {
            this.sellingDateFormArray.controls[i].get(item.id).setValue(
                this.sellingDateFormArray.controls[i].get('allDay').value
            );
        }
    }

    public selectDay(i) {
        const selectedDays = [];
        for (const item of this.days) {
            selectedDays.push(this.sellingDateFormArray.controls[i].get(item.id).value);
        }
        this.sellingDateFormArray.controls[i].get('allDay').setValue(
            selectedDays.every(function(value: boolean){
                return value === true;
            })
        );
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.sellingDateTimeCondDataArray = RuleUtil.getComponenetData(rule, 'sellingDateTimeCondition');
        }
        if ( this.sellingDateTimeCondDataArray && this.sellingDateTimeCondDataArray.length > 0 ) {
            this.setFormValuesFromData();
        } else {
            this.selectAllDays(0);
        }
    }

    public getValues() {

        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        // Array of values to be sent in the rule request to service
        const sellingDateConditionArray = [];

        for (const sellDateFormUnit of this.sellingDateFormArray.value) {
            const daysArray = [];
            if (sellDateFormUnit.allDay) {
                daysArray.push('ALL');
            } else {
                if (sellDateFormUnit.monday) { daysArray.push('MON'); }
                if (sellDateFormUnit.tuesday) { daysArray.push('TUE'); }
                if (sellDateFormUnit.wednesday) { daysArray.push('WED'); }
                if (sellDateFormUnit.thursday) { daysArray.push('THU'); }
                if (sellDateFormUnit.friday) { daysArray.push('FRI'); }
                if (sellDateFormUnit.saturday) { daysArray.push('SAT'); }
                if (sellDateFormUnit.sunday) { daysArray.push('SUN'); }
            }
            let dateAndTime: DateOrRange;
            if (sellDateFormUnit.startDate || sellDateFormUnit.endDate || sellDateFormUnit.startHour ||
                sellDateFormUnit.startMinute || sellDateFormUnit.endHour || sellDateFormUnit.endMinute) {
                dateAndTime = new DateOrRange();

                if (sellDateFormUnit.startDate) {
                    dateAndTime.startDateTime = this.datePipe.transform(sellDateFormUnit.startDate, 'yyyy-MM-dd') + 'T'
                    + sellDateFormUnit.startHour + ':' + sellDateFormUnit.startMinute + ':00';
                } else if (sellDateFormUnit.startHour || sellDateFormUnit.startMinute) {
                    dateAndTime.startDateTime = 'T' + sellDateFormUnit.startHour + ':' + sellDateFormUnit.startMinute + ':00';
                }
                if (sellDateFormUnit.endDate) {
                    dateAndTime.endDateTime =  this.datePipe.transform(sellDateFormUnit.endDate, 'yyyy-MM-dd') +
                    'T' + sellDateFormUnit.endHour + ':' + sellDateFormUnit.endMinute + ':00';
                } else if (sellDateFormUnit.endHour || sellDateFormUnit.endMinute) {
                    dateAndTime.endDateTime = 'T' + sellDateFormUnit.endHour + ':' + sellDateFormUnit.endMinute + ':00';
                }
            }
            sellingDateConditionArray.push( {
                comparator: sellDateFormUnit.operators,
                dayOfWeek: daysArray,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return sellingDateConditionArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

         // Validate only when user given the input
        if (!this.isEmptyCondition) {
            for (const sellingDateFormUnit of this.sellingDateFormArray.controls) {
                if (!sellingDateFormUnit.get('allDay').value
                            && !sellingDateFormUnit.get('friday').value
                            && !sellingDateFormUnit.get('monday').value
                            && !sellingDateFormUnit.get('saturday').value
                            && !sellingDateFormUnit.get('sunday').value
                            && !sellingDateFormUnit.get('thursday').value
                            && !sellingDateFormUnit.get('tuesday').value
                            && !sellingDateFormUnit.get('wednesday').value) {
                                this.hasErrors = true;
                                this.validationService.addGlobalError('acegui.rules.messages.days.required');
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        // Remove the selling dates component from the array when there is no day selected
        for (const sellDateFormUnit of this.sellingDateFormArray.controls) {
            let emptyForm = true;
            if (sellDateFormUnit.get('allDay').value
                 || sellDateFormUnit.get('friday').value
                 || sellDateFormUnit.get('monday').value
                 || sellDateFormUnit.get('saturday').value
                 || sellDateFormUnit.get('sunday').value
                 || sellDateFormUnit.get('thursday').value
                 || sellDateFormUnit.get('tuesday').value
                 || sellDateFormUnit.get('wednesday').value
                 || sellDateFormUnit.get('startHour').value
                 || sellDateFormUnit.get('startMinute').value
                 || sellDateFormUnit.get('startDate').value
                 || sellDateFormUnit.get('endHour').value
                 || sellDateFormUnit.get('endMinute').value
                 || sellDateFormUnit.get('endDate').value) {
                    emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i) ;
            }
            i++;
        }
        for (const emptyFormGroup of emptyForms.reverse()){
            this.removeSellingDates(emptyFormGroup);
        }
        if (this.sellingDateFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addSellingDates();
        }
    }

    private setFormValuesFromData() {
        const sellingDateTimeFormUnitArray = [];

        for ( const sellingDateTimeDataUnit of this.sellingDateTimeCondDataArray) {

            let startDateTimeSplit = [];
            let startTimeSplit = [];
            if (sellingDateTimeDataUnit.dateOrRange && sellingDateTimeDataUnit.dateOrRange.startDateTime) {
                startDateTimeSplit =  sellingDateTimeDataUnit.dateOrRange.startDateTime.split('T');
                if (startDateTimeSplit[1]) {
                    startTimeSplit =  startDateTimeSplit[1].split(':');
                }
            }

            let endDateTimeSplit = [];
            let endTimeSplit = [];
            if (sellingDateTimeDataUnit.dateOrRange && sellingDateTimeDataUnit.dateOrRange.endDateTime) {
                endDateTimeSplit = sellingDateTimeDataUnit.dateOrRange.endDateTime.split('T');
                if (endDateTimeSplit[1]) {
                    endTimeSplit = endDateTimeSplit[1].split(':');
                }
            }

            const sellDateTimeFormUnit = {
                operators: sellingDateTimeDataUnit.comparator,
                startDate: startDateTimeSplit[0],
                startHour: startTimeSplit[0],
                startMinute: startTimeSplit[1],
                endDate: endDateTimeSplit[0],
                endHour: endTimeSplit[0],
                endMinute: endTimeSplit[1]
            } as DateTimeFormGroup;

            if (sellingDateTimeDataUnit.dayOfWeek) {
                for ( const dayWeek of sellingDateTimeDataUnit.dayOfWeek) {
                    switch (dayWeek) {
                        case 'ALL':
                            sellDateTimeFormUnit.allDay = true;
                            sellDateTimeFormUnit.monday = true;
                            sellDateTimeFormUnit.tuesday = true;
                            sellDateTimeFormUnit.wednesday = true;
                            sellDateTimeFormUnit.thursday = true;
                            sellDateTimeFormUnit.friday = true;
                            sellDateTimeFormUnit.saturday = true;
                            sellDateTimeFormUnit.sunday = true;
                            break;
                        case 'MON':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.monday = true;
                            break;
                        case 'TUE':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.tuesday = true;
                            break;
                        case 'WED':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.wednesday = true;
                            break;
                        case 'THU':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.thursday = true;
                            break;
                        case 'FRI':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.friday = true;
                            break;
                        case 'SAT':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.saturday = true;
                            break;
                        case 'SUN':
                            sellDateTimeFormUnit.allDay = false;
                            sellDateTimeFormUnit.sunday = true;
                            break;
                    }
                }
            }
            sellingDateTimeFormUnitArray.push(sellDateTimeFormUnit);
        }

        const sellingDateTimeFormModel = {
            sellingDateArray: sellingDateTimeFormUnitArray
        } as SellingDateTimeComponentForm;

        if (sellingDateTimeFormModel) {
            this.setFormValues(sellingDateTimeFormModel);
        }
    }

    private setFormValues(depatureDateTimeFormModel: SellingDateTimeComponentForm) {
        const sellingDateFormArray = this.sellingDateGroup.get('sellingDateArray') as FormArray;
        for (const sellingDateFormUnit of depatureDateTimeFormModel.sellingDateArray){
            sellingDateFormArray.push(this.createSellingDateFormGroup());
        }
        this.removeSellingDates(0);
        (this.sellingDateGroup as FormGroup).patchValue(depatureDateTimeFormModel, { onlySelf: true });
    }

}
