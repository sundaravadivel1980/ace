import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { Rule, TimeDepartureCondition, Time } from '@dxc/tr-ux-ace-services/dist/lib';

import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, TimeToDepartureComponentForm, DaysAndHoursFormGroup } from '../../../../models/rule-form.model';

@Component({
    selector: 'time-to-departure',
    templateUrl: 'time-to-departure.component.html',
    styleUrls: ['./time-to-departure.component.scss']
})

export class TimeToDepartureComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public timeToDepartureForm: FormGroup;
    private timeToDepartureDataArray: TimeDepartureCondition[];

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder) {
    }

    public ngOnInit() {
        this.timeToDepartureForm = this.fb.group({
            timeToDepartureUnit: this.fb.array([this.createTimeToDepartureFormGroup()])
        });
        this.setValues();
    }

    public createTimeToDepartureFormGroup() {
        return this.fb.group({
            days: [''],
            hours: [''],
            minutes: ['']
        });
    }

    get timeToDepartureArray(): FormArray {
        return this.timeToDepartureForm.get('timeToDepartureUnit') as FormArray;
    }

    public addTimeToDeparture() {
        this.timeToDepartureArray.push(this.createTimeToDepartureFormGroup());
    }

    public removeTimeToDeparture(i: number) {
        this.timeToDepartureArray.removeAt(i);
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.timeToDepartureDataArray = RuleUtil.getComponenetData(rule, 'timeToDepartureCondition');
        }
        if ( this.timeToDepartureDataArray && this.timeToDepartureDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): TimeDepartureCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        const timeToDepartureCondDataArray = [];
        for (const timeToDepartureFormUnit of this.timeToDepartureArray.value) {
            let timeData: any;
            timeData = {
                days: timeToDepartureFormUnit.days,
                hours: timeToDepartureFormUnit.hours,
                minutes: timeToDepartureFormUnit.minutes
            } as Time;
            timeToDepartureCondDataArray.push( {
                comparator: 'EQ',
                time: timeData
            } as TimeDepartureCondition);
        }
        return timeToDepartureCondDataArray;
    }

    public validate() {
        this.removeEmptyForms();
        this.hasErrors = false;
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyGroups = [];
        this.isEmptyCondition = false;

        for (const timeToDepartFormUnit of this.timeToDepartureArray.controls) {
            let emptyForm = true;
            if (timeToDepartFormUnit.get('days').value || timeToDepartFormUnit.get('hours').value || timeToDepartFormUnit.get('minutes').value) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyGroups.push(i);
            }
            i++;
        }
        for (const emptyGroup of emptyGroups.reverse()){
            this.removeTimeToDeparture(emptyGroup);
        }
        if (this.timeToDepartureArray.length === 0) {
            this.isEmptyCondition = true;
            this.addTimeToDeparture();
        }
    }

    private setFormValuesFromData() {
        const timeToDepartFormArray = [];

        for ( const timeToDepartureDataUnit of this.timeToDepartureDataArray) {
            const timeToDepartFormUnit =  {
                days: timeToDepartureDataUnit.time.days,
                hours: timeToDepartureDataUnit.time.hours,
                minutes: timeToDepartureDataUnit.time.minutes
            } as DaysAndHoursFormGroup;
            timeToDepartFormArray.push(timeToDepartFormUnit);
        }

        const timeToDepartComponentForm = {
            timeToDepartureUnit: timeToDepartFormArray
        } as TimeToDepartureComponentForm;

        if (timeToDepartComponentForm) {
            this.setFormValues(timeToDepartComponentForm);
        }
    }

    private setFormValues(timeDepartureFromModel: TimeToDepartureComponentForm) {
        const timeToDepartFormArray = this.timeToDepartureForm.get('timeToDepartureUnit') as FormArray;
        for (const timeToDepartFormUnit of timeDepartureFromModel.timeToDepartureUnit){
            timeToDepartFormArray.push(this.createTimeToDepartureFormGroup());
        }
        this.removeTimeToDeparture(0);
        (this.timeToDepartureForm as FormGroup).patchValue(timeDepartureFromModel, { onlySelf: true });
    }
}
