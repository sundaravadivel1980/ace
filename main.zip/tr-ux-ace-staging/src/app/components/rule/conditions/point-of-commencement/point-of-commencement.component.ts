import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { AppSingletonService } from '../../../../app-singleton.service';
import { Rule, PointOfCommencementCondition } from '@dxc/tr-ux-ace-services/dist/lib';

import {
    PointOfCommencementFormModel,
    PointOfCommencementFormModelGroup,
    RuleDetailChildForm,
    DropdownModel } from '../../../../models/rule-form.model';
import { RuleUtil } from '../../rule.util.ts';
import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';

@Component({
    selector: 'point-of-commencement',
    templateUrl: 'point-of-commencement.component.html',
    styleUrls: ['./point-of-commencement.component.scss']
})

export class PointOfCommencementComponent implements  RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public pointOfCommencementGroup: FormGroup;
    public pocConditionDataArray: PointOfCommencementCondition[];

    public operators: any[];
    public ruleJsonStore: any;
    public listOfAirport: DropdownModel[];

    private isEmptyCondition: boolean = false;

    constructor(private fb: FormBuilder, private singletonService: AppSingletonService) {
        this.ruleJsonStore = singletonService.ruleJsonStore;
        this.operators = this.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        const locationGroupList = GroupType.getGroupList('Location Grouping', this.singletonService.groupTypes);
        const airportList = CarrierConfig.getAiportsList(this.singletonService.airports);
        this.listOfAirport = locationGroupList.concat(airportList) as DropdownModel[];

        this.pointOfCommencementGroup = this.fb.group({
            pointOfCommencementLogicalUnit: this.fb.array([this.createpointOfCommencementLogicalUnit()])
        });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.pocConditionDataArray = RuleUtil.getComponenetData(rule, 'pointOfCommencementCondition');
        }
        if ( this.pocConditionDataArray && this.pocConditionDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): PointOfCommencementCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        const pocDataArray = [];
        for (const pocFormUnit of this.pocFormArray.value) {
            pocDataArray.push( {
                comparator: pocFormUnit.operators,
                city: pocFormUnit.location
            } as PointOfCommencementCondition);
        }
        return pocDataArray;
    }

    public validate() {
        this.removeEmptyForms();
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        // when there is no airport selected from the UI, then remove the empty condition
        for (const pointOfCommencementLogicalUnit of this.pocFormArray.controls) {
            let emptyForm = true;
            if (pointOfCommencementLogicalUnit.get('location').value.length > 0) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const removeGroup of emptyForms.reverse()){
            this.removePointOfCommencementLogicalUnit(removeGroup);
        }
        if (this.pocFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addPointOfCommencementLogicalUnit();
        }
    }

    public addPointOfCommencementLogicalUnit() {
        const control = this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
        control.push(this.createpointOfCommencementLogicalUnit());
    }

    public removePointOfCommencementLogicalUnit(i: number) {
        const control = this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
        control.removeAt(i);
    }

    get pocFormArray(): FormArray{
        return this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
    }

    private createpointOfCommencementLogicalUnit() {
        // If we get the operator list from service, then the service should return which operator is the default operator
        return this.fb.group({
            operators: 'EQ',
            location: ''
        });
    }

    private setFormValuesFromData() {
        const pocFormUnitArray = [];
        for (const pocDataUnit of this.pocConditionDataArray) {
            const pocFormUnit = {
                operators: pocDataUnit.comparator,
                location: pocDataUnit.city
            } as PointOfCommencementFormModelGroup;
            pocFormUnitArray.push(pocFormUnit);
        }
        const pocComponentForm = {
            pointOfCommencementLogicalUnit: pocFormUnitArray
        } as PointOfCommencementFormModel;

        if (pocComponentForm) {
            this.setFormValues(pocComponentForm);
        }
    }

    private setFormValues(pointOfCommencementFromModel: PointOfCommencementFormModel) {
        const control = this.pointOfCommencementGroup.get('pointOfCommencementLogicalUnit') as FormArray;
        for (const pointOfCommencementLogicalUnit of pointOfCommencementFromModel.pointOfCommencementLogicalUnit){
            control.push(this.createpointOfCommencementLogicalUnit());
        }
        this.removePointOfCommencementLogicalUnit(0);
        (this.pointOfCommencementGroup as FormGroup).patchValue(pointOfCommencementFromModel, { onlySelf: true });
    }
}
