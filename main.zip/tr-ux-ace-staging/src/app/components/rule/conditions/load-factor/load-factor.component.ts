import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators, FormControl, FormGroupDirective, NgForm } from '@angular/forms';

import { Rule, LoadFactorCondition, LoadFactorLeg, LoadFactor } from '@dxc/tr-ux-ace-services/dist/lib';

import {
    LoadFactorFormGroup,
    LFComponentFormModel,
    OriginDestinationFormGroup,
    RuleDetailChildForm,
    DropdownModel } from '../../../../models/rule-form.model';
import { RuleUtil } from '../../rule.util.ts';
import { AppSingletonService } from '../../../../app-singleton.service';
// import { RuleMessageService } from '../../../../services/rule/rule-message.service';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AbstractControl } from '@angular/forms/src/model';

@Component({
    selector: 'load-factor',
    templateUrl: 'load-factor.component.html',
    styleUrls: ['./load-factor.component.scss']
})

export class LoadFactorComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    public LdFactorForm: FormGroup;

    public cabins: DropdownModel[];
    public operators: DropdownModel[];
    private listOfAirport: DropdownModel[];

     // Will be true if there is no input value given by the user for class availability condition
     private isEmptyCondition: boolean = false;
     private hasErrors: boolean = false;

    private loadFactorComponentData: LoadFactorCondition[];

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private validationService: RuleValidationService) {
        const data = singletonService.ruleJsonStore;
        this.operators = singletonService.ruleJsonStore.LoadfactorOperators;
    }

    public ngOnInit() {
        this.cabins = CarrierConfig.getCabinList('Cabin Types', this.singletonService.carrierPreferences);
        const locationGroupList = GroupType.getGroupList('Location Grouping', this.singletonService.groupTypes);
        const cityAirportList = CarrierConfig.getAiportsList(this.singletonService.airports);
        this.listOfAirport = locationGroupList.concat(cityAirportList) as DropdownModel[];

        this.LdFactorForm = this.fb.group({LoadFactor: this.fb.array([this.createLoadFactorLogicalUnit()])});
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.loadFactorComponentData = RuleUtil.getComponenetData(rule, 'loadFactorCondition');
        }
        if ( this.loadFactorComponentData && this.loadFactorComponentData.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): LoadFactorCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        const loadFactorConditionArray = [];
        for (const ldFactorFormUnit of this.ldFormArray.value) {
            const ldFactorOriginDestFormArray = [];
            for (const originDestFormUnit of ldFactorFormUnit.originDestinations) {
                ldFactorOriginDestFormArray.push({
                    origin: originDestFormUnit.origin ? originDestFormUnit.origin : [],
                    destination: originDestFormUnit.destination ? originDestFormUnit.destination : []
                } as LoadFactorLeg);
            }

            const loadFactorCondition = new LoadFactorCondition();
            loadFactorCondition.comparator = ldFactorFormUnit.actual;
            loadFactorCondition.cabin = [ldFactorFormUnit.cabin];
            const actualInput = ldFactorFormUnit.actualInput.split('-');
            loadFactorCondition.startPercent = actualInput[0];
            if (actualInput[1]) {
                loadFactorCondition.endPercent = actualInput[1];
            }
            loadFactorCondition.leg = ldFactorOriginDestFormArray;
            loadFactorConditionArray.push(loadFactorCondition);
        }
        return loadFactorConditionArray;
    }

    get ldFormArray(): FormArray{
        return this.LdFactorForm.get('LoadFactor') as FormArray;
    }

    public isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
        return !!(control && control.invalid && (control.dirty || control.touched));
    }

    public addLoadFactorLogicalUnit() {
        const control = this.LdFactorForm.get('LoadFactor') as FormArray;
        control.push(this.createLoadFactorLogicalUnit());
    }

    public removeLoadFactorLogicalUnit(i: number) {
        const control = this.LdFactorForm.get('LoadFactor') as FormArray;
        control.removeAt(i);
    }

    public validateOriginAndDestination(originAndDestFormArray: FormArray) {
        let j: number = 0;
        const removeLocationGroups = [];
        for (const loadFactorLogicalUnitLeg of originAndDestFormArray.controls) {
            if (loadFactorLogicalUnitLeg.get('origin').value.length === 0 &&
                loadFactorLogicalUnitLeg.get('destination').value.length === 0) {
                    removeLocationGroups.push(j);
            }
            j++;
        }

        return removeLocationGroups.reverse();
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        if (!this.isEmptyCondition) {
            for (const loadFactorFormUnit of this.ldFormArray.controls) {

                if (!loadFactorFormUnit.get('cabin').value && !loadFactorFormUnit.get('actualInput').value) {
                    this.validationService.addGlobalError('acegui.rules.messages.load.factor.cabin.and.lf.mandatory');
                    this.validationService.showRequiredFieldError(loadFactorFormUnit.get('cabin'));
                    this.validationService.showRequiredFieldError(loadFactorFormUnit.get('actualInput'));
                    this.hasErrors = true;
                } else if (!loadFactorFormUnit.get('cabin').value) {
                    this.validationService.addGlobalError('acegui.rules.messages.load.factor.cabin.mandtory');
                    this.validationService.showRequiredFieldError(loadFactorFormUnit.get('cabin'));
                    this.hasErrors = true;
                } else if (!loadFactorFormUnit.get('actualInput').value) {
                    this.validationService.addGlobalError('acegui.rules.messages.load.factor.lf.mandtory');
                    this.validationService.showRequiredFieldError(loadFactorFormUnit.get('actualInput'));
                    this.hasErrors = true;
                }
            }
       }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyLoadFactorFormUnits = [];
        this.isEmptyCondition = false;

        for (const loadFactorFormUnit of this.ldFormArray.controls) {
            const originAndDestFormUnitArray = loadFactorFormUnit.get('originDestinations') as FormArray;

            let emptyOriginAndDestForm = false;
            const emptyOriginAndDestFormUnitArray = this.validateOriginAndDestination(originAndDestFormUnitArray);
            if (originAndDestFormUnitArray.controls.length === emptyOriginAndDestFormUnitArray.length) {
                emptyOriginAndDestForm = true;
                emptyOriginAndDestFormUnitArray.splice(0, 1);
            }

            for (const emptyOriginDestFormUnit of emptyOriginAndDestFormUnitArray){
                this.removeOriginDestFormGroup(i, emptyOriginDestFormUnit);
            }

            let emptyForm = true;
            if (loadFactorFormUnit.get('cabin').value
                || loadFactorFormUnit.get('actualInput').value
                || !emptyOriginAndDestForm) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyLoadFactorFormUnits.push(i);
            }

            i++;
        }

        if (this.ldFormArray.controls.length === emptyLoadFactorFormUnits.length) {
            this.isEmptyCondition = true;
            emptyLoadFactorFormUnits.splice(0, 1);
        }
        for (const emptyLdFactorForm of emptyLoadFactorFormUnits.reverse()){
            this.removeLoadFactorLogicalUnit(emptyLdFactorForm);
        }
    }

    private setFormValuesFromData() {
        const loadFactorFormModel = new LFComponentFormModel();
        const loadFactorFormArray = [];

        for (const loadFactorData of this.loadFactorComponentData) {
            const ldFacorFormUnit = new LoadFactorFormGroup();
            ldFacorFormUnit.cabin = loadFactorData.cabin[0];
            ldFacorFormUnit.actual = String(loadFactorData.comparator);

            if (loadFactorData.startPercent && loadFactorData.endPercent) {
                ldFacorFormUnit.actualInput = loadFactorData.startPercent + '-' + loadFactorData.endPercent;
            } else {
                ldFacorFormUnit.actualInput = String(loadFactorData.startPercent);
            }

            const originAndDestFormArray = [];
            for (const loadFactorLegData of loadFactorData.leg) {
                const originDestFormUnit = new OriginDestinationFormGroup();
                originDestFormUnit.origin = loadFactorLegData.origin ? loadFactorLegData.origin : '';
                originDestFormUnit.destination = loadFactorLegData.destination ? loadFactorLegData.destination : '';
                originAndDestFormArray.push(originDestFormUnit);
            }

            ldFacorFormUnit.originDestinations = originAndDestFormArray;
            loadFactorFormArray.push(ldFacorFormUnit);
        }
        loadFactorFormModel.LoadFactor = loadFactorFormArray;

        if (loadFactorFormModel) {
            this.setFormValues(loadFactorFormModel);
        }
    }

    private setFormValues(ldFactorFormModel: LFComponentFormModel) {

        let i: number;
        let j: number;

        const loadFactorFormArrayLength = ldFactorFormModel.LoadFactor.length;
        const ldFactorFormArray = this.LdFactorForm.get('LoadFactor') as FormArray;

        // generate fields for marketLogic Unit
        for (i = 0; i < loadFactorFormArrayLength ; i++ ) {
            ldFactorFormArray.push(this.createLoadFactorLogicalUnit());
        }

        ldFactorFormArray.removeAt(i);

        // generate fields for orginDestination
        i = 0;
        for (const ldFactorFormUnit of ldFactorFormModel.LoadFactor) {
            j = 0;
            const originDestFormArray =  this.ldFormArray.controls[i].get('originDestinations') as FormArray;
            for ( const originDestFormUnit of ldFactorFormUnit.originDestinations) {
                originDestFormArray.push(this.createOriginDestFormGroup());
                j++;
            }
            this.removeOriginDestFormGroup(i, j);
            i++;
        }
          // Push service response data into generated fields
        (this.LdFactorForm as FormGroup).patchValue(ldFactorFormModel, { onlySelf: true });
    }

    private createLoadFactorLogicalUnit() {
       return this.fb.group({
           cabin: [''],
           actual: ['EQ'],
           actualInput : [''],
           originDestinations: this.fb.array([this.createOriginDestFormGroup()])
       });
    }

    private createOriginDestFormGroup() {
        return this.fb.group({
            origin: [''],
            destination: ['']
        });
    }

    private addOriginDestFormGroup(j: number) {
        const control = this.LdFactorForm.get('LoadFactor')['controls'][j].get('originDestinations') as FormArray;
        control.push(this.createOriginDestFormGroup());
    }

    private removeOriginDestFormGroup(j: number, i: number) {
        const control = this.LdFactorForm.get('LoadFactor')['controls'][j].get('originDestinations') as FormArray;
        control.removeAt(i);
    }

}
