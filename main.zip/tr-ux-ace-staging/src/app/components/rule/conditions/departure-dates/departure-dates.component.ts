// Framework imports
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

// Third party and own lib imports
import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';

// Local imports
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, DepartureDateTimeComponentForm, DateTimeFormGroup } from '../../../../models/rule-form.model';
import { DropdownModel } from '../../../../models/rule-form.model';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

@Component({
    selector: 'departure-dates',
    templateUrl: 'departure-dates.component.html',
    styleUrls: ['./departure-dates.component.scss']
})
export class DepartureDatesComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;
    @Input() public timeUnitCount = 0;
    @Output() public timeUnitCountChange = new EventEmitter();

    public departureDateGroup: FormGroup;
    public departDateTimeCondDataArray: DateTimeCondition[];

    public operators: DropdownModel[];
    public days: DropdownModel[];
    public minDate = new Date();
    public minEndDate = new Date();
    public startMaxDate: any;
    public carrierPrefDateFormat: string;
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private appSingletonService: AppSingletonService,
                private datePipe: DatePipe,
                private validationService: RuleValidationService) {
        this.operators = this.appSingletonService.ruleJsonStore.Operators;
        this.days = this.appSingletonService.ruleJsonStore.Days;
    }

    public ngOnInit() {
        this.carrierPrefDateFormat = this.appSingletonService.carrierDateFormat;
        // this.carrierPrefDateFormat = 'yyyy-MM-dd';

        this.departureDateGroup = this.fb.group({
            departureDataLogicalUnits: this.fb.array([this.createDepartureDateFormGroup()])
        });
        this.setValues();
    }

    public setEndDate(event: MatDatepickerInputEvent<Date>) {
        this.minEndDate = event.value;
        this.startMaxDate = '';
    }

    public setStartDate(event: MatDatepickerInputEvent<Date>) {
        this.startMaxDate = event.value;
    }

    public createDepartureDateFormGroup() {
        return this.fb.group({
            allDay: ['true'],
            monday: [''],
            tuesday: [''],
            wednesday: [''],
            thursday: [''],
            friday: [''],
            saturday: [''],
            sunday: [''],
            operators: 'EQ',
            startDate: '',
            startHour: '',
            startMinute: '',
            endDate: '',
            endHour: '',
            endMinute: ''
        });
    }

    public addDepartureDates() {
        this.departureDateFormArray.push(this.createDepartureDateFormGroup());
        this.timeUnitCount++;
        this.timeUnitCountChange.emit(this.timeUnitCount);
        this.allChecked(this.timeUnitCount);
    }

    public removeDepartureDates(i: number) {
        this.departureDateFormArray.removeAt(i);
        this.timeUnitCount--;
    }

    get departureDateFormArray(): FormArray {
        return this.departureDateGroup.get('departureDataLogicalUnits') as FormArray;
    }

    public allChecked(i) {
        for (const item of this.days) {
            this.departureDateFormArray.controls[i].get(item.id).setValue(
                this.departureDateFormArray.controls[i].get('allDay').value
            );
        }
    }

    public dayChecked(i) {
        const isAllChecked = [];
        for (const item of this.days) {
            isAllChecked.push(this.departureDateFormArray.controls[i].get(item.id).value);
        }
        this.departureDateFormArray.controls[i].get('allDay').setValue(
            isAllChecked.every(function(value: boolean){
                return value === true;
            })
        );
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.departDateTimeCondDataArray = RuleUtil.getComponenetData(rule, 'departureDateCondition');
        }
        if ( this.departDateTimeCondDataArray && this.departDateTimeCondDataArray.length > 0 ) {
            this.setFormValuesFromData();
        } else {
            this.allChecked(0);
        }
    }

    public getValues(): DateTimeCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        const dateTimeCondArray = [];
        for (const dateTimeFormUnit of this.departureDateFormArray.value) {
            const daysArray = [];
            if (dateTimeFormUnit.allDay) {
                daysArray.push('ALL');
            } else {
                if (dateTimeFormUnit.monday) { daysArray.push('MON'); }
                if (dateTimeFormUnit.tuesday) { daysArray.push('TUE'); }
                if (dateTimeFormUnit.wednesday) { daysArray.push('WED'); }
                if (dateTimeFormUnit.thursday) { daysArray.push('THU'); }
                if (dateTimeFormUnit.friday) { daysArray.push('FRI'); }
                if (dateTimeFormUnit.saturday) { daysArray.push('SAT'); }
                if (dateTimeFormUnit.sunday) { daysArray.push('SUN'); }
            }
            let dateAndTime: DateOrRange;
            if (dateTimeFormUnit.startDate || dateTimeFormUnit.endDate || dateTimeFormUnit.startHour ||
                dateTimeFormUnit.startMinute || dateTimeFormUnit.endHour || dateTimeFormUnit.endMinute) {
                dateAndTime = new DateOrRange();

                if (dateTimeFormUnit.startDate) {
                    dateAndTime.startDateTime = this.datePipe.transform(dateTimeFormUnit.startDate, 'yyyy-MM-dd') + 'T'
                    + dateTimeFormUnit.startHour + ':' + dateTimeFormUnit.startMinute + ':00';
                } else if (dateTimeFormUnit.startHour || dateTimeFormUnit.startMinute) {
                    dateAndTime.startDateTime = 'T' + dateTimeFormUnit.startHour + ':' + dateTimeFormUnit.startMinute + ':00';
                }
                if (dateTimeFormUnit.endDate) {
                    dateAndTime.endDateTime =  this.datePipe.transform(dateTimeFormUnit.endDate, 'yyyy-MM-dd') +
                    'T' + dateTimeFormUnit.endHour + ':' + dateTimeFormUnit.endMinute + ':00';
                } else if (dateTimeFormUnit.endHour || dateTimeFormUnit.endMinute) {
                    dateAndTime.endDateTime = 'T' + dateTimeFormUnit.endHour + ':' + dateTimeFormUnit.endMinute + ':00';
                }
            }
            dateTimeCondArray.push({
                comparator: dateTimeFormUnit.operators,
                dayOfWeek: daysArray,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return dateTimeCondArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

         // Validate only when user given the input
        if (!this.isEmptyCondition) {
            for (const checkDepatureDateUnit of this.departureDateFormArray.controls) {
                if (!checkDepatureDateUnit.get('allDay').value
                            && !checkDepatureDateUnit.get('friday').value
                            && !checkDepatureDateUnit.get('monday').value
                            && !checkDepatureDateUnit.get('saturday').value
                            && !checkDepatureDateUnit.get('sunday').value
                            && !checkDepatureDateUnit.get('thursday').value
                            && !checkDepatureDateUnit.get('tuesday').value
                            && !checkDepatureDateUnit.get('wednesday').value) {
                                this.hasErrors = true;
                                this.validationService.addGlobalError('acegui.rules.messages.days.required');
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const departDateFormUnit of this.departureDateFormArray.controls) {
            let emptyForm = true;
            if (departDateFormUnit.get('allDay').value
                 || departDateFormUnit.get('friday').value
                 || departDateFormUnit.get('monday').value
                 || departDateFormUnit.get('saturday').value
                 || departDateFormUnit.get('sunday').value
                 || departDateFormUnit.get('thursday').value
                 || departDateFormUnit.get('tuesday').value
                 || departDateFormUnit.get('wednesday').value
                 || departDateFormUnit.get('startHour').value
                 || departDateFormUnit.get('startMinute').value
                 || departDateFormUnit.get('startDate').value
                 || departDateFormUnit.get('endHour').value
                 || departDateFormUnit.get('endMinute').value
                 || departDateFormUnit.get('endDate').value) {
                    emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyGroup of emptyForms.reverse()){
            this.removeDepartureDates(emptyGroup);
        }
        if (this.departureDateFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addDepartureDates();
        }
    }

    private setFormValuesFromData() {
        const departDateTimeFormUnitArray = [];

        for ( const departDateTimeDataUnit of this.departDateTimeCondDataArray) {
            this.timeUnitCount++;

            let startDateTimeSplit = [];
            let startTimeSplit = [];
            if (departDateTimeDataUnit.dateOrRange && departDateTimeDataUnit.dateOrRange.startDateTime) {
                startDateTimeSplit =  departDateTimeDataUnit.dateOrRange.startDateTime.split('T');
                if (startDateTimeSplit[1]) {
                    startTimeSplit =  startDateTimeSplit[1].split(':');
                }
            }

            let endDateTimeSplit = [];
            let endTimeSplit = [];
            if (departDateTimeDataUnit.dateOrRange && departDateTimeDataUnit.dateOrRange.endDateTime) {
                endDateTimeSplit = departDateTimeDataUnit.dateOrRange.endDateTime.split('T');
                if (endDateTimeSplit[1]) {
                    endTimeSplit = endDateTimeSplit[1].split(':');
                }
            }

            const departDateTimeFormUnit =  {
                operators: departDateTimeDataUnit.comparator,
                startDate: startDateTimeSplit[0],
                startHour: startTimeSplit[0],
                startMinute: startTimeSplit[1],
                endDate: endDateTimeSplit[0],
                endHour: endTimeSplit[0],
                endMinute: endTimeSplit[1]
            } as DateTimeFormGroup;

            if (departDateTimeDataUnit.dayOfWeek) {
                for ( const dayWeek of departDateTimeDataUnit.dayOfWeek) {
                    switch (dayWeek) {
                        case 'ALL':
                            departDateTimeFormUnit.allDay = true;
                            departDateTimeFormUnit.monday = true;
                            departDateTimeFormUnit.tuesday = true;
                            departDateTimeFormUnit.wednesday = true;
                            departDateTimeFormUnit.thursday = true;
                            departDateTimeFormUnit.friday = true;
                            departDateTimeFormUnit.saturday = true;
                            departDateTimeFormUnit.sunday = true;
                            break;
                        case 'MON':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.monday = true;
                            break;
                        case 'TUE':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.tuesday = true;
                            break;
                        case 'WED':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.wednesday = true;
                            break;
                        case 'THU':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.thursday = true;
                            break;
                        case 'FRI':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.friday = true;
                            break;
                        case 'SAT':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.saturday = true;
                            break;
                        case 'SUN':
                            departDateTimeFormUnit.allDay = false;
                            departDateTimeFormUnit.sunday = true;
                            break;
                    }
                }
            }
            departDateTimeFormUnitArray.push(departDateTimeFormUnit);
        }

        const departDateTimeComponentForm =  {
            departureDataLogicalUnits: departDateTimeFormUnitArray
        } as DepartureDateTimeComponentForm;

        if (departDateTimeComponentForm) {
            this.setFormValues(departDateTimeComponentForm);
        }
    }

    private setFormValues(depatureDateTimeFormModel: DepartureDateTimeComponentForm) {
        const departureDateTimeFormArray = this.departureDateGroup.get('departureDataLogicalUnits') as FormArray;
        for (const departureDateTimeFormUnit of depatureDateTimeFormModel.departureDataLogicalUnits){
            departureDateTimeFormArray.push(this.createDepartureDateFormGroup());
        }
        this.removeDepartureDates(0);
        (this.departureDateGroup as FormGroup).patchValue(depatureDateTimeFormModel, { onlySelf: true });
    }
}
