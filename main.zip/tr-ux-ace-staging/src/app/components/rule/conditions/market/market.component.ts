import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { TranslateService } from '@ngx-translate/core';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { Rule, MarketCondition, Market, MarketGrouping, Segment } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';
import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppUtil } from '../../../../utility/app-util';
import {
    MarketComponentForm, MarketFormGroup,
    OriginDestinationFormGroup,
    RuleDetailChildForm,
    DropdownModel
} from '../../../../models/rule-form.model';
import { Observable } from 'rxjs/Observable';
import { RuleUtil } from '../../rule.util.ts';
import { FormControl } from '@angular/forms/src/model';
import { AppConstants } from 'src/app/app.constants';

@Component({
    selector: 'market',
    templateUrl: 'market.component.html',
    styleUrls: ['./market.component.scss']
})
export class MarketComponent implements OnInit, RuleDetailChildForm {
    @Input() public childInput: Rule;

    public marketForm: FormGroup;

    public listOfAirport: DropdownModel[];
    public marketGroups: DropdownModel[];
    public operators: any[];
    public applies: any[];

    public title: string;
    public showSegment: boolean = false;

    public legOrOAndD: string;
    public placeholderOrgin: string = 'Origin';
    public placeholderDest: string = 'Destination';

    public ruleJsonStore: any;

    // Will be true when the input is given for any segment form
    private segmentInputValueExists: boolean = false;
    // Will be true when the input is given for any market form
    private marketInputValueExists: boolean = false;

    private marketComponentData: MarketCondition[];

    constructor(
        private fb: FormBuilder,
        private singletonService: AppSingletonService,
        private messageService: MessageService,
        private translateService: TranslateService,
        private ruleValidation: RuleValidationService) {
        this.ruleJsonStore = singletonService.ruleJsonStore;
        this.operators = this.ruleJsonStore.Operators;
    }

    public ngOnInit() {
        const locationGroupList = GroupType.getGroupList('Location Grouping', this.singletonService.groupTypes);
        const cityAirportList = CarrierConfig.getAiportsList(this.singletonService.airports);
        this.marketGroups = GroupType.getGroupList('Market Grouping', this.singletonService.groupTypes);
        this.listOfAirport = locationGroupList.concat(cityAirportList) as DropdownModel[];

        let defaultSelection = 'Market';
        if (this.childInput.type === AppConstants.ACTION_BID_PRICE_ADJ) {
            // Show the 'Adjust O&D Bid Price' and 'Adjust Leg Bid Price' boolean flags for bid price adjustment action
            this.applies = this.ruleJsonStore.AdjustBidPriceTypes;
            this.title = 'Market';
            defaultSelection = 'O&D';
            this.showSegment = false;
        } else {
            // Segments applicable for all actions other than bid price
            this.title = 'Markets and Segments';
            this.showSegment = true;
        }

        this.marketForm = this.fb.group({
            legOrOAndDFlag: [defaultSelection],
            marketLogicalUnits: this.fb.array([this.createMarketLogicalUnitFormGroup()]),
            segmentLogicalUnits: this.fb.array([this.createSegmentLogicalUnitFormGroup()])
        });

        this.marketForm.get('legOrOAndDFlag').valueChanges.subscribe(
            (data: string) => {
                if (data === 'LEG') {
                    this.title = 'Market';
                    this.placeholderOrgin = 'Leg Origin';
                    this.placeholderDest = 'Leg Destination';
                } else {
                    this.title = 'Market';
                    this.placeholderOrgin = 'Origin';
                    this.placeholderDest = 'Destination';
                }
            }
        );
        this.setValues();
    }

    public resetMarketForm() {
       // this.marketForm.reset();
    }

    /**
     * Sets the form values by getting the values from rule service response
     */
    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.marketComponentData = RuleUtil.getComponenetData(rule, 'marketCondition');
        }

        if (this.marketComponentData && this.marketComponentData.length > 0) {
            this.setFormValuesFromData();
        }
    }

    /**
     * constructs the market component service request for create/update rule
     */
    public getValues() {
        this.validate();

        if (!this.marketInputValueExists && !this.segmentInputValueExists) {
            this.ruleValidation.addGlobalError('acegui.rules.messages.market.condition');
            return null;
        }

        // Array for MarketCondition. MarketCondition is the data container for both selected market and segment
        const marketConditionArray = [];

        // Construct the market data to be sent in the rule request for create/update
        if (this.marketInputValueExists) {
            for (const marketForm of this.marketFormArray.value) {
                const originDestinationDataArray = [];
                for (const originDestinationForm of marketForm.originDestinations) {
                    const originDestinationData = new MarketGrouping();
                    originDestinationData.bidirectional = originDestinationForm.bidirectional ? true : false;
                    originDestinationData.destination = originDestinationForm.destination ?
                        (originDestinationForm.destination[0] === '***' ? [] : originDestinationForm.destination) : [];
                    originDestinationData.origin = originDestinationForm.origin ?
                        (originDestinationForm.origin[0] === '***' ? [] : originDestinationForm.origin) : [];
                    originDestinationDataArray.push(originDestinationData);
                }

                const marketData = new Market();
                marketData.marketGrouping = marketForm.groupName ? marketForm.groupName : [];
                marketData.market = originDestinationDataArray;

                const marketConditionData = new MarketCondition();
                marketConditionData.comparator = marketForm.operators;
                marketConditionData.market = [marketData];
                marketConditionArray.push(marketConditionData);
            }
        }

        // Construct the segment data to be sent in the rule request for create/update
        if (this.showSegment && this.segmentInputValueExists) {
            for (const segmentForm of this.segmentFormArray.value) {
                const segmentDataArray = [];
                let checkSegmentValidation: boolean = false;

                for (const segmentOAndDForm of segmentForm.originDestinations) {
                    const segmentData = new Segment();
                    if (segmentOAndDForm.destination || segmentOAndDForm.origin) {
                        checkSegmentValidation = true;
                    }
                    // Send empty array to the servier user selected '****'
                    // '****' means ALL
                    segmentData.destination = segmentOAndDForm.destination ?
                        (segmentOAndDForm.destination[0] === '***' ? [] : segmentOAndDForm.destination) : [];
                    segmentData.origin = segmentOAndDForm.origin ?
                        (segmentOAndDForm.origin[0] === '***' ? [] : segmentOAndDForm.origin) : [];

                    segmentDataArray.push(segmentData);
                }
                if (checkSegmentValidation) {
                    const segmentConditionData = new MarketCondition();
                    segmentConditionData.comparator = segmentForm.operators;
                    segmentConditionData.segment = segmentDataArray;
                    marketConditionArray.push(segmentConditionData);
                }
            }
        }
        return marketConditionArray;
    }

    public validate() {
        this.messageService.clear();

        // Remove the segment section when the origin and destination not entered by the user
        if (this.showSegment) {
           this.validateSegment();
        }

        // Remove the market section when the origin and destination (or) market group not entered by the user
        this.validateMarket();
    }

    public validateMarket() {
        let i: number = 0;
        const removableMarketFormGroups = [];
        // Remove the market section when the origin and destination (or) market group not entered by the user
        for (const marketForm of this.marketFormArray.controls) {
            const originDestinations = marketForm.get('originDestinations') as FormArray;
            let j: number = 0;
            const removableOAndDFormGroups = [];
            let emptyMarketForm = true;
            for (const originAndDestinationForm of originDestinations.controls) {
                if (AppUtil.isArrayValueExists(originAndDestinationForm, 'origin')
                    || AppUtil.isArrayValueExists(originAndDestinationForm, 'destination')) {
                    this.marketInputValueExists = true;
                    emptyMarketForm = false;
                } else {
                    removableOAndDFormGroups.push(j);
                }
                j++;
            }
            if (originDestinations.controls.length === removableOAndDFormGroups.length) {
                removableOAndDFormGroups.splice(0, 1);
            }

            for (const removableOAndFormGroup of removableOAndDFormGroups.reverse()) {
                this.removeOriginDestFormGroup(i, removableOAndFormGroup, 'marketLogicalUnits');
            }

            if (marketForm.get('groupName').value.length > 0) {
                this.marketInputValueExists = true;
                emptyMarketForm = false;
            }

            if (emptyMarketForm) {
                removableMarketFormGroups.push(i);
            }
            i++;
        }

        if (this.marketFormArray.length > 1) {
            if (this.marketFormArray.controls.length === removableMarketFormGroups.length) {
                removableMarketFormGroups.splice(0, 1);
            }
            for (const removableMarketFormGroup of removableMarketFormGroups.reverse()) {
                this.removeMarketLogicalUnit(removableMarketFormGroup, 'marketLogicalUnits');
            }
        }
    }

    public validateSegment() {
        let n: number = 0;
        const removableSegmentFormGroups = [];

        for (const segmentForm of this.segmentFormArray.controls) {
            let k: number = 0;
            let emptySegmentForm = true;
            const removableSegmentOAndDFormGroups = [];
            const originDestinations = segmentForm.get('originDestinations') as FormArray;

            for (const originDestinationForm of originDestinations.controls) {
                if (AppUtil.isArrayValueExists(originDestinationForm, 'origin')
                || AppUtil.isArrayValueExists(originDestinationForm, 'destination')) {
                    this.segmentInputValueExists = true;
                    emptySegmentForm = false;
                } else {
                    removableSegmentOAndDFormGroups.push(k);
                }
                k++;
            }

            if (originDestinations.controls.length === removableSegmentOAndDFormGroups.length) {
                removableSegmentOAndDFormGroups.splice(0, 1);
            }

            for (const removableOAndDFormGroup of removableSegmentOAndDFormGroups.reverse()) {
                this.removeOriginDestFormGroup(n, removableOAndDFormGroup, 'segmentLogicalUnits');
            }
            if (emptySegmentForm) {
                removableSegmentFormGroups.push(n);
            }
            n++;
        }
        if (this.segmentFormArray.length > 1) {
            if (this.segmentFormArray.controls.length === removableSegmentFormGroups.length) {
                removableSegmentFormGroups.splice(0, 1);
            }
            for (const removeGroup of removableSegmentFormGroups.reverse()) {
                this.removeMarketLogicalUnit(removeGroup, 'segmentLogicalUnits');
            }
        }
    }

    public getLegOrOAndDFlag() {
        if (this.marketFormArray.parent.value.legOrOAndDFlag === 'Market' || this.marketFormArray.parent.value.legOrOAndDFlag === 'LEG') {
            return true;
        } else {
            return false;
        }
    }

    private setFormValuesFromData() {
        // Array of maket and segment forms
        const marketLogicalUnitArray = [];
        const segmentLogicalUnitArray = [];

        // Construct the form values for edit from the service data
        for (const marketComponent of this.marketComponentData) {
            if (this.childInput.action[0].bidPriceAdjustmentAction) {
                this.legOrOAndD = this.childInput.action[0].bidPriceAdjustmentAction.adjustLeg ? 'LEG' : 'O&D';
            }

            // Market or segment form
            const marketOrSegmentLogicalUnit = new MarketFormGroup();
            const originDestinationArray = [];

            // Construct the segment form
            if (marketComponent.hasOwnProperty('segment')) {
                marketOrSegmentLogicalUnit.operators = marketComponent.comparator;
                for (const originDestination of marketComponent.segment) {
                    const originDestinationArrayData = new OriginDestinationFormGroup();
                    originDestinationArrayData.destination = originDestination.destination ? originDestination.destination : ['***'];
                    originDestinationArrayData.origin = originDestination.origin ? originDestination.origin : ['***'];
                    originDestinationArray.push(originDestinationArrayData);
                }
                marketOrSegmentLogicalUnit.originDestinations = originDestinationArray;
                segmentLogicalUnitArray.push(marketOrSegmentLogicalUnit);
            } else {
                // Construct the market form
                marketOrSegmentLogicalUnit.operators = marketComponent.comparator;

                for (const marketData of marketComponent.market) {
                    if (marketData.market) {
                        // Market has nested market. See the rules.xsd for more details
                        for (const originDestination of marketData.market) {
                            const originDestinationArrayData = new OriginDestinationFormGroup();
                            originDestinationArrayData.destination = originDestination.destination ? originDestination.destination : ['***'];
                            originDestinationArrayData.origin = originDestination.origin ? originDestination.origin : ['***'];
                            originDestinationArrayData.bidirectional = originDestination.bidirectional;
                            originDestinationArray.push(originDestinationArrayData);
                        }
                    } else {
                        const originDestinationArrayData = new OriginDestinationFormGroup();
                        originDestinationArray.push(originDestinationArrayData);
                    }
                    marketOrSegmentLogicalUnit.groupName = marketData.marketGrouping ? marketData.marketGrouping : '';
                }
                marketOrSegmentLogicalUnit.originDestinations = originDestinationArray;
                marketLogicalUnitArray.push(marketOrSegmentLogicalUnit);
            }
        }

        // Push the array of market forms and segment forms to market section for display
        const marketComponentFormModel = {
            legOrOAndDFlag: this.legOrOAndD,
            segmentLogicalUnits: segmentLogicalUnitArray,
            marketLogicalUnits: marketLogicalUnitArray
        } as MarketComponentForm;

        this.setFormValues(marketComponentFormModel);
    }

    private setFormValues(marketComponentFormModel: MarketComponentForm) {
        const segmentLogicalUnitsLength = marketComponentFormModel.segmentLogicalUnits.length;
        const controlSegmentLogicalUnits = this.marketForm.get('segmentLogicalUnits') as FormArray;
        let i: number;
        let j: number;
        // generate fields for marketLogic Unit
        for (i = 0; i < segmentLogicalUnitsLength; i++) {
            controlSegmentLogicalUnits.push(this.createSegmentLogicalUnitFormGroup());
        }
        if (segmentLogicalUnitsLength > 0) {
            controlSegmentLogicalUnits.removeAt(i);
        }
        // generate fields for orginDestination
        i = 0;
        for (const segmentLogicalUnits of marketComponentFormModel.segmentLogicalUnits) {
            j = 0;
            const controlOrginDest = this.segmentFormArray.controls[i].get('originDestinations') as FormArray;
            for (const orginDestination of segmentLogicalUnits.originDestinations) {
                controlOrginDest.push(this.createOriginDestFormGroup());
                j++;
            }
            this.removeOriginDestFormGroup(i, j, 'segmentLogicalUnits');
            i++;
        }

        const marketLogicalUnitsLength = marketComponentFormModel.marketLogicalUnits.length;
        const controlMarketLogicalUnits = this.marketForm.get('marketLogicalUnits') as FormArray;

        // generate fields for marketLogic Unit
        for (i = 0; i < marketLogicalUnitsLength; i++) {
            controlMarketLogicalUnits.push(this.createMarketLogicalUnitFormGroup());
        }
        if (marketLogicalUnitsLength > 0) {
            controlMarketLogicalUnits.removeAt(i);
        }
        // generate fields for orginDestination
        i = 0;
        for (const marketLogicalUnits of marketComponentFormModel.marketLogicalUnits) {
            j = 0;
            const controlOrginDest = this.marketFormArray.controls[i].get('originDestinations') as FormArray;
            for (const orginDestination of marketLogicalUnits.originDestinations) {
                controlOrginDest.push(this.createOriginDestFormGroup());
                j++;
            }
            this.removeOriginDestFormGroup(i, j, 'marketLogicalUnits');
            i++;
        }
        // Push service response data into generated fields
        (this.marketForm as FormGroup).patchValue(marketComponentFormModel, { onlySelf: true });
    }

    get marketFormArray(): FormArray {
        return this.marketForm.get('marketLogicalUnits') as FormArray;
    }

    get segmentFormArray(): FormArray {
        return this.marketForm.get('segmentLogicalUnits') as FormArray;
    }

    private createMarketLogicalUnitFormGroup() {
        return this.fb.group({
            operators: ['EQ'],
            groupName: [[]],
            originDestinations: this.fb.array([this.createOriginDestFormGroup()])
        });
    }

    private createSegmentLogicalUnitFormGroup() {
        return this.fb.group({
            operators: ['EQ'],
            originDestinations: this.fb.array([this.createOriginDestFormGroup()])
        });
    }

    private createOriginDestFormGroup() {
        return this.fb.group({
            origin: [[]],
            destination: [[]],
            bidirectional: ['']
        });
    }

    private addMarketLogicalUnit(formName) {
        const control = this.marketForm.get(formName) as FormArray;
        control.push(this.createMarketLogicalUnitFormGroup());
    }

    private removeMarketLogicalUnit(i: number, formName) {
        const control = this.marketForm.get(formName) as FormArray;
        control.removeAt(i);
    }

    private addOriginDestFormGroup(j: number, fromName) {
        const control = this.marketForm.get(fromName)['controls'][j].get('originDestinations') as FormArray;
        control.push(this.createOriginDestFormGroup());
    }

    private removeOriginDestFormGroup(j: number, i: number, fromName) {
        const control = this.marketForm.get(fromName)['controls'][j].get('originDestinations') as FormArray;
        control.removeAt(i);
    }

}
