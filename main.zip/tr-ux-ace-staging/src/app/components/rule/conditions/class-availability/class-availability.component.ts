import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Rule, ClassAvailabilityCondition, Seat } from '@dxc/tr-ux-ace-services/dist/lib';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';

import { AppUtil } from '../../../../utility/app-util';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm,
            DropdownModel,
            ClassAvailabilityComponentForm,
            ClassAvailabilityFormGroup,
            ClassSegmentForm
} from '../../../../models/rule-form.model';

@Component({
    selector : 'class-availability',
    templateUrl : 'class-availability.component.html',
    styleUrls : ['./class-availability.component.scss']
})
export class ClassAvailabilityComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public classesAvailabilityGroup: FormGroup;
    public classAvailConditionDataArray: ClassAvailabilityCondition[];

    // Operators for class conditions
    public selectConds: string[] = [];
    // Operators for seats
    public operators: string[] = [];

    // Carrier configured classses and cabins. Name it appropriately
    public bookingClassesInput: DropdownModel[];
    public cabinClassesInput: DropdownModel[];

    // User selected classes and cabins. Name it appropriately
    private cabinViewData: string[] = [];
    private bookingViewData: string[] = [];

    // Will be true if there is no input value given by the user for class availability condition
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageService,
                private translateService: TranslateService,
                private ruleValidation: RuleValidationService) {
        const data = singletonService.ruleJsonStore;
        this.selectConds = data.Operators;
        this.operators = data.AllOperators;
    }

    public ngOnInit() {
        this.cabinClassesInput = CarrierConfig.getCabinList('Cabin Types', this.singletonService.carrierPreferences);
        this.bookingClassesInput = CarrierConfig.getBookingClassesList('Class Classes', this.singletonService.carrierPreferences);

        this.classesAvailabilityGroup = this.fb.group({classesAvailabilityUnit: this.fb.array([this.createClassesAvailabilityUnit()])});
        this.setValues();
    }

    /**
     * Populates the form value based on the rule data from the service
     */
    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.classAvailConditionDataArray = RuleUtil.getComponenetData(rule, 'classAvailabilityCondition');
        }
        if ( this.classAvailConditionDataArray && this.classAvailConditionDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    /**
     * Constructs the service request values for the create or update rule
     */
    public getValues(): ClassAvailabilityCondition[] {

        this.validate();

        // Do not send the data in the create/update service request when the the class availability input is not given.
        // This is also helpful to delete the existing data
        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        const classAvailabilityConditionArray = [];
        for (const classesAvailabilityUnit of this.classAvailabilityFormArray.value) {
            const seat = {
                seatComparator: classesAvailabilityUnit.operators,
                count: classesAvailabilityUnit.numbers
            } as Seat;

            const classAvailabilityCondition = {
                comparator: classesAvailabilityUnit.condSelect,
                classOfService: classesAvailabilityUnit.bookedClasses.selectedSeats ?
                                classesAvailabilityUnit.bookedClasses.selectedSeats.split(',') : [],
                cabin: classesAvailabilityUnit.cabinClasses,
                seats: seat
            } as ClassAvailabilityCondition;

            classAvailabilityConditionArray.push(classAvailabilityCondition);
        }
        return classAvailabilityConditionArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        if (!this.isEmptyCondition) {
            for (const classesAvailabilityFormUnit of this.classAvailabilityFormArray.controls) {

                if (RuleUtil.isBookingClassSelected(classesAvailabilityFormUnit)
                    && AppUtil.isArrayValueExists(classesAvailabilityFormUnit, 'cabinClasses')) {
                        // When booking and cabin provided
                        this.ruleValidation.addGlobalError('acegui.rules.messages.both.classes.and.cabin.not.allowed');
                        this.hasErrors = true;
                }  else if (RuleUtil.isBookingClassSelected(classesAvailabilityFormUnit)
                    || AppUtil.isArrayValueExists(classesAvailabilityFormUnit, 'cabinClasses')) {
                    // When booking or cabin provided, and seats not provided
                    if (AppUtil.isEmptyValue(classesAvailabilityFormUnit, 'numbers')) {
                        this.ruleValidation.addGlobalError('acegui.rules.messages.seats.required');
                        this.hasErrors = true;
                    }
                } else {
                    // When booking or cabin is not provided, and seats provided
                    if (AppUtil.isValueExists(classesAvailabilityFormUnit, 'numbers')) {
                        this.ruleValidation.addGlobalError('acegui.rules.messages.classes.or.cabin.required');
                        this.hasErrors = true;
                    }
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyClassAvailFormUnitArray = [];
        this.isEmptyCondition = false;

        for (const classesAvailabilityFormUnit of this.classAvailabilityFormArray.controls) {

            let emptyForm = true;
            if (RuleUtil.isBookingClassSelected(classesAvailabilityFormUnit)
                || AppUtil.isArrayValueExists(classesAvailabilityFormUnit, 'cabinClasses')
                || AppUtil.isValueExists(classesAvailabilityFormUnit, 'numbers')) {
                    emptyForm = false;
            }

            if (emptyForm) {
                emptyClassAvailFormUnitArray.push(i);
            }
            i++;
        }

        // When the class form array and the removable form array is equal, then just add an empty form
        if (this.classAvailabilityFormArray.controls.length === emptyClassAvailFormUnitArray.length) {
            this.isEmptyCondition = true;
            emptyClassAvailFormUnitArray.splice(0, 1);
        }
        for (const emptyUnit of emptyClassAvailFormUnitArray.reverse()){
            this.removeClassesAvailabilityUnit(emptyUnit);
        }
    }

    get classAvailabilityFormArray(): FormArray{
        return this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;
    }

    private clearDatas(i) {
        this.bookingViewData.splice(i, 1);
        this.cabinViewData.splice(i, 1);
    }

    private setFormValuesFromData() {
        const classAvailabilityFormUnitArray = [];

        for ( const classAvailDataUnit of this.classAvailConditionDataArray) {
            this.cabinViewData.push(classAvailDataUnit.cabin ? classAvailDataUnit.cabin : '');
            this.bookingViewData.push(classAvailDataUnit.classOfService ? classAvailDataUnit.classOfService : '');
            classAvailabilityFormUnitArray.push( {
                condSelect: classAvailDataUnit.comparator,
                operators: classAvailDataUnit.seats.seatComparator,
                numbers: classAvailDataUnit.seats.count
            } as ClassAvailabilityFormGroup);
        }
        const classAvailabilityFormModel = {
            classesAvailabilityUnit: classAvailabilityFormUnitArray
        } as ClassAvailabilityComponentForm;

        if (classAvailabilityFormModel) {
            this.setFormValues(classAvailabilityFormModel);
        }
    }

    private setFormValues(classesAvailabilityFormModel: ClassAvailabilityComponentForm) {
        const classAvailFormArrayLength = classesAvailabilityFormModel.classesAvailabilityUnit.length;
        const classAvailFormArray = this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;

        let i: number;
        // generate fields for marketLogic Unit
        for (i = 0; i < classAvailFormArrayLength ; i++ ) {
            classAvailFormArray.push(this.createClassesAvailabilityUnit());
        }
        classAvailFormArray.removeAt(i);
        // Push service response data into generated fields
        (this.classesAvailabilityGroup as FormGroup).patchValue(classesAvailabilityFormModel, { onlySelf: true });
    }

    private createClassesAvailabilityUnit() {
        return this.fb.group({
            condSelect : 'EQ',
            bookedClasses: [''],
            cabinClasses: [''],
            numbers: [''],
            operators: ['GT']
        });
    }

    private addClassesAvailabilityUnit() {
        const classAvailFormArray = this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;
        classAvailFormArray.push(this.createClassesAvailabilityUnit());
    }

    private removeClassesAvailabilityUnit(i: number) {
        const classAvailFormArray = this.classesAvailabilityGroup.get('classesAvailabilityUnit') as FormArray;
        classAvailFormArray.removeAt(i);
    }

}
