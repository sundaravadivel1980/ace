import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';

import { AppSingletonService } from '../../../../app-singleton.service';
import { CarrierConfig } from '../../../../models/carrier-config';
import { Rule, ClassBookingCondition, Seat, ClassSegment } from '@dxc/tr-ux-ace-services/dist/lib';
import { RuleDetailChildForm,
            DropdownModel,
            ClassBookingComponentForm,
            ClassBookingFormGroup,
            ClassSegmentForm
        } from '../../../../models/rule-form.model';
import { GroupType } from '../../../../models/group-type';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';
import { RuleUtil } from '../../rule.util.ts';
import { AppUtil } from '../../../../utility/app-util';

@Component({
    selector : 'class-booking',
    templateUrl : 'class-booking.component.html',
    styleUrls : ['./class-booking.component.scss']
})
export class ClassBookingComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public classesBookingGroup: FormGroup;
    public classBookingConditionDataArray: ClassBookingCondition[];

    public selectConds: string[] = [];
    public operators: string[] = [];
    public listOfAirport: DropdownModel[];
    public bookingClassesInput: DropdownModel[];
    public cabinClassesInput: DropdownModel[];
    private cabinViewData: string[] = [];
    private bookingViewData: string[] = [];

    // Will be true if there is no input value given by the user for class booking condition
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private messageService: MessageService,
                private translateService: TranslateService,
                private ruleValidation: RuleValidationService) {
        const data = singletonService.ruleJsonStore;
        // for class conditions
        this.selectConds = data.Operators;
        // for seats
        this.operators = data.AllOperators;
    }

    public ngOnInit() {
        this.cabinClassesInput = CarrierConfig.getCabinList('Cabin Types', this.singletonService.carrierPreferences);
        this.bookingClassesInput = CarrierConfig.getBookingClassesList('Class Classes', this.singletonService.carrierPreferences);
        const locationGroupList = GroupType.getGroupList('Location Grouping', this.singletonService.groupTypes);
        const cityAirportList = CarrierConfig.getAiportsList(this.singletonService.airports);
        this.listOfAirport = locationGroupList.concat(cityAirportList) as DropdownModel[];

        this.classesBookingGroup = this.fb.group({classesBookingUnit: this.fb.array([this.createClassBookingUnit()])});
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.classBookingConditionDataArray = RuleUtil.getComponenetData(rule, 'classBookingCondition');
        }
        if ( this.classBookingConditionDataArray && this.classBookingConditionDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): ClassBookingCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        const classBookingConditionArray = [];
        for (const classBookingFormUnit of this.classBookingFormArray.value) {
            // const classBookingSeats = [];
            const classSegment = [];

            for (const originAndDestFormUnit of classBookingFormUnit.seatsUnit) {
                if (originAndDestFormUnit.origin.length > 0 || originAndDestFormUnit.destination.length > 0) {
                    classSegment.push({
                        origin: originAndDestFormUnit.origin,
                        destination: originAndDestFormUnit.destination
                    } as ClassSegment);
                }
            }

            const seat = {
                seatComparator: classBookingFormUnit.operators,
                count: classBookingFormUnit.numbers,
                segment: classSegment
            } as Seat;

            const classBookingCondition = {
                comparator: classBookingFormUnit.condSelect,
                classOfService: classBookingFormUnit.bookedClasses.selectedSeats ?
                                classBookingFormUnit.bookedClasses.selectedSeats.split(',') : [],
                cabin: classBookingFormUnit.cabinClasses,
                seats: seat
            } as ClassBookingCondition;

            classBookingConditionArray.push(classBookingCondition);
        }

        return classBookingConditionArray;
    }

    public clearDatas(i) {
        this.bookingViewData.splice(i, 1);
        this.cabinViewData.splice(i, 1);
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        // Validate only when user given the input
        if (!this.isEmptyCondition) {
            for (const classBookingFormUnit of this.classBookingFormArray.controls) {
                if (RuleUtil.isBookingClassSelected(classBookingFormUnit)
                     &&  AppUtil.isArrayValueExists(classBookingFormUnit, 'cabinClasses')) {
                         this.ruleValidation.addGlobalError('acegui.rules.messages.both.classes.and.cabin.not.allowed');
                         this.hasErrors = true;
                } else if (RuleUtil.isBookingClassSelected(classBookingFormUnit)
                    || AppUtil.isArrayValueExists(classBookingFormUnit, 'cabinClasses') ) {
                        if (AppUtil.isEmptyValue(classBookingFormUnit, 'numbers')) {
                            this.ruleValidation.addGlobalError('acegui.rules.messages.seats.required');
                            this.hasErrors = true;
                        }
                } else {
                        if (AppUtil.isValueExists(classBookingFormUnit, 'numbers')) {
                            this.ruleValidation.addGlobalError('acegui.rules.messages.classes.or.cabin.required');
                            this.hasErrors = true;
                        }
                }
            }
        }
    }

    private removeEmptyForms() {

        let i: number = 0;
        const emptyClassBkgFormUnits = [];
        this.isEmptyCondition = false;

        for (const classBookingFormUnit of this.classBookingFormArray.controls) {
            const originAndDestFormUnitArray = classBookingFormUnit.get('seatsUnit') as FormArray;

            // Remove the empty O&D fields
            let emptyOriginAndDestForm = false;
            const emptyOriginAndDestFormUnitArray = this.validateOriginAndDestination(originAndDestFormUnitArray);
            if (originAndDestFormUnitArray.controls.length === emptyOriginAndDestFormUnitArray.length) {
                emptyOriginAndDestForm = true;
                emptyOriginAndDestFormUnitArray.splice(0, 1);
            }

            for (const emptyOriginAndDestFormUnit of emptyOriginAndDestFormUnitArray){
                this.removeSeatsUnitFormGroup(i, emptyOriginAndDestFormUnit);
            }

            let emptyForm = true;
            // The form is not empty when user given any field input
            if (RuleUtil.isBookingClassSelected(classBookingFormUnit)
                 || AppUtil.isArrayValueExists(classBookingFormUnit, 'cabinClasses')
                 || AppUtil.isValueExists(classBookingFormUnit, 'numbers')
                 || !emptyOriginAndDestForm) {
                emptyForm = false;

            }

            if (emptyForm) {
                emptyClassBkgFormUnits.push(i);
            }

            i++;
        }

        if (this.classBookingFormArray.controls.length === emptyClassBkgFormUnits.length) {
            this.isEmptyCondition = true;
            emptyClassBkgFormUnits.splice(0, 1);
        }
        for (const emptyClassBkgFormUnit of emptyClassBkgFormUnits.reverse()){
            this.removeClassesBookingUnit(emptyClassBkgFormUnit);
        }
    }

    private validateOriginAndDestination(segmentFormUnit: FormArray) {
        let j: number = 0;
        const removableOAndDFormGroups = [];
        for (const originAndDestination of segmentFormUnit.controls) {
            if (originAndDestination.get('origin').value.length === 0 && originAndDestination.get('destination').value.length === 0) {
                removableOAndDFormGroups.push(j);
            }
            j++;
        }
        return removableOAndDFormGroups.reverse();
    }

    get classBookingFormArray(): FormArray{
        return this.classesBookingGroup.get('classesBookingUnit') as FormArray;
    }

    private setFormValuesFromData() {
        const classBookingFormGroupArray = [];

        for ( const classBkgDataUnit of this.classBookingConditionDataArray) {
            this.cabinViewData.push(classBkgDataUnit.cabin ? classBkgDataUnit.cabin : '');
            this.bookingViewData.push(classBkgDataUnit.classOfService ? classBkgDataUnit.classOfService : '');

            const segmentFormArray = [];
            if (classBkgDataUnit.seats.segment) {
                for (const classAvailabilitySeatData of classBkgDataUnit.seats.segment) {
                    segmentFormArray.push({
                        origin: classAvailabilitySeatData.origin ? classAvailabilitySeatData.origin : [],
                        destination: classAvailabilitySeatData.destination ? classAvailabilitySeatData.destination : []
                    } as ClassSegmentForm);
                }
            } else {
                segmentFormArray.push( {
                    origin: [],
                    destination: []
                } as ClassSegmentForm);
            }

            classBookingFormGroupArray.push({
                condSelect: classBkgDataUnit.comparator,
                seatsUnit: segmentFormArray,
                operators: classBkgDataUnit.seats.seatComparator,
                numbers: classBkgDataUnit.seats.count
            } as ClassBookingFormGroup);
        }

        const classBookingForm = {
            classesBookingUnit: classBookingFormGroupArray
        } as ClassBookingComponentForm;

        if (classBookingForm) {
            this.setFormValues(classBookingForm);
        }
    }

    private setFormValues(classBookingForm: ClassBookingComponentForm) {
        const classesBookingUnitsLength = classBookingForm.classesBookingUnit.length;
        const classBookingUnits = this.classesBookingGroup.get('classesBookingUnit') as FormArray;

        let i: number;
        let j: number;

        // Create empty class booking forms
        for (i = 0; i < classesBookingUnitsLength ; i++ ) {
            classBookingUnits.push(this.createClassBookingUnit());
        }

        classBookingUnits.removeAt(i);

        // create empty O&D forms
        i = 0;
        for (const classBookingFormUnit of classBookingForm.classesBookingUnit) {
            j = 0;
            const originAndDestFormUnits = this.classBookingFormArray.controls[i].get('seatsUnit') as FormArray;
            for ( const orginDestination of classBookingFormUnit.seatsUnit) {
                originAndDestFormUnits.push(this.createSeatsUnitFormGroup());
                j++;
            }
            this.removeSeatsUnitFormGroup(i, j);
            i++;
        }
          // Push service response data into empty forms
        (this.classesBookingGroup as FormGroup).patchValue(classBookingForm, { onlySelf: true });
    }

    private createClassBookingUnit() {
        return this.fb.group({
            condSelect : 'EQ',
            seatsUnit: this.fb.array([this.createSeatsUnitFormGroup()]),
            bookedClasses: [''],
            cabinClasses: [[]],
            numbers: [''],
            operators: ['GT']
        });
    }

    private createSeatsUnitFormGroup() {
        return this.fb.group({
            origin: [[]],
            destination: [[]]
        });
    }

    private addSeatsUnitFormGroup(j: number) {
        const control = this.classesBookingGroup.get('classesBookingUnit')['controls'][j].get('seatsUnit') as FormArray;
        control.push(this.createSeatsUnitFormGroup());
    }

    private removeSeatsUnitFormGroup(j: number, i: number) {
        const control = this.classesBookingGroup.get('classesBookingUnit')['controls'][j].get('seatsUnit') as FormArray;
        control.removeAt(i);
    }

    private addClassesBookingUnit() {
        const control = this.classesBookingGroup.get('classesBookingUnit') as FormArray;
        control.push(this.createClassBookingUnit());
    }

    private removeClassesBookingUnit(i: number) {
        const control = this.classesBookingGroup.get('classesBookingUnit') as FormArray;
        control.removeAt(i);
    }
}
