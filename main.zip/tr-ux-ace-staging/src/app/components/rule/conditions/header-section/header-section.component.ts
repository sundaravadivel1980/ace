import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { MatChipInputEvent } from '@angular/material';

import { TranslateService } from '@ngx-translate/core';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { RuleService, Rule, RuleRs, RqStandardPayload, RuleRq } from '@dxc/tr-ux-ace-services/dist/lib';
import { DialogsService } from '@dxc/tr-ux-ace-core/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { environment } from '../../../../../environments/environment';
import { AppConstants } from '../../../../app.constants';
import { RuleUtil } from '../../rule.util';
import { RuleParamsService } from '../../../../services/rule/rule-params.service';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';
import { RuleDetailChildForm } from '../../../../models/rule-form.model';

const COMMA = 188;
const ENTER = 13;

@Component({
    selector: 'header-section',
    templateUrl: 'header-section.component.html',
    styleUrls: ['./header-section.component.scss']
})
export class HeaderSectionComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public headerSection: FormGroup;

    public statuses: any[];
    public chipKeywords: any;
    public disableIcons: boolean = true;
    public types: any;
    public transactionIsRequired: boolean = false;
    public transactionErrorMsg: string;

    private URL: string = environment.apiUrl + AppConstants.ruleUrl;

    constructor(
        private fb: FormBuilder,
        private singletonService: AppSingletonService,
        private router: Router,
        private dialogsService: DialogsService,
        private paramsService: RuleParamsService,
        private ruleService: RuleService,
        private messageService: MessageService,
        private translateService: TranslateService,
        private validationService: RuleValidationService
        ) {
        const data = singletonService.ruleJsonStore;
        this.statuses = data.Status;
        this.types = data.TransactionTypes;
        this.translateService.get('error.required.field').subscribe(
            translation => {
                this.transactionErrorMsg = translation;
        });
    }

    public ngOnInit() {
        this.chipKeywords = this.childInput.keyword ? this.childInput.keyword : []; // Keywords initializing
        this.headerSection = this.fb.group({
            Status: ['', Validators.required], // Status initializing
            RuleName: ['', Validators.required], // RuleName initializing
            Keywords: [''],
            transactionType: ['', Validators.required],
            disableIcons: ''
        });

        this.setValues();

    }

    public setValues() {
        if (this.childInput.action) {
            const transIds = [];
            for ( const transTypes of this.types) {
                if (transTypes.id !== 'ALL') {
                    transIds.push(transTypes.id);
                }
            }
            const checkTrans = transIds.filter(item => this.childInput.action[0].transaction.indexOf(item) < 0);
            this.headerSection.patchValue({RuleName: this.childInput.name});
            this.headerSection.patchValue({Status: this.childInput.status});
            this.headerSection.patchValue({Keywords: this.childInput.keyword});
            this.headerSection.patchValue({transactionType: checkTrans.length > 0 ? this.childInput.action[0].transaction : ['ALL']});
            this.headerSection.get('disableIcons').setValue(true);
        }

        if (!this.childInput.status) {
            // this.headerSection.patchValue({Status: 'SAVED'});
            this.headerSection.get('Status').disable();
            this.headerSection.get('disableIcons').setValue(false);
        }
    }

    public getValues() {
        const data = this.singletonService.ruleJsonStore;
        const transIds = [];
        for ( const transTypes of data.TransactionTypes) {
          if (transTypes.id !== 'ALL') {
            transIds.push(transTypes.id);
          }
        }
        let transactionTypeCheck: any = [];
        if (this.headerSection.get('transactionType').value.length > 0) {
          transactionTypeCheck = this.headerSection.get('transactionType').value.find(function(obj) { return obj === 'ALL'; });
        }

        const transactionValue = transactionTypeCheck === 'ALL' ? transIds : this.headerSection.get('transactionType').value;

        const keywords = this.headerSection.get('Keywords').value ? this.headerSection.get('Keywords').value : [];
        const ruleName =  this.headerSection.get('RuleName').value;
        const statusValue =  this.headerSection.get('Status').value ? this.headerSection.get('Status').value : 'SAVED';

        return {
            transaction : transactionValue,
            keyword : keywords,
            name : ruleName,
            status : statusValue
        };
    }

    public validate() {
        let hasErrors = false;
        if (!this.headerSection.get('RuleName').value) {
            this.validationService.showRequiredFieldError(this.headerSection.get('RuleName'));
            this.validationService.addGlobalError('acegui.rules.messages.header.rule.name.required');
            hasErrors = true;
        }
        if (this.headerSection.get('transactionType').value.length === 0) {
            this.validationService.addGlobalError('acegui.rules.messages.header.transaction.type.required');
            this.transactionIsRequired = true;
            hasErrors = true;
        } else {
            this.transactionIsRequired = false;
        }

        return hasErrors;
    }

    public add(event: MatChipInputEvent): void {
        const input = event.input;
        const value = event.value;
        if ((value || '').trim()) {
            this.chipKeywords.push(value.trim());
            this.headerSection.get('Keywords').setValue(this.chipKeywords);
        }
        if (input) {
            input.value = '';
        }
    }

    public remove(keyword: any): void {
        const index = this.chipKeywords.indexOf(keyword);
        if (index >= 0) {
            this.chipKeywords.splice(index, 1);
            this.headerSection.get('Keywords').setValue(this.chipKeywords);
        }
    }

    public enableIconLinks() {
        this.headerSection.get('Status').enable();
        this.headerSection.get('Status').setValue('SAVED');
        this.headerSection.get('disableIcons').setValue(true);
    }

    public deleteRule(ruleId: number, status: string) {
        let confirmMsg: string;
        this.messageService.clear();
        if (status === 'INACT' || status === 'SIMUL') {
        confirmMsg = 'This action will permanently delete this rule and will not be avaliable in the future to either copy or edit';
        } else {
        confirmMsg = 'Are you sure you want to do this?';
        }
        this.dialogsService
            .confirm('Confirm Dialog', confirmMsg)
            .subscribe(res => {
                if (res) {
                    this.ruleService.deleteRule(this.URL + '/' + ruleId).subscribe(
                        (ruleResponse: RuleRs) => {
                            if (ruleResponse.rsStandardPayload.success) {
                                this.messageService.success('Rule Deleted Successfully', true);
                                this.router.navigate(['/rule']);
                            } else {
                                this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                            }
                        },
                        (error: HttpErrorResponse ) => {
                            this.messageService.error(error.status + '---' + error.message);
                        }
                    );
                } else {
                    this.messageService.warn('Delete action cancelled');
                }
        });
    }

    public exportRule(ruleId: number, ruleVersion: number) {
        const ruleArray = [];
        const rule = new Rule();
        rule.id = ruleId;
        rule.version = ruleVersion;
        ruleArray.push(rule);
        RuleUtil.downloadExportData(ruleArray, this.ruleService, this.messageService);
    }

    public deactivateRule(id: number, version: number) {
        this.dialogsService
            .confirm('Confirm Dialog', 'Are you sure you want to do this?')
            .subscribe(res => {
                if (res) {
                    this.childInput.status = 'INACT';
                    const requestPayload = {
                        correlationId: '1', pointOfSale: null
                    } as RqStandardPayload;

                    const ruleData =  {
                        rqStandardPayload: requestPayload,
                        rule: [this.childInput]
                    } as RuleRq;

                    this.ruleService.updateRule(this.URL, ruleData).subscribe(
                        (ruleResponse: RuleRs) => {
                            if (ruleResponse.rsStandardPayload.success) {
                                this.messageService.success('Rule Deactivated Successfully', true);
                                this.router.navigate(['/rule']);
                            } else {
                                this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                            }
                        },
                        (error: HttpErrorResponse) => {
                        this.messageService.error(error.status + '---' + error.message);
                        }
                    );
                }
        });
    }

    public copyRule(id: number, version: number) {
        this.paramsService.params = {ruleId: 0, ruleVersion: 0, ruleAction: this.childInput.type,
             ruleNew: true, ruleTime: null, copyId: id, copyRuleVersion: version};
        this.router.navigate(['/rule/detail', 0 ]);
    }
}
