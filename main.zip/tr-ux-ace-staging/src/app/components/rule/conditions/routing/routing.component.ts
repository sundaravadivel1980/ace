import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { RoutingCondition, Routing, Rule } from '@dxc/tr-ux-ace-services/dist/lib';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, DropdownModel, RoutingComponentForm, RoutingFormGroup } from '../../../../models/rule-form.model';
import { GroupType } from '../../../../models/group-type';
import { CarrierConfig } from '../../../../models/carrier-config';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';
import { AppUtil } from '../../../../utility/app-util';

@Component({
    selector: 'routing',
    templateUrl: 'routing.component.html',
    styleUrls: ['routing.component.scss']
})

export class RoutingComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public routingFormGroup: FormGroup;
    public routingConditionDataArray: RoutingCondition[];

    public domesticInternational: DropdownModel[];
    public connectTypes: DropdownModel[];
    public directNonstops: DropdownModel[];
    public carriersList: DropdownModel[];

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private validationService: RuleValidationService) {
        this.domesticInternational = this.singletonService.ruleJsonStore.RoutingTypes;
        this.connectTypes = this.singletonService.ruleJsonStore.RoutingConnectTypes;
        this.directNonstops = this.singletonService.ruleJsonStore.RoutingCategorys;
    }
    public ngOnInit() {
        const groupList = GroupType.getGroupList('Carrier Grouping', this.singletonService.groupTypes);
        const airlineList = CarrierConfig.getAirlines(this.singletonService.airlines);
        this.carriersList = groupList.concat(airlineList) as DropdownModel[];

        this.routingFormGroup = this.fb.group({
            routingUnit: this.fb.array([this.createRoutingUnit()])
        });
        this.setValues();
    }

    public checkboxChecked(i: number) {
        if (this.routingFormArray.controls[i].get('direct').value === false &&
           this.routingFormArray.controls[i].get('nonstop').value === false  ) {
                this.routingFormArray.controls[i].get('connectType').enable();
           }else {
                this.routingFormArray.controls[i].get('connectType').reset();
                this.routingFormArray.controls[i].get('carrier').reset();
                this.routingFormArray.controls[i].get('connectType').disable();
        }

    }

    public enableDisableOptions(i: number, val: string) {
        if(val === 'Any'){
            this.routingFormArray.controls[i].get('direct').enable();
            this.routingFormArray.controls[i].get('nonstop').enable();
        } else {
        this.routingFormArray.controls[i].get('direct').disable();
        this.routingFormArray.controls[i].get('direct').setValue(false);
        this.routingFormArray.controls[i].get('nonstop').disable();
        this.routingFormArray.controls[i].get('nonstop').setValue(false);
        }
    }

    public createRoutingUnit() {
        return this.fb.group({
            domesticInternational : '',
            direct: false,
            nonstop: false,
            connectionCount: '',
            connectType: '',
            carrier: ''
        });
    }

    get routingFormArray(): FormArray {
        return this.routingFormGroup.get('routingUnit') as FormArray;
    }

    public addRoutingUnit() {
        this.routingFormArray.push(this.createRoutingUnit());
    }

    public removeRoutingUnit(i: number) {
        this.routingFormArray.removeAt(i);
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.routingConditionDataArray = RuleUtil.getComponenetData(rule, 'routingCondition');
        }
        if ( this.routingConditionDataArray && this.routingConditionDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): RoutingCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        const routingConditionDataArray = [];

        for (const routingFormUnit of this.routingFormArray.value) {
            console.log(routingFormUnit);
            const routingLogicalUnitData = new Routing();
            if (routingFormUnit.connectionCount) {
                routingLogicalUnitData.connectionCount = routingFormUnit.connectionCount.split(',');
            }
            routingLogicalUnitData.direct = routingFormUnit.direct ? true : false;
            routingLogicalUnitData.nonStop = routingFormUnit.nonstop ? true : false;
            if (routingFormUnit.domesticInternational !== 'Either') {
                routingLogicalUnitData.domestic = routingFormUnit.domesticInternational === 'Domestic' ? true : false;
            }
            if (!routingLogicalUnitData.direct && !routingLogicalUnitData.nonStop) {
                if (AppUtil.isNullOrBlank(routingFormUnit.connectType) || routingFormUnit.connectType === 'ANY') {
                    routingLogicalUnitData.connectType = null;
                } else {
                    routingLogicalUnitData.connectType = routingFormUnit.connectType;
                }
                routingLogicalUnitData.carrier = routingFormUnit.connectType === 'INTERLINE' ?
                                        routingFormUnit.carrier : [];
            }
            routingConditionDataArray.push({
                comparator: 'EQ',
                routing: routingLogicalUnitData
            } as RoutingCondition);
        }
        return routingConditionDataArray;
    }

    public validate() {
        this.removeEmptyForms();
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyRoutingFormUnitArray = [];
        this.isEmptyCondition = false;

        for (const routingFormUnit of this.routingFormArray.controls) {
            let emptyForm = true;
            if (routingFormUnit.get('connectionCount').value
                || routingFormUnit.get('direct').value
                || routingFormUnit.get('nonstop').value
                || (routingFormUnit.get('domesticInternational').value
                && routingFormUnit.get('domesticInternational').value !== 'Either')
                || (routingFormUnit.get('connectType').value && routingFormUnit.get('connectType').value !== 'ANY')) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyRoutingFormUnitArray.push(i);
            }
            i++;
        }
        if (this.routingFormArray.controls.length === emptyRoutingFormUnitArray.length) {
            this.isEmptyCondition = true;
            emptyRoutingFormUnitArray.splice(0, 1);
        }
        for (const emptyForm of emptyRoutingFormUnitArray.reverse()){
            this.removeRoutingUnit(emptyForm);
        }
    }

    private setFormValuesFromData() {
        const routingFormUnitArray = [];

        for (const routingDataUnit of this.routingConditionDataArray) {
            const routingFormUnit = {
                domesticInternational: routingDataUnit.routing.hasOwnProperty('domestic') ? routingDataUnit.routing.domestic ?
                                        'Domestic' : 'International' : 'Either',
                connectType: routingDataUnit.routing.connectType,
                connectionCount: routingDataUnit.routing.connectionCount ? routingDataUnit.routing.connectionCount.join() : '',
                direct: routingDataUnit.routing.direct,
                nonstop: routingDataUnit.routing.nonStop,
                carrier: routingDataUnit.routing.carrier
            } as RoutingFormGroup;

            routingFormUnitArray.push(routingFormUnit);
        }
        const routingComponentFormModel =  {
            routingUnit: routingFormUnitArray
        } as RoutingComponentForm;

        if (routingComponentFormModel) {
             this.setFormValues(routingComponentFormModel);
        }
    }

    private setFormValues(routingComponentFormModel: RoutingComponentForm) {
        const routingFormUnitArray = this.routingFormGroup.get('routingUnit') as FormArray;
        for (const routingFormUnit of routingComponentFormModel.routingUnit){
            routingFormUnitArray.push(this.createRoutingUnit());
        }
        this.removeRoutingUnit(0);
        (this.routingFormGroup as FormGroup).patchValue(routingComponentFormModel, { onlySelf: true });

        let i: number = 0;
        for (const routingtLogicalUnit of routingComponentFormModel.routingUnit){
            this.checkboxChecked(i);
            i++;
        }
    }
}
