import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';

import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';
import { Rule, ClassCondition, ClassClosureActionInput, ClassSuppressionActionInput } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import { CarrierConfig } from '../../../../models/carrier-config';
import { AppConstants } from '../../../../app.constants';
import { AppUtil } from '../../../../utility/app-util';

import { RuleDetailChildForm, ClassesComponentForm, ClassesFormGroup, DropdownModel } from '../../../../models/rule-form.model';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

@Component({
    selector : 'classes',
    templateUrl : 'classes.component.html',
    styleUrls : ['./classes.component.scss']
})
export class ClassesComponent implements RuleDetailChildForm, OnInit {

    @Input() public childInput: Rule;

    // First level form group. The base for all the sub form groups of classes component
    public classesGroup: FormGroup;
    public classConditionDataArray: ClassCondition[];

    public operators: any[];
    public waitlistOptions: any[];

    public bookingClassesInput: DropdownModel[];
    public cabinClassesInput: DropdownModel[];
    public showWaitList: boolean = false;

    private cabinViewData: string[] = [];
    private bookingViewData: string[] = [];

    // Will be true if there is no input value given by the user for class availability condition
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private validationService: RuleValidationService) {
        const data = singletonService.ruleJsonStore;
        this.operators = data.Operators;
        this.waitlistOptions = data.WaitLists;
    }

    public ngOnInit() {

        // Cabin and booking classes from carrier config
        this.cabinClassesInput = CarrierConfig.getCabinList('Cabin Types', this.singletonService.carrierPreferences);
        this.bookingClassesInput = CarrierConfig.getBookingClassesList('Class Classes', this.singletonService.carrierPreferences);

        if (this.childInput.type === AppConstants.ACTION_CLASS_CLOSSURE) {
            this.showWaitList = true;
        }
        this.classesGroup = this.fb.group({
            classesUnit: this.fb.array([this.createClassFormGroup()]),
            waitlistRdo: ['CLOSED']
        });

        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.classConditionDataArray = RuleUtil.getComponenetData(rule, 'classCondition');
        }
        if ( this.classConditionDataArray && this.classConditionDataArray.length > 0 ) {
            let actionInput: ClassClosureActionInput;
            if (rule.type === AppConstants.ACTION_CLASS_CLOSSURE) {
                actionInput = rule.action[0].classClosureAction.actionInput;
            }
            this.setFormValuesFromData(actionInput);
        }
    }

    public getValues(): ClassCondition[] {

        this.validate();

        if (this.hasErrors) {
            return null;
        }

        const classConditionArray = [];
        for (const classFormUnit of this.classFormArray.value) {
            const classCondition = {
                comparator: classFormUnit.condSelect,
                classOfService: classFormUnit.bookedClasses.selectedSeats ?
                                classFormUnit.bookedClasses.selectedSeats.split(',') : [],
                cabin: classFormUnit.cabinClasses
            } as ClassCondition;
            classConditionArray.push(classCondition);
        }
        return classConditionArray;
    }

    public getActionInput() {
        if (this.childInput.type === AppConstants.ACTION_CLASS_CLOSSURE) {
            const classClosureActionInput = new ClassClosureActionInput();
            classClosureActionInput.unblock = true;
            classClosureActionInput.waitlistClose = this.classesGroup.get('waitlistRdo').value === 'WAITLIST' ? true : false;
            return classClosureActionInput;
        } else if (this.childInput.type === AppConstants.ACTION_CLASS_SUPPRESSION) {
            const classClosureActionInput = new ClassSuppressionActionInput();
            return classClosureActionInput;
        }
    }

    public addClassesUnit() {
        const classFormArray =  this.classesGroup.get('classesUnit') as FormArray;
        classFormArray.push(this.createClassFormGroup());
    }

    public removeClassesUnit(i: number) {
        const classFormArray = this.classesGroup.get('classesUnit') as FormArray;
        classFormArray.removeAt(i);
    }

    public clearDatas(i) {
        this.bookingViewData.splice(i, 1);
        this.cabinViewData.splice(i, 1);
    }

    get classFormArray(): FormArray{
        return this.classesGroup.get('classesUnit') as FormArray;
    }

    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        if (this.isEmptyCondition) {
            // Classes condition is required for all the actions
            this.validationService.addGlobalError('acegui.rules.messages.class.condition');
            this.hasErrors = true;
        } else {
            for (const classFormUnit of this.classFormArray.controls) {
                if (RuleUtil.isBookingClassSelected(classFormUnit)
                  && AppUtil.isArrayValueExists(classFormUnit, 'cabinClasses')) {
                    // When booking and cabin provided
                    this.validationService.addGlobalError('acegui.rules.messages.both.classes.and.cabin.not.allowed');
                    this.hasErrors = true;
                }
            }
        }
    }

    private setFormValuesFromData(actionInput) {
        const classesFormModel = new ClassesComponentForm();
        const classesFormUnitArray = [];

        for ( const classDataUnit of this.classConditionDataArray){
            this.cabinViewData.push(classDataUnit.cabin ? classDataUnit.cabin : '');
            this.bookingViewData.push(classDataUnit.classOfService ? classDataUnit.classOfService : '');
            const classFormUnit = new ClassesFormGroup();
            classFormUnit.condSelect = classDataUnit.comparator;
            classesFormUnitArray.push(classFormUnit);
        }
        if (actionInput) {
            classesFormModel.waitlistRdo = actionInput.waitlistClose ? 'WAITLIST' : 'CLOSED';
        }
        classesFormModel.classesUnit = classesFormUnitArray;
        if (classesFormModel) {
            this.setFormValues(classesFormModel);
        }
    }

    private setFormValues(classesFormModel: ClassesComponentForm) {
        // Create the empty forms first and then the patch it with the rule data
        const classFormArray =  this.classesGroup.get('classesUnit') as FormArray;
        for (const classFormUnit of classesFormModel.classesUnit){
            classFormArray.push(this.createClassFormGroup());
        }
        this.removeClassesUnit(0);
        (this.classesGroup as FormGroup).patchValue(classesFormModel, { onlySelf: true });
    }

    private setActionInputValues(actionInput) {
        this.classFormArray.controls[0].get('waitlistRdo').setValue(true);
    }

    private removeEmptyForms() {
        let i: number = 0;
        const emptyClassesFormunits = [];
        this.isEmptyCondition = false;

        for (const classFormUnit of this.classFormArray.controls) {
            let emptyForm = true;
            if (RuleUtil.isBookingClassSelected(classFormUnit)
                 || AppUtil.isArrayValueExists(classFormUnit, 'cabinClasses')) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyClassesFormunits.push(i);
            }

            i++;
        }
        if (this.classFormArray.controls.length === emptyClassesFormunits.length) {
            this.isEmptyCondition = true;
            emptyClassesFormunits.splice(0, 1);
        }
        for (const emptyUnit of emptyClassesFormunits.reverse()){
            this.removeClassesUnit(emptyUnit);
        }
    }

    private createClassFormGroup() {
        return this.fb.group({
            condSelect: 'EQ',
            bookedClasses: ['', Validators.required],
            cabinClasses: ''
        });
    }

}
