import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';

import { AppSingletonService } from '../../../../app-singleton.service';
import { Rule, MarketFareActionInput, ClassCondition } from '@dxc/tr-ux-ace-services/dist/lib';
import { RuleDetailChildForm, DropdownModel, MarketFareComponentForm, MarketFareFormGroup } from '../../../../models/rule-form.model';
import { RuleUtil } from '../../rule.util.ts';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

@Component({
    selector: 'base-fare-adjustment',
    templateUrl: 'base-fare-adjustment.component.html',
    styleUrls: ['base-fare-adjustment.component.scss']
})
export class BaseFareAdjustmentComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public baseFareAdjustmentGroup: FormGroup;
    public carrierPrefCurrency: string;
    private baseFareActionInput: MarketFareActionInput;

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
        private singletonService: AppSingletonService,
        private messageService: MessageService,
        private translateService: TranslateService,
        private ruleValidation: RuleValidationService) {
    }

    public ngOnInit() {
        this.carrierPrefCurrency = this.singletonService.carrierCurrency;
        this.baseFareAdjustmentGroup = this.fb.group({
            baseFareAdjustmentUnit: this.fb.array([this.createBaseFareFormGroup()])
        });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.baseFareActionInput = RuleUtil.getComponenetData(rule, 'actionInput');
        }
        if (this.baseFareActionInput) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): MarketFareActionInput {
        this.validate();

        if (this.hasErrors) {
            return null;
        }
        const dataArray = [];
        for (const baseFareAdjustmentUnit of this.baseFareFormArray.value) {
            const baseFareeAdjustmentActionInputData = new MarketFareActionInput();
            baseFareeAdjustmentActionInputData.amount = baseFareAdjustmentUnit.setFare;
            baseFareeAdjustmentActionInputData.changeAmount = baseFareAdjustmentUnit.amount ?
                baseFareAdjustmentUnit.amountSign + baseFareAdjustmentUnit.amount : '';
            baseFareeAdjustmentActionInputData.changePercent = baseFareAdjustmentUnit.basefarePercentage ?
                baseFareAdjustmentUnit.basefarePercentageSign + baseFareAdjustmentUnit.basefarePercentage : '';
            baseFareeAdjustmentActionInputData.maximum = baseFareAdjustmentUnit.maxAmount;
            baseFareeAdjustmentActionInputData.minimum = baseFareAdjustmentUnit.minAmount;
            dataArray.push(baseFareeAdjustmentActionInputData);
        }

        return dataArray[0];
    }

    public validate() {
        this.hasErrors = false;
        this.removeEmptyForms();

        if (this.isEmptyCondition) {
            this.hasErrors = true;
            this.ruleValidation.addGlobalError('acegui.rules.messages.base.fare.condition.required');
        } else {
            for (const baseFareFormUnit of this.baseFareFormArray.controls) {
                if (baseFareFormUnit.value.amount && baseFareFormUnit.value.basefarePercentage) {
                    // Both Amount and percentage not valid. User can provide amount or percentage
                    this.hasErrors = true;
                    this.ruleValidation.addGlobalError('acegui.rules.messages.base.fare.amount.and.percent.not.allowed');
                } else if (baseFareFormUnit.value.setFare &&
                    (baseFareFormUnit.value.amount
                        || baseFareFormUnit.value.basefarePercentage
                        || baseFareFormUnit.value.minAmount
                        || baseFareFormUnit.value.maxAmount)) {
                    // Set base fare cannot be given with any other combination
                    this.hasErrors = true;
                    this.ruleValidation.addGlobalError('acegui.rules.messages.base.fare.set.fare.cannot.be.combined');
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;
        for (const baseFareFormUnit of this.baseFareFormArray.controls) {
            let emptyForm = true;
            if (baseFareFormUnit.value.amount || baseFareFormUnit.value.basefarePercentage ||
                baseFareFormUnit.value.setFare || baseFareFormUnit.value.minAmount || baseFareFormUnit.value.maxAmount) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyGroup of emptyForms.reverse()) {
            this.removeBaseFareAdjustmentUnit(emptyGroup);
        }
        if (this.baseFareFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addBaseFareAdjustmentUnit();
        }
    }

    public enableDisableFields(value) {
        const fieldsList = ['amount', 'basefarePercentage', 'basefarePercentageSign', 'amountSign', 'minAmount', 'maxAmount'];
        if (value === '') {
            for (const field of fieldsList) {
                // this.bidPriceFormArray.controls[0].get(field).reset();
                this.baseFareFormArray.controls[0].get(field).enable();
            }
        } else {
            for (const field of fieldsList) {
                this.baseFareFormArray.controls[0].get(field).reset();
                this.baseFareFormArray.controls[0].get(field).disable();
            }
        }
    }

    get baseFareFormArray(): FormArray {
        return this.baseFareAdjustmentGroup.get('baseFareAdjustmentUnit') as FormArray;
    }

    private createBaseFareFormGroup() {
        return this.fb.group({
            amount: [''],
            amountSign: [''],
            basefarePercentage: [''],
            basefarePercentageSign: [''],
            minAmount: [''],
            maxAmount: [''],
            setFare: [''],
            bookedClasses: '',
            cabinClasses: ''
        });
    }

    get baseFareUnit(): FormArray {
        return this.baseFareAdjustmentGroup.get('baseFareAdjustmentUnit') as FormArray;
    }

    private addBaseFareAdjustmentUnit() {
        this.baseFareUnit.push(this.createBaseFareFormGroup());
    }

    private removeBaseFareAdjustmentUnit(i: number) {
        this.baseFareUnit.removeAt(i);
    }

    private setFormValuesFromData() {
        const marketFareFromModelGroupData = [];

        const marketFareFromModelGroup = {} as MarketFareFormGroup;
        if (this.baseFareActionInput.changeAmount) {
            marketFareFromModelGroup.amount = Math.abs(this.baseFareActionInput.changeAmount);
            marketFareFromModelGroup.amountSign = this.baseFareActionInput.changeAmount > 0 ? '+' : '-';
        }
        if (this.baseFareActionInput.changePercent) {
            marketFareFromModelGroup.basefarePercentageSign = this.baseFareActionInput.changePercent > 0 ? '+' : '-';
            marketFareFromModelGroup.basefarePercentage = Math.abs(this.baseFareActionInput.changePercent);
        }
        marketFareFromModelGroup.maxAmount = this.baseFareActionInput.maximum;
        marketFareFromModelGroup.minAmount = this.baseFareActionInput.minimum;
        marketFareFromModelGroup.setFare = this.baseFareActionInput.amount;
        marketFareFromModelGroupData.push(marketFareFromModelGroup);
        const baseFareFormModel = {
            baseFareAdjustmentUnit: marketFareFromModelGroupData
        } as MarketFareComponentForm;

        if (baseFareFormModel) {
            this.setFormValues(baseFareFormModel);
        }
        marketFareFromModelGroup.setFare ? this.enableDisableFields(marketFareFromModelGroup.setFare) : null;
    }

    private setFormValues(marketFareFromModel: MarketFareComponentForm) {
        const control = this.baseFareAdjustmentGroup.get('baseFareAdjustmentUnit') as FormArray;
        for (const baseFareAdjustmentUnit of marketFareFromModel.baseFareAdjustmentUnit) {
            control.push(this.createBaseFareFormGroup());
        }
        this.removeBaseFareAdjustmentUnit(0);
        (this.baseFareAdjustmentGroup as FormGroup).patchValue(marketFareFromModel, { onlySelf: true });
    }
}
