import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { DropdownModel } from '../../../../models/rule-form.model';

@Component({
    selector: 'frequent-flyer',
    templateUrl: 'frequent-flyer.component.html',
    styleUrls: ['./frequent-flyer.component.scss']
})

export class FrequentFlyerComponent implements OnInit {
    @Input() public childInput: any;
    @Output() public childControls = new EventEmitter();
    public frequentFlyerForm: FormGroup;
    public operators: DropdownModel[];
    public flyerProgram: DropdownModel[];
    public tierLevel: DropdownModel[];
    public listOfAirport: DropdownModel[];

    constructor(private _fb: FormBuilder, private singletonService: AppSingletonService) {
        this.listOfAirport = singletonService.airportJsonStore;
        this.operators = singletonService.ruleJsonStore.Operators;
        this.flyerProgram = singletonService.ruleJsonStore.FrequentFlyerProgram;
        this.tierLevel = singletonService.ruleJsonStore.FrequentFlyerTierLevel;
     }
    public ngOnInit() {
        this.frequentFlyerForm = this._fb.group({FrequentFlyer: this._fb.array([this.initFrequentFlyer()])});
        this.childControls.emit(this.frequentFlyerForm);
        this.frequentFlyerForm.valueChanges.subscribe(() => {
            this.childControls.emit(this.frequentFlyerForm);
        });
    }

    public initFrequentFlyer() {
        return this._fb.group({
            operators: ['EQ', Validators.required],
            flyerProgram: ['', Validators.required],
            tierLevel: ['', Validators.required]
        });
    }
    public addFrequentFlyer() {
        const control = this.frequentFlyerForm.get('FrequentFlyer') as FormArray;
        control.push(this.initFrequentFlyer());
    }
    public removeFrequentFlyer(i: number) {
        const control = this.frequentFlyerForm.get('FrequentFlyer') as FormArray;
        control.removeAt(i);
    }
}
