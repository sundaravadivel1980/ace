import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, AbstractControl } from '@angular/forms';

import { Rule, DateTimeCondition, DateOrRange } from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';
import { RuleUtil } from '../../rule.util.ts';
import { RuleDetailChildForm, ArrivalTimeComponentForm, TimeFormGroup, DropdownModel } from '../../../../models/rule-form.model';

@Component({
    selector: 'arrival-time',
    templateUrl: 'arrival-time.component.html',
    styleUrls: ['./arrival-time.component.scss']
})
export class ArrivalTimeGroupComponent implements RuleDetailChildForm, OnInit {
    @Input() private childInput: Rule;

    private arrivalTimeGroup: FormGroup;
    private arrivalTimeComponentData: DateTimeCondition[];

    private operators: DropdownModel[];
    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private appSingletonService: AppSingletonService,
                private validationService: RuleValidationService) {
        this.operators = this.appSingletonService.ruleJsonStore.Operators as DropdownModel[];
    }

    public ngOnInit() {
        this.arrivalTimeGroup = this.fb.group({
            arrivalTime: this.fb.array([this.createArrivalTimeFormGroup()])
        });

        this.setValues();
    }

    get arrivalTimeFormArray(): FormArray {
        return this.arrivalTimeGroup.get('arrivalTime') as FormArray;
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.arrivalTimeComponentData = RuleUtil.getComponenetData(rule, 'arrivalTimeCondition');
        }
        if (this.arrivalTimeComponentData && this.arrivalTimeComponentData.length > 0) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): DateTimeCondition[] {
        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        const arrivalTimeConditionDataArray = [];
        for (const arrivalTimeFormUnit of this.arrivalTimeFormArray.value) {
            const dateAndTime = new DateOrRange();
            if (arrivalTimeFormUnit.startHours) {
                dateAndTime.startDateTime = arrivalTimeFormUnit.startHours + ':' + arrivalTimeFormUnit.startMinutes + ':00';
            }
            if (arrivalTimeFormUnit.endHours) {
                dateAndTime.endDateTime = arrivalTimeFormUnit.endHours + ':' + arrivalTimeFormUnit.endMinutes + ':00';
            }
            arrivalTimeConditionDataArray.push({
                comparator: arrivalTimeFormUnit.operator,
                dateOrRange: dateAndTime
            } as DateTimeCondition);
        }
        return arrivalTimeConditionDataArray;
    }
    public validate() {

        this.removeEmptyForms();
        this.hasErrors = false;

        for (const arrivalTimeFormUnit of this.arrivalTimeFormArray.controls) {
            if (arrivalTimeFormUnit.get('endHours').value || arrivalTimeFormUnit.get('startHours').value ||
                arrivalTimeFormUnit.get('startMinutes').value || arrivalTimeFormUnit.get('endMinutes').value) {
                if (!arrivalTimeFormUnit.get('endHours').value) {
                    this.addError(arrivalTimeFormUnit, 'endHours', 'endMinutes');
                    this.validationService.addGlobalError('acegui.rules.messages.end.time.required');
                    this.hasErrors = true;
                } else if (!arrivalTimeFormUnit.get('startHours').value) {
                    this.addError(arrivalTimeFormUnit, 'startHours', 'startMinutes');
                    this.validationService.addGlobalError('acegui.rules.messages.start.time.required');
                    this.hasErrors = true;
                } else if (arrivalTimeFormUnit.get('endHours').value < arrivalTimeFormUnit.get('startHours').value) {
                    this.addError(arrivalTimeFormUnit, 'endHours', 'endMinutes');
                    this.validationService.addGlobalError('acegui.rules.messages.start.time.cannot.be.greater');
                    this.hasErrors = true;
                } else if ((arrivalTimeFormUnit.get('endHours').value === arrivalTimeFormUnit.get('startHours').value) &&
                    arrivalTimeFormUnit.get('endMinutes').value < arrivalTimeFormUnit.get('startMinutes').value) {
                    this.addError(arrivalTimeFormUnit, 'endHours', 'endMinutes');
                    this.validationService.addGlobalError('acegui.rules.messages.start.time.cannot.be.greater');
                    this.hasErrors = true;
                } else {
                    arrivalTimeFormUnit.get('endHours').setErrors(null);
                    arrivalTimeFormUnit.get('endMinutes').setErrors(null);
                    arrivalTimeFormUnit.get('startHours').setErrors(null);
                    arrivalTimeFormUnit.get('startMinutes').setErrors(null);
                }
            }
        }
    }

    private addError(arrivalTimeFormUnit: AbstractControl, hours: string, minutes: string): AbstractControl {
        arrivalTimeFormUnit.get(hours).setErrors({ errorVal: true });
        arrivalTimeFormUnit.get(minutes).setErrors({ errorVal: true });
        return arrivalTimeFormUnit;
    }

    private removeEmptyForms() {
        let i: number = 0;
        const emptyForms = [];
        this.isEmptyCondition = false;

        for (const arrivalTimeFormUnit of this.arrivalTimeFormArray.controls) {
            let emptyForm = true;
            if (arrivalTimeFormUnit.get('endHours').value || arrivalTimeFormUnit.get('startHours').value ||
                arrivalTimeFormUnit.get('startMinutes').value || arrivalTimeFormUnit.get('endMinutes').value) {
                emptyForm = false;
            }
            if (emptyForm) {
                emptyForms.push(i);
            }
            i++;
        }
        for (const emptyForm of emptyForms.reverse()) {
            this.removeArrivalTime(emptyForm);
        }
        if (this.arrivalTimeFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addArrivalTime();
        }
    }

    private setFormValuesFromData() {
        const arrivalTimeFormUnitArray = [];
        for (const arrivalTimeDataUnit of this.arrivalTimeComponentData) {
            const startTimeSplit = arrivalTimeDataUnit.dateOrRange.startDateTime ?
                arrivalTimeDataUnit.dateOrRange.startDateTime.split(':') : '';
            const endTimeSplit = arrivalTimeDataUnit.dateOrRange.endDateTime ?
                arrivalTimeDataUnit.dateOrRange.endDateTime.split(':') : '';

            const arrivalTimeFormUnit = {
                operator: arrivalTimeDataUnit.comparator,
                startHours: startTimeSplit[0],
                startMinutes: startTimeSplit[1],
                endHours: endTimeSplit[0],
                endMinutes: endTimeSplit[1]
            } as TimeFormGroup;

            arrivalTimeFormUnitArray.push(arrivalTimeFormUnit);
        }

        const arrTimeFormModel = {
            arrivalTime: arrivalTimeFormUnitArray
        } as ArrivalTimeComponentForm;

        if (arrTimeFormModel) {
            this.setFormValues(arrTimeFormModel);
        }
    }

    private createArrivalTimeFormGroup() {
        return this.fb.group({
            operator: 'EQ',
            startHours: '',
            startMinutes: '',
            endHours: '',
            endMinutes: ''
        });
    }

    private setFormValues(arrivalTimeFormModel: ArrivalTimeComponentForm) {
        const arrivalTimeFormUnitArray = this.arrivalTimeGroup.get('arrivalTime') as FormArray;
        for (const arrivalTimeFormUnit of arrivalTimeFormModel.arrivalTime) {
            arrivalTimeFormUnitArray.push(this.createArrivalTimeFormGroup());
        }
        this.removeArrivalTime(0);
        (this.arrivalTimeGroup as FormGroup).patchValue(arrivalTimeFormModel, { onlySelf: true });
    }

    private addArrivalTime() {
        this.arrivalTimeFormArray.push(this.createArrivalTimeFormGroup());
    }

    private removeArrivalTime(i: number) {
        this.arrivalTimeFormArray.removeAt(i);
    }
}
