import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, AfterViewChecked } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { AppSingletonService } from '../../../../app-singleton.service';
import { DropdownModel } from '../../../../models/rule-form.model';
import { DxcDisableService } from '../../../../services/rule/dxc-disabe.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'cabin-classes',
    templateUrl: 'cabin-classes.component.html',
    styleUrls: ['./cabin-classes.component.scss']
})
export class CabinClassesComponent implements OnInit, OnDestroy {
    @Input() public childInput: any;
    @Input() public cabinClassesInput: DropdownModel[];
    @Output() public subChildOutput = new EventEmitter();
    public disableAllCabins: boolean;
    public cabinClassesGroup: FormGroup;
    private subscription: Subscription;
    constructor(private fb: FormBuilder, private dxcDisable: DxcDisableService) {
    }

    public ngOnInit() {
        this.cabinClassesGroup = this.fb.group(this.dynamicFormFields());
        const checkedCabins = [];
        this.cabinClassesGroup.valueChanges.subscribe(cabinClasses => {
            Object.keys(cabinClasses).forEach(field => {
                if (cabinClasses[field] && cabinClasses[field] === true && field !== 'allCabin' && checkedCabins.indexOf(field) == -1) {
                    checkedCabins.push(field);
                } else if (field === 'allCabin' && !cabinClasses[field]) {
                    checkedCabins.length = 0;
                }
            });
            this.subChildOutput.emit(checkedCabins);
        });
        this.subChildOutput.emit(checkedCabins);
        this.dxcDisable.getBooking().subscribe(
            data => {
                //  this.enableDisableAllFields(data);
            },
            error => {
                console.log(error);
            });

        if (this.childInput) {
            const isAllChecked = [];
            for (const cabin of this.childInput) {
                this.cabinClassesGroup.get(cabin).setValue(true);
            }
            if (this.childInput.length === this.cabinClassesInput.length) {
                this.cabinClassesGroup.get('allCabin').setValue(true);
            }
        }
    }

    public ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    public allCabinChecked() {
        for (const item of this.cabinClassesInput) {
            this.cabinClassesGroup.get(item.id).setValue(
                this.cabinClassesGroup.get('allCabin').value
            );
        }
        this.isAllCabinsFalse();
    }

    private enableDisableAllFields(data) {
        if (data === 'enable') {
            this.cabinClassesGroup.reset();
            this.cabinClassesGroup.enable();
        } else if (data === 'disable') {
            this.cabinClassesGroup.reset();
            this.cabinClassesGroup.disable();
        }
    }

    private dynamicFormFields() {
        const allFormFields = {};
        allFormFields['allCabin'] = [false];
        for (const item of this.cabinClassesInput) {
            allFormFields[item.id] = [false];
        }
        return allFormFields;
    }

    private cabinsChecked() {
        const isAllChecked = [];
        for (const item of this.cabinClassesInput) {
            isAllChecked.push(this.cabinClassesGroup.get(item.id).value);
        }
        this.cabinClassesGroup.get('allCabin').setValue(
            isAllChecked.every(function(item: boolean) {
                return item === true;
            })
        );
        this.isAllCabinsFalse();
    }

    private isAllCabinsFalse() {
        const isAllChecked = [];
        for (const item of this.cabinClassesInput) {
            isAllChecked.push(this.cabinClassesGroup.get(item.id).value);
        }
        isAllChecked.push(this.cabinClassesGroup.get('allCabin').value);
        const isAllFalse = isAllChecked.every(function(item: boolean) {
            return item === false || item === null;
        });
        const setCabins = isAllFalse ? 'enable' : 'disable';
        //  this.dxcDisable.setCabins(setCabins);
    }

}
