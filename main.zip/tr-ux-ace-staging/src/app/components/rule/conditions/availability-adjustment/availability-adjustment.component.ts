import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { Rule, AvailabilityActionInput, ClassCondition } from '@dxc/tr-ux-ace-services/dist/lib';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';
import {
    RuleDetailChildForm,
    AvailabilityAdjustmentComponentForm,
    AvailabilityAdjustmentFormGroup,
    DropdownModel
} from '../../../../models/rule-form.model';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateService } from '@ngx-translate/core';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';

@Component({
    selector: 'availability-adjustment',
    templateUrl: 'availability-adjustment.component.html',
    styleUrls: ['./availability-adjustment.component.scss']
})

export class AvailabilityAdjustmentComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;

    public availabilityAdjustmentForm: FormGroup;

    /**
     * Actually it is not array. There will be only one action input
     */
    private availAdjustDataActionInput: AvailabilityActionInput;

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private validationService: RuleValidationService) {
                    // empty constructor
    }

    public ngOnInit() {
        this.availabilityAdjustmentForm = this.fb.group({
            availabilityAdjustmentUnit: this.fb.array([this.crateAvailAdjFormGroup()])
        });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.availAdjustDataActionInput = RuleUtil.getComponenetData(rule, 'actionInput');
        }
        if (this.availAdjustDataActionInput) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): AvailabilityActionInput {
        this.validate();

        if (this.hasErrors) {
            return null;
        }

        const dataArray = [];
        for (const availAdjustUnit of this.aaFormArray.value) {
            const availabilityActionInput = new AvailabilityActionInput();
            availabilityActionInput.changeAmount =  availAdjustUnit.seats > 0 ?
             availAdjustUnit.seatsSign + availAdjustUnit.seats : '';
            availabilityActionInput.changePercent = availAdjustUnit.numbers > 0 ?
             availAdjustUnit.numbersSign + availAdjustUnit.numbers : '';
            availabilityActionInput.maximum = availAdjustUnit.maxSeats;
            availabilityActionInput.maximumIncrease = availAdjustUnit.increaseSeats;
            availabilityActionInput.overrideSegmentLimit = availAdjustUnit.override ? true : false;
            availabilityActionInput.useAuAvailability = availAdjustUnit.availability ? true : false;
            dataArray.push(availabilityActionInput);
        }
        return dataArray[0];
    }

    public validate() {
        const removeGroups = [];
        this.hasErrors = false;

        this.removeEmptyForms();

        if (this.isEmptyCondition) {
            this.validationService.addGlobalError('acegui.rules.messages.avail.adjust.condition.required');
            this.hasErrors = true;
        } else {
            for (const availAdjustFormUnit of this.aaFormArray.controls) {
                // Both seats and percentage not allowed. Only one is allowed
                if (availAdjustFormUnit.value.numbers && availAdjustFormUnit.value.seats) {
                    this.validationService.addGlobalError('acegui.rules.messages.avail.adjust.percentage.and.seat.not.allowed');
                    this.hasErrors = true;
                }

                // Percentage is required when maximum increase seats is given
                if (availAdjustFormUnit.value.increaseSeats && !availAdjustFormUnit.value.numbers) {
                    this.validationService.addGlobalError('acegui.rules.messages.avail.adjust.percentage.required');
                    this.hasErrors = true;
                }

                // If AU availability is selected, then no other adjustment allowed.
                if (availAdjustFormUnit.value.availability && (availAdjustFormUnit.value.override || availAdjustFormUnit.value.seats ||
                    availAdjustFormUnit.value.numbers || availAdjustFormUnit.value.maxSeats ||
                    availAdjustFormUnit.value.increaseSeats)) {
                        this.validationService.addGlobalError('acegui.rules.messages.avail.adjust.percentage.au.availability');
                        this.hasErrors = true;
                }
            }
        }
    }

    public removeEmptyForms() {
        let i: number = 0;
        const emptyGroups = [];
        this.isEmptyCondition = false;

        for (const availAdjustFormUnit of this.aaFormArray.controls) {
            let emptyForm = true;
            if (availAdjustFormUnit.value.availability || availAdjustFormUnit.value.override || availAdjustFormUnit.value.seats ||
                availAdjustFormUnit.value.numbers || availAdjustFormUnit.value.maxSeats ||
                availAdjustFormUnit.value.increaseSeats) {
                emptyForm = false;
            }

            if (emptyForm) {
                emptyGroups.push(i) ;
            }
            i++;
        }
        for (const removeGroup of emptyGroups.reverse()) {
            this.removeAvailabilityAdjustmentUnit(removeGroup);
        }
        if (this.aaFormArray.length === 0) {
            this.isEmptyCondition = true;
            this.addAvailabilityAdjustmentUnit();
        }
    }

    public disableAllField(checked) {
        const fieldsList = ['override', 'numbers', 'maxSeats', 'seats', 'numbersSign', 'seatsSign', 'increaseSeats'];
        if (checked) {
            for (const field of fieldsList) {
                this.aaFormArray.controls[0].get(field).reset();
                this.aaFormArray.controls[0].get(field).enable();
            }
        } else {
            for (const field of fieldsList) {
                this.aaFormArray.controls[0].get(field).reset();
                this.aaFormArray.controls[0].get(field).disable();
            }
        }
    }

    get aaFormArray(): FormArray {
        return this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
    }

    private setFormValuesFromData() {
        const availAdjustFormUnitArray = [];

        const availAdjustFormUnit = {} as AvailabilityAdjustmentFormGroup;
        if (this.availAdjustDataActionInput.changeAmount) {
            availAdjustFormUnit.seatsSign = this.availAdjustDataActionInput.changeAmount > 0 ? '+' : '-';
            availAdjustFormUnit.seats = Math.abs(this.availAdjustDataActionInput.changeAmount);
        }
        if (this.availAdjustDataActionInput.changePercent) {
            availAdjustFormUnit.numbersSign = this.availAdjustDataActionInput.changePercent > 0 ? '+' : '-';
            availAdjustFormUnit.numbers = Math.abs(this.availAdjustDataActionInput.changePercent);
        }
        availAdjustFormUnit.maxSeats = this.availAdjustDataActionInput.maximum;
        availAdjustFormUnit.minSeats = this.availAdjustDataActionInput.minimum;
        availAdjustFormUnit.increaseSeats = this.availAdjustDataActionInput.maximumIncrease;
        availAdjustFormUnit.availability = this.availAdjustDataActionInput.useAuAvailability ? true : false;
        availAdjustFormUnit.override = this.availAdjustDataActionInput.overrideSegmentLimit ? true : false;
        availAdjustFormUnitArray.push(availAdjustFormUnit);
        const availAdjustFormModel = {
            availabilityAdjustmentUnit: availAdjustFormUnitArray
        } as AvailabilityAdjustmentComponentForm;

        if (availAdjustFormModel) {
            this.setFormValues(availAdjustFormModel);
        }
        availAdjustFormUnit.availability ? this.disableAllField(!availAdjustFormUnit.availability) : null;
    }

    private setFormValues(availabilityAdjustmentFromModel: AvailabilityAdjustmentComponentForm) {
        const control = this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
        for (const availabilityAdjustmentUnit of availabilityAdjustmentFromModel.availabilityAdjustmentUnit) {
            control.push(this.crateAvailAdjFormGroup());
        }
        this.removeAvailabilityAdjustmentUnit(0);
        (this.availabilityAdjustmentForm as FormGroup).patchValue(availabilityAdjustmentFromModel, { onlySelf: true });
    }

    private crateAvailAdjFormGroup() {		// nest
        return this.fb.group({
            seatsSign: [{ value: '', disabled: false }],
            seats: [{ value: '', disabled: false }],
            numbersSign: [{ value: '', disabled: false }],
            numbers: [{ value: '', disabled: false }],
            maxSeats: [{ value: '', disabled: false }],
            increaseSeats: [{ value: '', disabled: false }],
            override: [{ value: false, disabled: false }],
            availability: [{ value: false, disabled: false }]
        });
    }

    private addAvailabilityAdjustmentUnit() {
        const control = this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
        control.push(this.crateAvailAdjFormGroup());
    }

    private removeAvailabilityAdjustmentUnit(i: number) {
        const control = this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
        control.removeAt(i);
    }

    get availabilityAdjustmentUnit(): FormArray {
        return this.availabilityAdjustmentForm.get('availabilityAdjustmentUnit') as FormArray;
    }

}
