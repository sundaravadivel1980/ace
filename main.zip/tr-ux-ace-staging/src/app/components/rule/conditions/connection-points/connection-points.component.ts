import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray, FormBuilder } from '@angular/forms';

import { ConnectionPointCondition, ConnectionCity, ConnectionCityAirport, TimeConnectionCity, Rule } from '@dxc/tr-ux-ace-services/dist/lib';

import { RuleDetailChildForm,
            ConnectionPointComponentForm,
            ConnectionPointFormGroup,
            ConnectionCityAndTimeFormModel,
            DropdownModel
        } from '../../../../models/rule-form.model';
import { CarrierConfig } from '../../../../models/carrier-config';
import { RuleValidationService } from '../../../../services/rule/rule-validation.service';
import { AppSingletonService } from '../../../../app-singleton.service';
import { RuleUtil } from '../../rule.util.ts';

@Component({
    selector: 'connection-points',
    templateUrl: 'connection-points.component.html',
    styleUrls: ['./connection-points.component.scss']
})

export class ConnectionPointsComponent implements RuleDetailChildForm, OnInit {
    @Input() public childInput: Rule;
    @Input() public timeUnitCount = 0;
    @Output() public timeUnitCountChange = new EventEmitter();

    public connectionPointsform: FormGroup;
    public connectionPointDataArray: ConnectionPointCondition[];

    public mainOperators: DropdownModel[];
    public radioOptions: any;
    public listOfAirport: DropdownModel[];
    public removeAddTimeUnit: boolean = true;

    private isEmptyCondition: boolean = false;
    private hasErrors: boolean = false;

    constructor(private fb: FormBuilder,
                private singletonService: AppSingletonService,
                private validationService: RuleValidationService) {
        this.mainOperators = singletonService.ruleJsonStore.ConnectionPoint.MainOperator;
        this.radioOptions = singletonService.ruleJsonStore.ConnectionPoint.RadioOptions;
    }

    public ngOnInit() {
        this.listOfAirport = CarrierConfig.getAiportsList(this.singletonService.airports) as DropdownModel[];
        this.connectionPointsform = this.fb.group({ connectionPointUnit: this.fb.array([this.createConnPointFormGroup()]) });
        this.setValues();
    }

    public setValues() {
        const rule = this.childInput;
        if (rule.action) {
            this.connectionPointDataArray = RuleUtil.getComponenetData(rule, 'connectionPointCondition');
        }

        if ( this.connectionPointDataArray && this.connectionPointDataArray.length > 0 ) {
            this.setFormValuesFromData();
        }
    }

    public getValues(): ConnectionPointCondition[] {

        this.validate();

        if (this.isEmptyCondition) {
            return null;
        }

        if (this.hasErrors) {
            return null;
        }

        const connectionPointConditionArray = [];
        for (const connectionPointFormUnit of this.connectionPointFormArray.value) {
            const connCityAndTimeArray = [];
            for (const connTimeFormUnit of connectionPointFormUnit.connectionTimeUnit) {
                const connTime =  {
                    maximumMinutes: connTimeFormUnit.maxTime,
                    minimumMinutes: connTimeFormUnit.minTime
                } as TimeConnectionCity;

                const connCity =  {} as ConnectionCityAirport;
                connCity.arrival = connTimeFormUnit.connectionpointCityFrom ? connTimeFormUnit.connectionpointCityFrom[0] : '';
                if (connTimeFormUnit.connectionpointCityTo) {
                    connCity.departure =  connTimeFormUnit.connectionpointCityTo[0];
                }

                connCityAndTimeArray.push({
                    airports: connCity,
                    time: connTime
                } as ConnectionCity);
            }
            connectionPointConditionArray.push({
                comparator: connectionPointFormUnit.connectionpointSelect,
                inSequence: connectionPointFormUnit.connectionpointRadio === 'Any' ? false : true,
                connectionCity : connCityAndTimeArray
            } as ConnectionPointCondition);
        }
        return connectionPointConditionArray;
    }

    public validate() {

        this.removeEmptyForms();

        const emptyConnFormUnits = [];
        this.hasErrors = false;

        if (!this.isEmptyCondition) {
            for (const connPointFormUnit of this.connectionPointFormArray.controls) {
                const connCityTimeFormArray = connPointFormUnit.get('connectionTimeUnit') as FormArray;
                for (const connCityTimeFormUnit of connCityTimeFormArray.controls) {
                    if (connCityTimeFormUnit.get('connectionpointCityFrom').value.length === 0) {
                        this.hasErrors = true;
                        this.validationService.addGlobalError('acegui.rules.messages.connection.point.connnection.city.required');
                    }
                }
            }
        }
    }

    public removeEmptyForms() {

        let i: number = 0;
        const emptyConnFormUnits = [];
        this.isEmptyCondition = false;

        for (const connPointFormUnit of this.connectionPointFormArray.controls) {

            const connCityTimeFormArray = connPointFormUnit.get('connectionTimeUnit') as FormArray;
            let j: number = 0;
            const emptyConnCityTimeFormUnits = [];
            for (const connCityTimeFormUnit of connCityTimeFormArray.controls) {
                let emptyConnCityForm = true;
                if (connCityTimeFormUnit.get('connectionpointCityFrom').value.length > 0
                || connCityTimeFormUnit.get('connectionpointCityTo').value.length > 0 ||
                    connCityTimeFormUnit.get('minTime').value || connCityTimeFormUnit.get('maxTime').value) {
                        emptyConnCityForm = false;
                }

                if (emptyConnCityForm) {
                    emptyConnCityTimeFormUnits.push(j);
                }
                j++;
            }
            let emptyForm = false;
            if (connCityTimeFormArray.controls.length === emptyConnCityTimeFormUnits.length) {
                emptyForm = true;
                emptyConnCityTimeFormUnits.splice(0, 1);
            }

            for (const emptyConnCityFormUnit of emptyConnCityTimeFormUnits.reverse()){
                this.removeConnectionTimeUnit(i, emptyConnCityFormUnit);
            }

            if (emptyForm) {
                emptyConnFormUnits.push(i);
            }

            i++;
        }
        if (this.connectionPointFormArray.length === emptyConnFormUnits.length) {
            this.isEmptyCondition = true;
            emptyConnFormUnits.splice(0, 1);
        }
        for (const emptyConnForm of emptyConnFormUnits.reverse()){
            this.removeConnectionPointUnit(emptyConnForm);
        }
    }

    get connectionPointFormArray(): FormArray {
        return this.connectionPointsform.get('connectionPointUnit') as FormArray;
    }

    public createConnPointFormGroup() {		// nest
        return this.fb.group({
            connectionpointSelect: 'EQ',
            connectionpointRadio: ['Any'],
            connectionTimeUnit: this.fb.array([this.createConnCityTimeFormGroup()])
        });
    }
    public addConnectionPointUnit() {
        this.connectionPointFormArray.push(this.createConnPointFormGroup());
    }

    public removeConnectionPointUnit(i: number) {
        this.connectionPointFormArray.removeAt(i);
    }

    public createConnCityTimeFormGroup() {
        return this.fb.group({
            connectionpointCityFrom: [[]],
            connectionpointCityTo: [[]],
            minOperator: ['GT'],
            minTime: [],
            maxOperator: ['LT'],
            maxTime: []
        });
    }

    public addConnectionTimeUnit(i: number) {
        const control = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
        control.push(this.createConnCityTimeFormGroup());
        this.timeUnitCount++;
        this.timeUnitCountChange.emit(this.timeUnitCount);
        if (this.connectionPointFormArray.value[i].connectionpointRadio === 'Any' && this.timeUnitCount >= 10) {
            this.removeAddTimeUnit = false;
        } else  if (this.connectionPointFormArray.value[i].connectionpointRadio === 'In Sequence' && this.timeUnitCount >= 4) {
            this.removeAddTimeUnit = false;
        }
    }

    public removeConnectionTimeUnit(i: number, j: number) {
        const control = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
        control.removeAt(j);
        this.removeAddTimeUnit = true;
    }

    public radioClick(i) {
        const radioVal = this.connectionPointFormArray.controls[i].get('connectionpointRadio').value;
        const length = this.connectionPointFormArray.controls[i].get('connectionTimeUnit')['controls'].length;
        if ( (radioVal === 'Any') && length === 1) {
           this.timeUnitCount = 1;
           this.addConnectionTimeUnit(i);
        } else if ( (radioVal === 'Insequence') && length === 2) {
           this.removeConnectionTimeUnit(i, 0);
        }
    }

    private setFormValuesFromData() {
        const connectionPointFormModel = new ConnectionPointComponentForm();

        const connPointFormArray = [];
        for (const connectionPointDataUnit of this.connectionPointDataArray) {
            const connPointFormUnit = new ConnectionPointFormGroup();
            connPointFormUnit.connectionpointSelect = connectionPointDataUnit.comparator;
            if (connectionPointDataUnit.inSequence) {
                connPointFormUnit.connectionpointRadio = 'In Sequence';
            } else {
                connPointFormUnit.connectionpointRadio = 'Any';
            }

            const connCityAndTimeFormArray = [];
            for (const connCityAndTimeDataUnit of connectionPointDataUnit.connectionCity) {
                const connCityAndTimeFormUnit = {
                    maxTime: connCityAndTimeDataUnit.time.maximumMinutes ? connCityAndTimeDataUnit.time.maximumMinutes : '',
                    minTime: connCityAndTimeDataUnit.time.minimumMinutes ? connCityAndTimeDataUnit.time.minimumMinutes : '',
                    connectionpointCityFrom: connCityAndTimeDataUnit.airports.arrival ? [connCityAndTimeDataUnit.airports.arrival] : [],
                    connectionpointCityTo: connCityAndTimeDataUnit.airports.departure ? [connCityAndTimeDataUnit.airports.departure] : []
                } as ConnectionCityAndTimeFormModel;

                connCityAndTimeFormArray.push(connCityAndTimeFormUnit);
            }
            connPointFormUnit.connectionTimeUnit = connCityAndTimeFormArray;
            connPointFormArray.push(connPointFormUnit);
        }
        connectionPointFormModel.connectionPointUnit = connPointFormArray;
        if (connectionPointFormModel) {
            this.setFormValues(connectionPointFormModel);
        }
    }

    private setFormValues(connectionPointFormModel: ConnectionPointComponentForm) {
        const connectionPointFormArrayLength = connectionPointFormModel.connectionPointUnit.length;
        const connPointFormArray = this.connectionPointsform.get('connectionPointUnit') as FormArray;

        let i: number;
        let j: number;

        for (i = 0; i < connectionPointFormArrayLength ; i++ ) {
            connPointFormArray.push(this.createConnPointFormGroup());
        }
        connPointFormArray.removeAt(i);

        // generate fields for orginDestination
        i = 0;
        for (const connPointFormUnit of connectionPointFormModel.connectionPointUnit) {
            j = 0;
            const connCityTimeFormArray = this.connectionPointFormArray.controls[i].get('connectionTimeUnit') as FormArray;
            for ( const orginDestination of connPointFormUnit.connectionTimeUnit) {
                connCityTimeFormArray.push(this.createConnCityTimeFormGroup());
                j++;
            }
            this.removeConnectionTimeUnit(i, j);
            i++;
        }
          // Push service response data into generated fields
        (this.connectionPointsform as FormGroup).patchValue(connectionPointFormModel, { onlySelf: true });
    }
}
