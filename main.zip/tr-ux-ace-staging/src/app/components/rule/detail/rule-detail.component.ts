import { Component, OnInit, OnDestroy, ViewChild, ViewContainerRef, AfterViewInit,
ComponentFactoryResolver, Renderer } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

import { OverlayOrigin } from '@angular/cdk/overlay';
import { TemplatePortalDirective } from '@angular/cdk/portal';
import { OverlayConfig } from '@angular/cdk/overlay';
import { Overlay } from '@angular/cdk/overlay';
import { MatDialog } from '@angular/material';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { TranslateService } from '@ngx-translate/core';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';

import {
  RuleRs,
  RuleRq,
  RqStandardPayload,
  Rule,
  Action,
  RuleService
} from '@dxc/tr-ux-ace-services/dist/lib';

import { AppSingletonService } from '../../../app-singleton.service';
import { DataShare } from '../../../services/rule/data-share';
import { RuleParamsService } from '../../../services/rule/rule-params.service';
import { environment } from '../../../../environments/environment';
import { AppConstants } from '../../../app.constants';
import { RuleDetailParentComponent } from './rule-detail-parent.component';
import { RuleSummaryComponent } from '../rule-summary/rule-summary.component';
import { RuleValidationService } from '../../../services/rule/rule-validation.service';
import { ClassesComponent } from '../conditions/classes/classes.component';

@Component({
  templateUrl: './rule-detail.component.html',
  styleUrls: ['./rule-detail.component.scss']
})

/*
  * Rule detail component. This use the Angular reactive form concept
  * This contains multiple child components.
  * See the rule-detail.component.html for the embedded child components/forms
  * this.ruleViewData is the input to the child form(s)
  *
  * RuleDetailParentComponent.setComponents is used to get the values from the
  * child forms and construct the rule PUT/POST request
 *
 */

export class RuleDetailComponent extends RuleDetailParentComponent implements OnInit, OnDestroy {
  public enableAdditionalCondition: boolean = false;
  // @ViewChild('classesContainer', {read: ViewContainerRef}) public classesContainer: ViewContainerRef;

  private URL: string = environment.apiUrl + AppConstants.ruleUrl;
  private overlayRef: any;

  @ViewChild('addConditionOrigin')
  private addConditionOrigin: OverlayOrigin;
  @ViewChild('addConditionTemplate')
  private addConditionTemplate: TemplatePortalDirective;

  constructor(public overlay: Overlay,
              protected ruleParamsService: RuleParamsService,
              protected router: Router,
              protected ruleService: RuleService,
              protected singletonService: AppSingletonService,
              protected messageService: MessageService,
              protected popup: MatDialog,
              protected resolver: ComponentFactoryResolver,
              private translateService: TranslateService,
              private spinnerService: Ng4LoadingSpinnerService,
              private factoryResolver: ComponentFactoryResolver,
              private ruleValidation: RuleValidationService) {
    super(ruleParamsService, router, ruleService, singletonService, messageService, resolver);
    // To reload the page after save/copy
    this.router.routeReuseStrategy.shouldReuseRoute = function(){
        return false;
    };
  }
  /*
   * Angular lifecycle method, used to get/populate the value for new/edit rule
  */
  public ngOnInit() {
    this.params = this.ruleParamsService.params;
    if ( this.params === undefined ) {
      this.router.navigate(['/rule']);   // If no value set, redirect to home (Try to access via url)
    } else {
       const additional = this.singletonService.configJsonStore[this.params.ruleAction]['additional'];
       this.splitList(additional);
    }
    let tmpRuleId: number;
    let tmpRuleVersion: number;

    const ruleList = this.singletonService.ruleJsonStore.RuleTypes;
    if (this.params && (this.params.ruleId > 0 || this.params.copyId > 0)) {
      if (this.params.copyId > 0) {
        tmpRuleId = this.params.copyId;
        tmpRuleVersion = this.params.copyRuleVersion;
      } else {
        tmpRuleId = this.params.ruleId;
        tmpRuleVersion = this.params.ruleVersion;
      }
      this.ruleService.getRule(this.URL + '/' + tmpRuleId + '/' + tmpRuleVersion).subscribe(
        (ruleResponse: RuleRs) => {
          this.params.ruleTime = ruleResponse.rule[0].time;
          this.isDataLoaded = true;
          this.ruleViewData = ruleResponse.rule[0];
          this.params.ruleTime = ruleResponse.rule[0].time;
          if (this.params.copyId > 0) {
            this.ruleViewData.status = '';
          }
          this.enableDisableAdditionalComponents();
          console.log(JSON.stringify(ruleResponse.rule[0]));
        },
        (error: HttpErrorResponse) => {
          console.log(error);
        }
      );
    } else if (this.params && this.params.ruleId === 0) {
      this.isDataLoaded = true;
      this.ruleViewData = new Rule();
      this.ruleViewData.type = this.params.ruleAction;
    }
  }

  /*
   * User action for save rule. This will construct the rule request and post to service
   *
  */
  public saveRule(status: string) {

    const action = {} as Action;

    this.setComponents(action);
    const headerValues = this.headerSectionComponent.getValues();
    action.transaction = headerValues.transaction;

    const rule = {
      id: this.params.ruleId,
      keyword: headerValues.keyword,
      name: headerValues.name,
      status: headerValues.status,
      time: this.params.ruleTime,
      version: this.params.ruleVersion,
      userId: null,
      type: this.params.ruleAction,
      quickRule: null,
      action: [action]
    } as Rule;

    this.ruleViewData = rule;

    if (!this.ruleValidation.hasValidationErrors()) {
      this.createOrUpdateRule();
    } else {

      this.ruleValidation.showErrors();
    }
  }

  /**
   * To show additional conditions list overlay
   */
  public showAddlCondtionsOverlay() {
    const strategy = this.overlay.position()
      .connectedTo(
      this.addConditionOrigin.elementRef,
      { originX: 'end', originY: 'bottom' },
      { overlayX: 'end', overlayY: 'top' });

    const config = new OverlayConfig({
      hasBackdrop: true,
      backdropClass: 'cdk-overlay-transparent-backdrop',
      positionStrategy: strategy
    });
    this.overlayRef = this.overlay.create(config);

    this.overlayRef.attach(this.addConditionTemplate);
    this.overlayRef.backdropClick().subscribe(() => this.overlayRef.detach());
  }

  /**
   * Will add additional components in the rule detail page
   */
  public addAdditionalComp(checked: boolean, id: string) {
    this.checkedComponents[id] = checked;
    this.enableAdditionalCondition = false;
    for (const key in this.checkedComponents) {
      if (this.checkedComponents[key] === true) {
        this.enableAdditionalCondition = true;
      }
    }
  }

  public closeAddCondition() {
    this.overlayRef.detach();
  }

  /**
   * Confirmation popup. Not yet fully implemented
   * @param rule
   */
  public ruleSummary(rule) {
    const popupRef = this.popup.open(RuleSummaryComponent,
      {
        data: rule,
        width: '750px'
      });
    popupRef.afterClosed().subscribe(result => {
       if (result === 'confirmed') {
        this.createOrUpdateRule();
       }
    });
  }

  public ngOnDestroy() {
    // this.ruleParamsService.params = undefined;
  }

  private createOrUpdateRule() {
    this.spinnerService.show();
    const requestPayload = { correlationId: '1', pointOfSale: null } as RqStandardPayload;
    const ruleData = { rqStandardPayload: requestPayload, rule: [this.ruleViewData] } as RuleRq;
    console.log(JSON.stringify(ruleData));
    if (this.ruleParamsService.params.ruleId > 0) {
      this.ruleService.updateRule(this.URL, ruleData).subscribe(
        (ruleResponse: RuleRs) => {
          this.spinnerService.hide();
          if (ruleResponse.rule && ruleResponse.rule.length > 0) {
            this.ruleViewData = ruleResponse.rule[0];
            this.ruleParamsService.params.ruleId = this.ruleViewData.id;
            this.ruleParamsService.params.ruleVersion = this.ruleViewData.version;
            this.ruleParamsService.params.ruleTime = this.ruleViewData.time;
            this.messageService.success('Rules saved successfully');
          } else {
            // TODO: Need to send the error list. The message service and component needs to be updated
            this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
          }
        },
        (error: HttpErrorResponse) => {
          this.spinnerService.hide();
          this.messageService.error(error.status + '---' + error.message);
        }
      );
    } else {
      this.ruleService.createRule(this.URL, ruleData).subscribe(
        (ruleResponse: RuleRs) => {
          this.spinnerService.hide();
          if (ruleResponse.rule && ruleResponse.rule.length > 0) {
            this.headerSectionComponent.enableIconLinks();
            this.ruleViewData = ruleResponse.rule[0];
            this.ruleParamsService.params.ruleId = this.ruleViewData.id;
            this.ruleParamsService.params.ruleVersion = this.ruleViewData.version;
            this.ruleParamsService.params.ruleTime = this.ruleViewData.time;
            this.messageService.success('Rules Saved Successfully', true);
            this.router.navigate(['/rule/detail', this.ruleViewData.id]);
          } else {
            // TODO: Need to send the error list. The message service and component needs to be updated
            this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
          }
        },
        (error: HttpErrorResponse) => {
          this.spinnerService.hide();
          this.messageService.error(error.status + '---' + error.message);
        }
      );
    }
  }

  private splitList(list: any) {
    const data = list.sort((a, b) => {
        const x = a['description'].toString().toLowerCase();
        const y = b['description'].toString().toLowerCase();
        return x < y ? -1 : y < x ? 1 : 0 ;
    });
    const divide: number = (data.length / 2) + 1;
    this.componentsList1 = data.slice(0, divide);
    this.componentsList2 = data.slice(divide);
 }
}
