import { ViewChild, ViewContainerRef, ViewChildren, QueryList, ComponentFactoryResolver } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { Rule, Action, RuleService, ClassClosureAction, ClassSuppressionAction,
    MarketFareAdjustmentAction, BidPriceAdjustmentAction, AvailabilityAdjustmentAction
} from '@dxc/tr-ux-ace-services/dist/lib';

import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { AppSingletonService } from '../../../app-singleton.service';
import { AppConstants } from '../../../app.constants';

import { RuleParams } from '../../../services/rule/rule-params.model';
import { RuleParamsService } from '../../../services/rule/rule-params.service';

import { MarketComponent } from '../conditions/market/market.component';
import { ClassesComponent } from '../conditions/classes/classes.component';
import { FlightsComponent } from '../conditions/flights/flights.component';
import { CarriersComponent } from '../conditions/carriers/carriers.component';
import { LoadFactorComponent } from '../conditions/load-factor/load-factor.component';
import { RoutingComponent } from '../conditions/routing/routing.component';
import { ClassAvailabilityComponent } from '../conditions/class-availability/class-availability.component';
import { ConnectionPointsComponent } from '../conditions/connection-points/connection-points.component';
import { AvailabilityAdjustmentComponent } from '../conditions/availability-adjustment/availability-adjustment.component';
import { BaseFareAdjustmentComponent } from '../conditions/base-fare-adjustment/base-fare-adjustment.component';
import { DepartureDatesComponent } from '../conditions/departure-dates/departure-dates.component';
import { SellingDatesComponent } from '../conditions/selling-dates/selling-dates.component';
import { PointOfSaleComponent } from '../conditions/point-of-sale/point-of-sale.component';
import { BidPriceAdjustmentComponent } from '../conditions/bid-price-adjustment/bid-price-adjustment.component';
import { PointOfCommencementComponent } from '../conditions/point-of-commencement/point-of-commencement.component';
import { ClassBookingComponent } from '../conditions/class-booking/class-booking.component';
import { ArrivalTimeGroupComponent } from '../conditions/arrival-time/arrival-time.component';
import { DepartureTimeGroupComponent } from '../conditions/departure-time/departure-time.component';
import { TimeOutsideDepartureComponent } from '../conditions/time-outside-departure/time-outside-departure.component';
import { TimeToDepartureComponent } from '../conditions/time-to-departure/time-to-departure.component';
import { EquipmentComponent } from '../conditions/equipment/equipment.component';
import { HashDirective } from '../../../directives/hash-directive'; // For dynamic component createtion, finding ng-container
import { HeaderSectionComponent } from '../conditions/header-section/header-section.component';

export class RuleDetailParentComponent {

    public ruleViewData: Rule;

    public params: RuleParams;

    public enableAdditionalCondition: boolean = false;

    public toggleShaddow: boolean = false;
    /** Additioncal components list to be shown in the expansion panel */
    public componentsList1: string[] = [];
    public componentsList2: string[] = [];
    public ruleLists: any;
    public checkedComponents: any = [];
    public isDataLoaded: boolean;

/**
 * @ViewChild() provides the instance of another component or directive
 * in a parent component and then parent component can access the methods and properties of that component or directive.
 */
    @ViewChild(HeaderSectionComponent)
    protected headerSectionComponent: HeaderSectionComponent;
    @ViewChild(MarketComponent)
    private marketComponent: MarketComponent;
    @ViewChild(ClassesComponent)
    private classesComponent: ClassesComponent;
    @ViewChild(FlightsComponent)
    private flightsComponent: FlightsComponent;
    @ViewChild(CarriersComponent)
    private carriersComponent: CarriersComponent;
    @ViewChild(LoadFactorComponent)
    private loadFactorComponent: LoadFactorComponent;
    @ViewChild(ClassAvailabilityComponent)
    private classAvailabilityComponent: ClassAvailabilityComponent;
    @ViewChild(ConnectionPointsComponent)
    private connectionPointsComponent: ConnectionPointsComponent;
    @ViewChild(RoutingComponent)
    private routingComponent: RoutingComponent;
    @ViewChild(AvailabilityAdjustmentComponent)
    private availabilityAdjustmentComponent: AvailabilityAdjustmentComponent;
    @ViewChild(BaseFareAdjustmentComponent)
    private baseFareAdjustmentComponent: BaseFareAdjustmentComponent;
    @ViewChild(DepartureDatesComponent)
    private departureDatesComponent: DepartureDatesComponent;
    @ViewChild(PointOfSaleComponent)
    private pointOfSaleComponent: PointOfSaleComponent;
    @ViewChild(BidPriceAdjustmentComponent)
    private bidPriceAdjustmentComponent: BidPriceAdjustmentComponent;
    @ViewChild(PointOfCommencementComponent)
    private pointOfCommencementComponent: PointOfCommencementComponent;
    @ViewChild(ClassBookingComponent)
    private classBookingComponent: ClassBookingComponent;
    @ViewChild(SellingDatesComponent)
    private sellingDatesComponent: SellingDatesComponent;
    @ViewChild(ArrivalTimeGroupComponent)
    private arrivalTimeGroupComponent: ArrivalTimeGroupComponent;
    @ViewChild(DepartureTimeGroupComponent)
    private departureTimeGroupComponent: DepartureTimeGroupComponent;
    @ViewChild(TimeOutsideDepartureComponent)
    private timeOutsideDepartureComponent: TimeOutsideDepartureComponent;
    @ViewChild(TimeToDepartureComponent)
    private timeToDepartureComponent: TimeToDepartureComponent;
    @ViewChild(EquipmentComponent)
    private equipmentComponent: EquipmentComponent;
    @ViewChildren(HashDirective) private hashes: QueryList<HashDirective>; // Directive to get dynamic Compoenents

    constructor(
        protected ruleParamsService: RuleParamsService,
        protected router: Router,
        protected ruleService: RuleService,
        protected singletonService: AppSingletonService,
        protected messageService: MessageService,
        protected resolver: ComponentFactoryResolver) {

        const data = singletonService.ruleJsonStore;
        // this.ruleLists is actually the rule typeslist. Needs to be removed
        // if user is not allowed to change the rule type from the create rule page
        this.ruleLists = data.RuleLists;
    }

    protected enableDisableAdditionalComponents() {
        const actions = this.getActionInstance(this.ruleViewData.type, this.ruleViewData.action[0]);
        const keys = Object.keys(actions);
        for (const key of keys) {
            if (actions[key] && actions[key].length > 0
                && key !== 'actionInput' && key !== 'marketCondition' && key !== 'classCondition') {
                this.checkedComponents[key] = true;
            }
        }
        for (const key in this.checkedComponents) {
            if (this.checkedComponents[key] === true && key !== 'actionInput') {
                this.enableAdditionalCondition = true;
            }
        }
    }

    protected setComponents(action: Action): void {
        let ruleSpecificAction: any;
        ruleSpecificAction = this.getActionNewInstance(action);
        this.headerSectionComponent.validate();
        ruleSpecificAction.marketCondition = this.marketComponent.getValues();
        if (this.params.ruleAction !== AppConstants.ACTION_BID_PRICE_ADJ) {
            ruleSpecificAction.classCondition = this.classesComponent.getValues();
        }
        if (this.checkedComponents.flightCondition) {
            ruleSpecificAction.flightCondition = this.flightsComponent.getValues();
        }
        if (this.checkedComponents.carrierCondition) {
            ruleSpecificAction.carrierCondition = this.carriersComponent.getValues();
        }
        if (this.params.ruleAction !== AppConstants.ACTION_CLASS_SUPPRESSION) {
            ruleSpecificAction.actionInput = this.getActionInput();
        }
        if (this.checkedComponents.loadFactorCondition) {
            ruleSpecificAction.loadFactorCondition = this.loadFactorComponent.getValues();
        }
        if (this.checkedComponents.classAvailabilityCondition) {
            ruleSpecificAction.classAvailabilityCondition = this.classAvailabilityComponent.getValues();
        }
        if (this.checkedComponents.connectionPointCondition) {
            ruleSpecificAction.connectionPointCondition = this.connectionPointsComponent.getValues();
        }
        if (this.checkedComponents.routingCondition) {
            ruleSpecificAction.routingCondition = this.routingComponent.getValues();
        }
        if (this.checkedComponents.departureDateCondition) {
            ruleSpecificAction.departureDateCondition = this.departureDatesComponent.getValues();
        }
        if (this.checkedComponents.pointOfSaleCondition) {
            ruleSpecificAction.pointOfSaleCondition = this.pointOfSaleComponent.getValues();
        }
        if (this.checkedComponents.pointOfCommencementCondition) {
            ruleSpecificAction.pointOfCommencementCondition = this.pointOfCommencementComponent.getValues();
        }
        if (this.checkedComponents.classBookingCondition) {
            ruleSpecificAction.classBookingCondition = this.classBookingComponent.getValues();
        }
        if (this.checkedComponents.sellingDateTimeCondition) {
            ruleSpecificAction.sellingDateTimeCondition = this.sellingDatesComponent.getValues();
        }
        if (this.checkedComponents.arrivalTimeCondition) {
            ruleSpecificAction.arrivalTimeCondition = this.arrivalTimeGroupComponent.getValues();
        }
        if (this.checkedComponents.departureTimeCondition) {
            ruleSpecificAction.departureTimeCondition = this.departureTimeGroupComponent.getValues();
        }
        if (this.checkedComponents.timeOutsideDepartureCondition) {
            ruleSpecificAction.timeOutsideDepartureCondition = this.timeOutsideDepartureComponent.getValues();
        }
        if (this.checkedComponents.timeToDepartureCondition) {
            ruleSpecificAction.timeToDepartureCondition = this.timeToDepartureComponent.getValues();
        }
        if (this.checkedComponents.equipmentCondition) {
            ruleSpecificAction.equipmentCondition = this.equipmentComponent.getValues();
        }
    }

    private getActionInput() {
        switch (this.params.ruleAction) {
            case AppConstants.ACTION_CLASS_CLOSSURE:
                return this.classesComponent.getActionInput();
            case AppConstants.ACTION_BASE_FARE_ADJ:
                return this.baseFareAdjustmentComponent.getValues();
            case AppConstants.ACTION_BID_PRICE_ADJ:
                return this.bidPriceAdjustmentComponent.getValues();
            case AppConstants.ACTION_CLASS_SUPPRESSION:
                 return this.classesComponent.getActionInput();
            case AppConstants.ACTION_AVAIL_ADJ:
                return this.availabilityAdjustmentComponent.getValues();
            default:
            // Nothing to do here
        }
    }

    private getActionNewInstance(action: Action) {
        switch (this.params.ruleAction) {
          case AppConstants.ACTION_CLASS_CLOSSURE:
            action.classClosureAction = new ClassClosureAction();
            return action.classClosureAction;
          case AppConstants.ACTION_BASE_FARE_ADJ:
             action.marketFareAdjustmentAction = new MarketFareAdjustmentAction();
             action.marketFareAdjustmentAction.adjustLeg = this.marketComponent.getLegOrOAndDFlag();
             return action.marketFareAdjustmentAction;
          case AppConstants.ACTION_BID_PRICE_ADJ:
             action.bidPriceAdjustmentAction = new BidPriceAdjustmentAction();
             action.bidPriceAdjustmentAction.adjustLeg = this.marketComponent.getLegOrOAndDFlag();
             return action.bidPriceAdjustmentAction;
          case AppConstants.ACTION_CLASS_SUPPRESSION:
             action.classSuppressionAction = new ClassSuppressionAction();
             return action.classSuppressionAction;
          case AppConstants.ACTION_AVAIL_ADJ:
             action.availabilityAdjustmentAction = new AvailabilityAdjustmentAction();
             return action.availabilityAdjustmentAction;
          default:
          // Nothing to do here
        }
    }

    private getActionInstance(type: string, action: Action) {
        switch (type) {
          case AppConstants.ACTION_CLASS_CLOSSURE:
            return action.classClosureAction;
          case AppConstants.ACTION_BASE_FARE_ADJ:
             return action.marketFareAdjustmentAction;
          case AppConstants.ACTION_BID_PRICE_ADJ:
             return action.bidPriceAdjustmentAction;
          case AppConstants.ACTION_CLASS_SUPPRESSION:
             return action.classSuppressionAction;
          case AppConstants.ACTION_AVAIL_ADJ:
             return action.availabilityAdjustmentAction;
          default:
          // Nothing to do here
        }
    }

}
