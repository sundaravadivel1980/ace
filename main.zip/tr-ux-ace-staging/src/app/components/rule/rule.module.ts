/*
 * Rule Module
 */

import { NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DxcCoreModule } from '@dxc/tr-ux-ace-core/dist/lib';
import { TranslateModule } from '@ngx-translate/core';

import { RuleComponent } from './rule.component';
import { RuleDetailComponent } from './detail/rule-detail.component';
import { RuleDirectoryComponent } from './directory/rule-directory.component';
import { RuleRoutingModule } from './rule-routing.module';

import { MarketComponent } from './conditions/market/market.component';
import { ConnectionPointsComponent } from './conditions/connection-points/connection-points.component';
import { HeaderSectionComponent } from './conditions/header-section/header-section.component';
import { AvailabilityAdjustmentComponent } from './conditions/availability-adjustment/availability-adjustment.component';
import { RoutingComponent } from './conditions/routing/routing.component';
import { BaseFareAdjustmentComponent } from './conditions/base-fare-adjustment/base-fare-adjustment.component';
import { LoadFactorComponent } from './conditions/load-factor/load-factor.component';
import { ClassAvailabilityComponent } from './conditions/class-availability/class-availability.component';
import { ClassesComponent } from './conditions/classes/classes.component';
import { FlightsComponent } from './conditions/flights/flights.component';
import { CarriersComponent } from './conditions/carriers/carriers.component';
import { DepartureDatesComponent } from './conditions/departure-dates/departure-dates.component';
import { RuleEffectiveDatesComponent } from './conditions/rule-effective-dates/rule-effective-dates.component';
import { SellingDatesComponent } from './conditions/selling-dates/selling-dates.component';
import { FrequentFlyerComponent } from './conditions/frequent-flyer/frequent-flyer.component';
import { BookingClassesComponent } from './conditions/booking-classes/booking-classes.component';
import { TimeToDepartureComponent } from './conditions/time-to-departure/time-to-departure.component';
import { TimeOutsideDepartureComponent } from './conditions/time-outside-departure/time-outside-departure.component';
import { DepartureTimeGroupComponent } from './conditions/departure-time/departure-time.component';
import { ArrivalTimeGroupComponent } from './conditions/arrival-time/arrival-time.component';
import { PointOfSaleComponent } from './conditions/point-of-sale/point-of-sale.component';
import { PointOfCommencementComponent } from './conditions/point-of-commencement/point-of-commencement.component';
import { BidPriceAdjustmentComponent } from './conditions/bid-price-adjustment/bid-price-adjustment.component';
import { CabinClassesComponent } from './conditions/cabin-classes/cabin-classes.component';
import { ClassBookingComponent } from './conditions/class-booking/class-booking.component';
import { RuleSummaryComponent } from './rule-summary/rule-summary.component';
import { ExpandTableRowDirective } from '../../directives/expand-table-row.directive';
import { EquipmentComponent } from './conditions/equipment/equipment.component';
import { DirectoryComponent } from './reference-tables/directory/directory.component';
import { DetailsComponent } from './reference-tables/details/details.component';
import { DynamicFormComponent } from './reference-tables/dynamic-form/dynamic-form.component';
import { DynamicTableComponent } from './reference-tables/dynamic-table/dynamic-table.component';
// Pipes
import { MyPipe } from '../../pipes/rule/my-pipe';

// Services
import { RuleParamsService } from '../../services/rule/rule-params.service';
import { DxcDisableService } from '../../services/rule/dxc-disabe.service';
import { RuleValidationService } from '../../services/rule/rule-validation.service';
// import { RuleMessageService } from '../../services/rule/rule-message.service';
import { DialogsService } from '@dxc/tr-ux-ace-core/dist/lib';

// Directives
import { ShowIfConfiguredDirective } from '../../directives/show-if-configured.directive';
import { ShowIfAdditionalDirective } from '../../directives/show-if-additional.directive';
// import { FormatterDirective } from '../../directives/formatter.directive';
import { HashDirective } from '../../directives/hash-directive';

@NgModule({
  imports: [TranslateModule, DxcCoreModule, RuleRoutingModule],
  declarations: [
    RuleComponent, RuleDetailComponent, RuleDirectoryComponent,
    AvailabilityAdjustmentComponent, RoutingComponent, BaseFareAdjustmentComponent,
    ConnectionPointsComponent, HeaderSectionComponent, MarketComponent, LoadFactorComponent,
    ClassAvailabilityComponent, FlightsComponent, CarriersComponent, DepartureDatesComponent, RuleEffectiveDatesComponent,
    SellingDatesComponent, ClassesComponent, BookingClassesComponent, FrequentFlyerComponent, TimeToDepartureComponent,
    TimeOutsideDepartureComponent, DepartureTimeGroupComponent, ArrivalTimeGroupComponent, PointOfSaleComponent,
    BidPriceAdjustmentComponent, RuleSummaryComponent, MyPipe, CabinClassesComponent, ShowIfConfiguredDirective, PointOfCommencementComponent,
    ExpandTableRowDirective, ClassBookingComponent, EquipmentComponent, ShowIfAdditionalDirective,
    DirectoryComponent, DetailsComponent, DynamicFormComponent, DynamicTableComponent, HashDirective

  ],
  exports: [
    TranslateModule
  ],
  providers: [ RuleParamsService, DxcDisableService, DialogsService, DatePipe,
               RuleValidationService ],
  entryComponents: [ RuleSummaryComponent,
    ClassesComponent,
    FlightsComponent,
    CarriersComponent,
    LoadFactorComponent,
    RoutingComponent,
    ClassAvailabilityComponent,
    ConnectionPointsComponent,
    DepartureDatesComponent,
    SellingDatesComponent,
    PointOfSaleComponent,
    PointOfCommencementComponent,
    ClassBookingComponent,
    ArrivalTimeGroupComponent,
    DepartureTimeGroupComponent,
    TimeOutsideDepartureComponent,
    TimeToDepartureComponent,
    EquipmentComponent ]
})
export class RuleModule { }
