/*
 * Rule Engine Component which will route to rule list, detail, edit, create, delete
 */
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: 'rule.component.html',
  styleUrls: ['./rule.component.scss'],
  providers: []
})
export class RuleComponent {
  public  navItems  =  [{
    Name:  'Home',
    Link: '.'
  },
  {
    Name:  'Directory',
    Link: ''
  },
  {
    Name:  'Table',
    Link: 'tables'
  },
  {
    Name:  'Groups',
    Link: '.'
  }
  ];

  public selectedNavItem: number = 1;

  constructor(private router: Router) {

  }

  public navigateToPage($event) {
    console.log($event);
    // this.selectedNavItem = $event.value;
    // this.router.navigate([this.navItems[$event.value].Link]);
  }
}
