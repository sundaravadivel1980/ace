import { RuleSummary } from '@dxc/tr-ux-ace-services/dist/lib';
import { DataSource } from '@angular/cdk/collections';

import { MatPaginator, MatSort } from '@angular/material';

import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { RuleDirectoryTableData } from './rule-directory-table-data';

export class RuleDirectoryDataSource extends DataSource<RuleSummary> {
    public filterChange = new BehaviorSubject('');
    get filter(): string { return this.filterChange.value; }
    set filter(filter: string) { this.filterChange.next(filter); }

    public filteredData: RuleSummary[] = [];
    public renderedData: RuleSummary[] = [];

    constructor(private ruleDirectoryTableData: RuleDirectoryTableData, private paginator: MatPaginator, private sort: MatSort) {
      super();
      this.filterChange.subscribe(() => this.paginator.pageIndex = 0);
    }

    public connect(): Observable<RuleSummary[]> {
      const displayDataChanges = [
       this.ruleDirectoryTableData.dataChange,
       this.filterChange,
       this.sort.sortChange,
       this.paginator.page
      ];

      return Observable.merge(...displayDataChanges).map(() => {

        this.filteredData = this.ruleDirectoryTableData.data.slice().filter(
          (item: RuleSummary) => {
                  const searchStr = (item.name + item.userId + item.type).toLowerCase();
                  return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        });

        const sortedData = this.sortData(this.filteredData.slice());

        const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
        this.renderedData = sortedData.splice(startIndex, this.paginator.pageSize);
        return this.renderedData;
    });
  }

    public disconnect() {
        // diconnect()
    }

    public sortData(data: RuleSummary[]): RuleSummary[] {
      if (!this.sort.active || this.sort.direction === '') { return data; }
      return data.sort((a, b) => {
        let propertyA: number|string = '';
        let propertyB: number|string = '';
        switch (this.sort.active) {
          case 'ruleName': [propertyA, propertyB] = [a.name, b.name]; break;
          case 'ruleVersion': [propertyA, propertyB] = [a.version, b.version]; break;
          case 'userName': [propertyA, propertyB] = [a.userId, b.userId]; break;
          case 'lastModified': [propertyA, propertyB] = [a.time, b.time]; break;
          case 'ruletype': [propertyA, propertyB] = [a.type, b.type]; break;
          case 'status': [propertyA, propertyB] = [a.status, b.status]; break;
          default: break;
        }
        const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
        const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
        return (valueA < valueB ? -1 : 1) * (this.sort.direction === 'asc' ? 1 : -1);
      });
    }
  }
