import { HttpErrorResponse } from '@angular/common/http';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { RuleService, RuleRs, RuleSummary, Rule, RuleRq } from '@dxc/tr-ux-ace-services/dist/lib';

import { environment } from '../../../../environments/environment';
import { AppConstants } from '../../../app.constants';

export class RuleDirectoryTableData {
    public dataChange: BehaviorSubject<RuleSummary[]> = new BehaviorSubject<RuleSummary[]>([]);
    public ruleData = new Subject <Rule[]> ();
    private URL = environment.apiUrl + AppConstants.ruleUrl;

    constructor(private ruleService: RuleService,
                private messageService: MessageService,
                private spinnerService: Ng4LoadingSpinnerService) {
    }

    get data(): RuleSummary[] {
        return this.dataChange.value;
    }

    public getRuleDatas(): Observable <Rule[]> {
        return this.ruleData.asObservable();
    }

    public loadAllRules() {
        this.spinnerService.show();
        const url = environment.apiUrl + AppConstants.ruleUrl + '/directory';
        this.ruleService.getAllRules(url).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                     console.log(ruleResponse.rule);
                     const rows = ruleResponse.rule ? ruleResponse.rule : [];
                     this.dataChange.next(rows);
                } else {
                    this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                }
            },
            (error: HttpErrorResponse ) => {
                this.spinnerService.hide();
                console.log(error);
            }
        );
    }

    public loadRules(status: string, ruleType: string) {
        this.spinnerService.show();
        const url = environment.apiUrl + AppConstants.ruleUrl + '/directory';
        this.ruleService.getRules(url, status, ruleType).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    console.log(ruleResponse.rule);
                    const rows = ruleResponse.rule ? ruleResponse.rule : [];
                    this.dataChange.next(rows);
                } else {
                    this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                }
            },
            (error: HttpErrorResponse ) => {
                this.spinnerService.hide();
                console.log(error);
            }
        );
    }

    public deleteRule(ruleId) {
        this.spinnerService.show();
        const url = environment.apiUrl + AppConstants.ruleUrl;
        this.ruleService.deleteRule(url + '/' + ruleId).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    this.messageService.success('Rule Deleted Successfully.');
                } else {
                    this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                }
            },
            (error: HttpErrorResponse ) => {
                this.spinnerService.hide();
                this.messageService.error(error.status + '---' + error.message);
            },
            () => {
                this.loadAllRules();
            }
        );
    }

    public getRule(id: number, version: number) {
        this.spinnerService.show();
        this.messageService.clear();
        // let ruleDeactivateData: any;
        this.ruleService.getRule(this.URL + '/' + id + '/' + version).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    const rows = ruleResponse.rule ? ruleResponse.rule : [];
                    this.ruleData.next(rows);
               } else {
                   this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
               }
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                this.messageService.error(error.status + '---' + error.message);
            }
        );
    }

    public updateStatus(ruleDataReq: RuleRq) {
        this.spinnerService.show();
        this.messageService.clear();
        this.ruleService.updateRule(this.URL, ruleDataReq).subscribe(
            (ruleResponse: RuleRs) => {
                this.spinnerService.hide();
                if (ruleResponse.rsStandardPayload.success) {
                    this.messageService.success('Rule Deactivated Successfully', true);
                } else {
                    this.messageService.error(ruleResponse.rsStandardPayload.errors.error[0].message);
                }
            },
            (error: HttpErrorResponse) => {
                this.spinnerService.hide();
                this.messageService.error(error.status + '---' + error.message);
            },
            () => {
                this.loadAllRules();
            }
        );
    }
}
