import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { DataSource } from '@angular/cdk/table';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort } from '@angular/material';
import { Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';

import { animate, state, style, transition, trigger } from '@angular/animations';

/** RXJS used in the table */
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/observable/merge';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { RuleService, RuleSummary, RqStandardPayload, RuleExportRq, RuleRs, Rule, RuleRq } from '@dxc/tr-ux-ace-services/dist/lib';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';
import { DialogsService } from '@dxc/tr-ux-ace-core/dist/lib';

import { AppSingletonService } from '../../../app-singleton.service';
import { RuleDirectoryTableData } from './rule-directory-table-data';
import { RuleDirectoryDataSource } from './rule-directory-data-source';
import { RuleParamsService } from '../../../services/rule/rule-params.service';
import { AppJsonDataService } from '../../../app-json-data.service';
import { DropdownModel } from '../../../models/rule-form.model';
import { RuleUtil } from '../rule.util';

@Component({
  templateUrl: './rule-directory.component.html',
  styleUrls: ['./rule-directory.component.scss'],
  animations: [
    trigger('dxcAnimations', [
      state('void', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('*', style({ height: '*', visibility: 'visible' })),
      transition('void <=> *', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ])]
})

/**
 * Component for rules directory page. mat-table is used for table. Go through the below link to understand more on
 * DataSource and SelectionModel
 *
 * https://material.angular.io/components/table/overview
 *
 */
export class RuleDirectoryComponent implements OnInit {

  /** The Data source for the table */
  public dataSource: RuleDirectoryDataSource | null;
  /** The service used to populate the data source for the table. The data will come from database through REST service */
  public ruleDirectoryTableData = new RuleDirectoryTableData(this.ruleService, this.messageService, this.spinnerService);
  /** Helps to maintain the row selected state */
  public rowSelectionModel = new SelectionModel<RuleSummary>(true, []);
  /** The table headers */
  public tableColumns = ['select', 'ruleName', 'ruleVersion', 'ruletype', 'status', 'userName', 'lastModified', 'action'];

  /** Filter dropdowns */
  public ruleTypesList: DropdownModel[];
  public ruleStatus: DropdownModel[];
  public selectedRuleType: DropdownModel;
  public ruleTypeId: string = '';
  public ruleStatusId: string = '';

  public quickRuleEnable: boolean;

  @ViewChild(MatPaginator) private paginator: MatPaginator;
  @ViewChild(MatSort) private sort: MatSort;
  /** Input box for filter search in the table. This filter will just search in the table and will not go to DB */
  @ViewChild('filter') private filter: ElementRef;

  constructor(private ruleService: RuleService,
              private router: Router,
              private cdRef: ChangeDetectorRef,
              private singletonService: AppSingletonService,
              private paramsService: RuleParamsService,
              private messageService: MessageService,
              private spinnerService: Ng4LoadingSpinnerService,
              private dialogsService: DialogsService) {

    const data = singletonService.ruleJsonStore;
    this.ruleTypesList = data.RuleTypes;
    this.ruleStatus = data.RuleStatus;
    this.quickRuleEnable = singletonService.configJsonStore.RuleDirectory.QuickRuleEnable;
  }

  public ngOnInit() {
    console.log(this.paramsService);
    this.ruleDirectoryTableData.loadAllRules();
    this.dataSource = new RuleDirectoryDataSource(this.ruleDirectoryTableData, this.paginator, this.sort);

    // Do the table filter when user type something in the filter search field
    Observable.fromEvent(this.filter.nativeElement, 'keyup').debounceTime(150).distinctUntilChanged().subscribe(() => {
      if (!this.dataSource) {
        return;
      }
      this.dataSource.filter = this.filter.nativeElement.value;
    });
  }

  /** Whether the number of selected elements matches the total number of rows. */
  public isAllSelected(): boolean {
    if (!this.dataSource) { return false; }
    if (this.rowSelectionModel.isEmpty()) { return false; }

    // If the rows displayed in the table is filtered rows, then row selection count should be based on the filtered rows
    if (this.filter.nativeElement.value) {
      const rows = this.dataSource.renderedData;
      let childRows: number = 0;
      for (const row of rows) {
        childRows = row['rule'] ? childRows + row['rule'].length : childRows + 0;
      }
      // Returns true if the selected rows match the total number of rows including the child rows (all versions)
      return this.rowSelectionModel.selected.length === rows.length + childRows;
    } else {
      const rows = this.ruleDirectoryTableData.data;
      let childRows: number = 0;
      for (const row of rows) {
        childRows = row['rule'] ? childRows + row['rule'].length : childRows + 0;
      }
      return this.rowSelectionModel.selected.length === rows.length + childRows;
    }
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  public masterToggle() {
    if (!this.dataSource) { return; }
    if (this.isAllSelected()) {
      this.rowSelectionModel.clear();
    } else if (this.filter.nativeElement.value) {
    // If the rows displayed in the table is filtered rows, then select only those rows
      this.dataSource.renderedData.forEach((row) => {
        this.rowSelectionModel.select(row);
        if (row['rule']) {
          for (const child of row['rule']) {
            this.rowSelectionModel.select(child);
          }
        }
      });
    } else {
      this.ruleDirectoryTableData.data.forEach((row) => {
        this.rowSelectionModel.select(row);
        if (row['rule']) {
          for (const child of row['rule']) {
            this.rowSelectionModel.select(child);
          }
        }
      });
    }
  }

  /** Refresh the table based on the selected filter. This action will fetch the data from the database based on the selected filter */
  public filterDirectory(type: string, status: string) {
    // When the filter button is clicked, then clear the filter text box. Do the fresh search from the database.
    this.filter.nativeElement.value = '';
    // Clear all the existing row selection
    this.rowSelectionModel.clear();

    if (type === '' && status === '') {
      // When the filter is selected as 'All', load all the fules
      this.ruleDirectoryTableData.loadAllRules();
    } else if (type || status) {
      // When filter is for specific action or status
      this.ruleDirectoryTableData.loadRules(status, type);
      this.dataSource = new RuleDirectoryDataSource(this.ruleDirectoryTableData, this.paginator, this.sort);
      Observable.fromEvent(this.filter.nativeElement, 'keyup').debounceTime(150).distinctUntilChanged().subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
      this.cdRef.detectChanges();
    } else {
      console.log('select anyone, either type or status');
    }
  }

  public editRule(id: number, version: string, type: string) {
    this.paramsService.params = { ruleId: id, ruleVersion: version, ruleAction: type, ruleNew: false };
    this.router.navigate(['/rule/detail', id]);
    console.log(this.paramsService.params);
  }

  public newRule(type: string) {
    this.paramsService.params = { ruleId: 0, ruleVersion: 0, ruleAction: type, ruleNew: true };
    this.router.navigate(['/rule/detail', 0]);
    console.log(this.paramsService.params);
  }

  /**
   * Multiple rows export
   */
  public exportSelected() {
    const ruleArray = [];
    if (this.rowSelectionModel.selected.length > 0) {
      console.log('Export this Rows :' + this.rowSelectionModel.selected);
      this.rowSelectionModel.selected.forEach(row => {
        const rule = new Rule();
        rule.id = row.id;
        rule.version = row.version;
        ruleArray.push(rule);
      });
      RuleUtil.downloadExportData(ruleArray, this.ruleService, this.messageService);
    } else {
      console.log('Please select the rules to export');
    }
  }

  /**
   * Single rule export
   */
  public exportRule(row: RuleSummary) {
    const ruleArray = [];
    const exportRuleObj = new Rule();
    exportRuleObj.id = row.id;
    exportRuleObj.version = row.version;
    ruleArray.push(exportRuleObj);
    RuleUtil.downloadExportData(ruleArray, this.ruleService, this.messageService);
  }

  public deleteRule(id: number, version: number, status: string) {
    let confirmMsg: string;
    this.messageService.clear();
    if (status === 'INACT' || status === 'SIMUL') {
      confirmMsg = 'This action will permanently delete this rule and will not be avaliable in the future to either copy or edit';
    } else {
      confirmMsg = 'Are you sure you want to do this?';
    }
    this.dialogsService
      .confirm('Confirm Dialog', confirmMsg)
      .subscribe(res => {
        if (res) {
          this.ruleDirectoryTableData.deleteRule(id);
        } else {
          this.messageService.warn('Delete action cancelled');
        }
      });
  }

  public clearFilter() {
    this.ruleDirectoryTableData.loadAllRules();
    this.rowSelectionModel.clear();
  }

  public deactivateRule(id: number, version: number) {
    this.dialogsService
      .confirm('Confirm Dialog', 'Are you sure you want to do this?')
      .subscribe(res => {
        if (res) {
          this.ruleDirectoryTableData.getRule(id, version);
          this.ruleDirectoryTableData.getRuleDatas().subscribe(
            data => {
              const ruleRequest = data[0];
              ruleRequest.status = 'INACT';
              const requestPayload = {
                correlationId: '1', pointOfSale: null
              } as RqStandardPayload;

              const ruleData = {
                rqStandardPayload: requestPayload,
                rule: [ruleRequest]
              } as RuleRq;
              this.ruleDirectoryTableData.updateStatus(ruleData);
            },
            error => {
              console.log(error);
            });
        }
      });
  }

  public copyRule(id: number, version: number, type: string) {
    this.paramsService.params = { ruleId: 0, ruleVersion: 0, ruleAction: type, ruleNew: true, ruleTime: null, copyId: id, copyRuleVersion: version };
    this.router.navigate(['/rule/detail', 0]);
  }

  public simulateSelected() {
    const simulateList = [];
    this.rowSelectionModel.selected.forEach(data => { simulateList.push(data['id']); });
    if (simulateList.length > 0) {
      console.log('Simulate This Rows :');
      console.log(simulateList);
    } else {
      console.log('No row selected for simulation');
    }
  }

  public isExpansionDetailRow = (index, row) => row.hasOwnProperty('detailRow');

}
