/**
 * Angular 2 decorators and services
 */
import {
  Component,
  OnInit,
  ViewEncapsulation
} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { Router } from '@angular/router';

import { TranslateService } from '@ngx-translate/core';
import { AirportsService, StartupService, AirlineRs, GroupingRs, CityAirportRs,
TableStructureRs, TableStructure, CityAirportService,
CarrierPreferencesRs, CurrencyRs, CountryRs } from '@dxc/tr-ux-ace-services/dist/lib';
import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';

import { AppSingletonService } from '../../app-singleton.service';
import { AppJsonDataService } from '../../app-json-data.service';
import { environment } from '../../../environments/environment';
import { CarrierConfig } from '../../models/carrier-config';
import { ReferenceTablesService } from '../rule/reference-tables/reference-tables.service';
import { AppConstants } from '../../app.constants';
import { DropdownModel } from 'src/app/models/rule-form.model';

/**
 * App Component
 * Top Level Component
 */
@Component({
  selector: 'app',
  encapsulation: ViewEncapsulation.None,
  styleUrls: [
    './app.component.scss'
  ],
  templateUrl: './app.component.html',
  providers: []

})
export class AppComponent implements OnInit, AfterViewInit {
  public appName = 'ACE Application';

  constructor(
    public router: Router,
    public translate: TranslateService,
    private startupService: StartupService,
    private cityAirportService: CityAirportService,
    private jsonService: AppJsonDataService,
    private airportsService: AirportsService,
    private refTable: ReferenceTablesService,
    private messageService: MessageService,
    private singletonService: AppSingletonService) {

    console.log('Appcomponent constructor ');
    translate.setDefaultLang('en');
    translate.use('en');

    this.jsonService.getRuleJson().subscribe(
      (data: any) => {
        singletonService.ruleJsonStore = data;
      },
      (error: any) => {
        console.log(error);
      }
    );

    this.jsonService.getConfigJson().subscribe(
      (configData: any) => {
        singletonService.configJsonStore = configData;
      },
      (error: any) => {
        console.log(error);
      }
    );

    this.airportsService.getAirportsJson().subscribe(
      (airportData: any) => {
        singletonService.airportJsonStore = this.buildAirportList(airportData.Collection);
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  public ngOnInit() {
    console.log('AppComponent is initialized');
  }

  public ngAfterViewInit() {
    console.log('Appcomponent after view init');
    this.loadCarrierPreferences();
    this.loadAirports();
    this.loadGroups();
    this.loadTables();
    this.loadAirlines();
    this.loadCountries();
    this.loadCurrencies();
    this.loadEquipmentData();
  }

  private loadCarrierPreferences() {
    const carrierPreferenceURL = environment.apiUrl + 'ace/data/carrierPreferences';
    this.startupService.getCarrierPreferences(carrierPreferenceURL).subscribe(
      (response: CarrierPreferencesRs) => {
        this.singletonService.carrierPreferences = response.carrierPreference;

        const dateFormatValues = CarrierConfig.getCarrierPreferenceVaues('GUI Date Format', response.carrierPreference);
        if (dateFormatValues[0]) {
          this.singletonService.carrierDateFormat = dateFormatValues[0].data[0];
          const currencyValues = CarrierConfig.getCarrierPreferenceVaues('Currency', response.carrierPreference);
          this.singletonService.carrierCurrency =  currencyValues[0].data[0];
        }

      },
      (error: HttpErrorResponse ) => {
          console.log(error);
          this.messageService.error(error.status + '---' + error.message);
      }
    );
  }

  private loadAirports() {
    const airportsURL = environment.apiUrl + 'ace/data/cityAirport';
    this.cityAirportService.getCityAirports(airportsURL).subscribe(
      (response: CityAirportRs) => {
        this.singletonService.airports = response.cityAirport;
      },
      (error: HttpErrorResponse ) => {
          console.log(error);
          this.messageService.error(error.status + '---' + error.message);
      }
    );
  }

  private loadAirlines() {
    const airlineURL = environment.apiUrl + 'ace/data/airline';
    this.startupService.getCarriers(airlineURL).subscribe(
      (response: AirlineRs) => {
        this.singletonService.airlines = response.airline;
      },
      (error: HttpErrorResponse ) => {
          console.log(error);
          this.messageService.error(error.status + '---' + error.message);
      }
    );
  }

  private loadGroups() {
    const groupingURL = environment.apiUrl + 'ace/data/grouping';
    this.startupService.getGroups(groupingURL).subscribe(
      (response: GroupingRs) => {
        this.singletonService.groupTypes = response.typeOfGroupings;
      },
      (error: HttpErrorResponse ) => {
          console.log(error);
          this.messageService.error(error.status + '---' + error.message);
      }
    );
  }

  private loadCurrencies() {
    const currencyURL = environment.apiUrl + 'ace/data/currency';
    this.startupService.getCurrencies(currencyURL).subscribe(
      (response: CurrencyRs) => {
        this.singletonService.currencies = response.currency;
      },
      (error: HttpErrorResponse ) => {
          console.log(error);
          this.messageService.error(error.status + '---' + error.message);
      }
    );
  }

  private loadCountries() {
    const countryURL = environment.apiUrl + 'ace/data/country';
    this.startupService.getCountries(countryURL).subscribe(
      (response: CountryRs) => {
        this.singletonService.countires = response.country;
      },
      (error: HttpErrorResponse ) => {
          console.log(error);
          this.messageService.error(error.status + '---' + error.message);
      }
    );
  }

  private loadTables() {
    const referenceTablesURL = environment.apiUrl + 'ace/table/structure';
    this.startupService.getReferenceTables(referenceTablesURL).subscribe(
      (response: TableStructureRs) => {
        this.singletonService.referenceTables = response.tableStructure;
      },
      (error: HttpErrorResponse ) => {
          console.log(error);
          this.messageService.error(error.status + '---' + error.message);
      }
    );
  }

  private loadEquipmentData() {
    const listOfEquipCode = [];
    const listOfEquipConfig = [];
    this.refTable.getTableByName(AppConstants.REF_TABLE_EQUIPMENT).subscribe( // 13 is equipment table id
      (data) => {
          data['row'].forEach(
              row => {
                listOfEquipCode.push({ id: row.column[0], value: row.column[1] } as DropdownModel);
                listOfEquipConfig.push({ id: row.column[2], value: row.column[3] } as DropdownModel);
              }
          );
          this.singletonService.equipmentCodeList = listOfEquipCode;
          this.singletonService.equipmentConfigList = listOfEquipConfig;
      },
      (error: HttpErrorResponse ) => {
        console.log(error);
        this.messageService.error(error.status + '---' + error.message);
     }
    );
  }

  private buildAirportList(data: any): string[] {
    const listOfAirport = [];
    for (const val of data) {
      if (val['LocationCode'] !== '') {
        const arr = {
                  id: val['LocationCode'],
                  value: val['LocationCode'] + ' - ' + val['CityName'] + ', ' + val['CountryName'] + ' ( ' + val['AirportName'] + ' ) '
                };
        listOfAirport.push(arr);
      }
    }
    return listOfAirport;
  }

}
