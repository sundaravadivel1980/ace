import { NgModule } from '@angular/core';
import { DxcCoreModule } from '@dxc/tr-ux-ace-core/dist/lib';
// import { ServicesModule } from '@dxc/tr-ux-ace-services';

import { MarketGroupDirectoryComponent } from './directory/market-group-directory.component';
import { MarketGroupDetailComponent } from './detail/market-group-detail.component';
// import { MarketGroupService }          from '@dxc/tr-ux-ace-services';
import { MarketGroupRoutingModule } from './market-group-routing.module';

@NgModule({
  imports:      [DxcCoreModule, MarketGroupRoutingModule ],
  declarations: [ MarketGroupDetailComponent, MarketGroupDirectoryComponent ],
  providers:    []
})
export class MarketGroupModule {}
