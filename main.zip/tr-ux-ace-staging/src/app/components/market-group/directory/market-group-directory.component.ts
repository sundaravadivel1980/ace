import { Component, OnInit } from '@angular/core';

import { MarketGroup, MarketGroupService } from '@dxc/tr-ux-ace-services/dist/lib';

@Component({
  template: `
    <br>
    <br>
    <br>
    <div *ngFor='let marketGroup of marketGroupes | async'>
      <a routerLink="{{'../' + marketGroup.id}}">{{marketGroup.id}} - {{marketGroup.name}}</a>
    </div>
  `
})
export class MarketGroupDirectoryComponent implements OnInit {
  public marketGroupes: Promise<MarketGroup[]>;

  constructor(private marketGroupService: MarketGroupService) { }

  public ngOnInit() {
    this.marketGroupes = this.marketGroupService.getMarketGroupes();
  }
}
