import { NgModule } from '@angular/core';
import {
  Routes,
  RouterModule
} from '@angular/router';

import { MarketGroupDirectoryComponent } from './directory/market-group-directory.component';
import { MarketGroupDetailComponent } from './detail/market-group-detail.component';

const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  { path: 'list', component: MarketGroupDirectoryComponent },
  { path: ':id', component: MarketGroupDetailComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MarketGroupRoutingModule { }
