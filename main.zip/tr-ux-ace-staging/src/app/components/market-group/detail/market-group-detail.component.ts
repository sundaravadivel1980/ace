import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  template: `
    <h3>Market Group Detail</h3>
    <div>Market Group id: {{id}}</div>
    <br>
    <a routerLink="../list">Go back to list</a>
  `
})
export class MarketGroupDetailComponent implements OnInit {
  public id: number;
  constructor(private route: ActivatedRoute) {  }

  public ngOnInit() {
    this.id = parseInt(this.route.snapshot.paramMap.get('id'), 10);
  }
}
