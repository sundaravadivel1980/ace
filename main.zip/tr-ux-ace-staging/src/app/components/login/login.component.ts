﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

// import { MessageService } from '@dxc/tr-ux-ace-core/dist/lib';

import { AuthenticationService } from '../../services/authentication.service';

@Component({
    templateUrl: 'login.component.html',
    styleUrls: [
        './login.component.scss'
    ]
})

export class LoginComponent implements OnInit {
    public model: any = {};
    public loading = false;
    public returnUrl: string;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService) { }

    public ngOnInit() {
        // reset login status
        this.authenticationService.logout();
        this.returnUrl = '/rule';
    }

    public login() {
        this.authenticationService.login(this.model.username, this.model.password);
        this.router.navigate([this.returnUrl]);
    }
}
