export const AppConstants = {
   ruleUrl : 'ace/rules',
   ruleExportUrl : 'ace/rules/export',
   referenceTable : 'ace/table',

   ACTION_CLASS_CLOSSURE : 'CLSCLO',
   ACTION_CLASS_SUPPRESSION : 'CLSSUP',
   ACTION_BID_PRICE_ADJ: 'BPRADJ',
   ACTION_BASE_FARE_ADJ: 'MKFRAJ',
   ACTION_AVAIL_ADJ: 'AVLADJ',

   REF_TABLE_EQUIPMENT: 'Equipment'
};
