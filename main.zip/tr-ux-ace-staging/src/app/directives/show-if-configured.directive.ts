import { Directive, TemplateRef, ViewContainerRef } from '@angular/core';
import { AppSingletonService } from '../app-singleton.service';
import { RuleParamsService } from '../services/rule/rule-params.service';

@Directive({
    selector: '[show-if-configured]'
})

export class ShowIfConfiguredDirective {

    private defaultList: any;
    private ruleType: string;
    private componentName: string;

    public constructor(
        private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private appSingleton: AppSingletonService,
        private ruleParams: RuleParamsService) {

            this.componentName = templateRef['_def']['element']['template']['lastRenderRootNode']['element']['name'];
            this.ruleType = ruleParams.params.ruleAction;
            this.defaultList = appSingleton.configJsonStore[this.ruleType]['default'];

            if (this.defaultList.indexOf(this.componentName) !== -1) {
                viewContainer.createEmbeddedView(templateRef);
            } else {
                viewContainer.clear();
            }
    }
}
