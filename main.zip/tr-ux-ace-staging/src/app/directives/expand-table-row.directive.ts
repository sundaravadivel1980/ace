import { Directive, HostBinding, HostListener, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
    selector: '[expandTableRow]'
})

export class ExpandTableRowDirective {
    private row: any;
    private tRef: TemplateRef<any>;
    private opened: boolean;

    constructor(public vcRef: ViewContainerRef) { }

    @Input() set expandTableRow(value: any) {
        if (value !== this.row) {
            this.row = value;
        }
    }

    @Input('expandTableRowContent') set template(value: TemplateRef<any>) {
        if (value !== this.tRef && this.row['rule']) {
            this.tRef = value;
        }
    }

    @HostListener('click') public onClick(): void {
        this.toggle();
    }

    public toggle(): void {
        if (this.opened) {
            this.vcRef.clear();
        } else {
            this.render();
        }
        this.opened = this.vcRef.length > 0;
    }

    private render(): void {
        this.vcRef.clear();
        if (this.tRef && this.row && this.row['rule']) {
            this.vcRef.createEmbeddedView(this.tRef, { $implicit: this.row });
        }
    }
}
