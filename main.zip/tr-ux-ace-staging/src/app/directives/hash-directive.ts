import { Component, VERSION, Input, Directive, ViewChildren, ViewContainerRef, QueryList } from '@angular/core';

@Directive({
  selector: '[hash]',
})

export class HashDirective  {
  @Input() public hash: string;

  constructor(public vcRef: ViewContainerRef) {}
}
