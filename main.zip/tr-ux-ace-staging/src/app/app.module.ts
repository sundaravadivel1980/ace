import { NgModule, ApplicationRef } from '@angular/core';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';

/*
 * Platform and Environment providers/directives/pipes
 */
import { DxcCoreModule } from '@dxc/tr-ux-ace-core/dist/lib';
import { ServicesModule } from '@dxc/tr-ux-ace-services/dist/lib';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

import { SharedModule } from './shared.module';

import { ROUTES } from './app.routes';
import { AppComponent } from './components/entry/app.component';
import { NoContentComponent } from './components/no-content';
import { AppJsonDataService } from './app-json-data.service';
import { ReferenceTablesService } from './components/rule/reference-tables/reference-tables.service';

import { LoginComponent } from './components/login/login.component';
import { AuthenticationService } from './services/authentication.service';
import { AuthGuard } from './services/auth.guard';

import '../styles/styles.scss';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, '../assets/i18n/', '.json');
}

/**
 * `AppModule` is the main entry point into Angular2's bootstraping process
 */
@NgModule({
  bootstrap: [ AppComponent ],
  declarations: [
    AppComponent,
    NoContentComponent,
    LoginComponent
  ],
  /**
   * Import Angular's modules.
   */
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    SharedModule.forRoot(),
    DxcCoreModule,
    ServicesModule,
    Ng4LoadingSpinnerModule.forRoot(),
    RouterModule.forRoot(ROUTES, {
      // enableTracing: true,
      // useHash: Boolean(history.pushState) === false,
      // preloadingStrategy: PreloadAllModules
    }),
    TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: (createTranslateLoader),
          deps: [HttpClient]
      }
    })
   ],
  /**
   * Expose our Services and Providers into Angular's dependency injection.
   */
  providers: [ AppJsonDataService, ReferenceTablesService, AuthenticationService, AuthGuard ]
})
export class AppModule {

  constructor(
    public appRef: ApplicationRef
  ) {}
}
