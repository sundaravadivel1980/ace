import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import 'rxjs/add/operator/map';

@Injectable()
export class AppJsonDataService {
  private RULE_JSON_URL: string = '../assets/jsons/rule-json-data.json';
  private CONFIG_JSON_URL: string = '../assets/jsons/copa-config.json';

  constructor(private http: HttpClient) { }
  public getRuleJson() {
    return this.http.get(this.RULE_JSON_URL);
  }
  public getConfigJson() {
    return this.http.get(this.CONFIG_JSON_URL);
  }
}
